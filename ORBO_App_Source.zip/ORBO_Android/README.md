# ORBO — Complete Android Assistant (v0.3.0 source)

Native Android (Kotlin + Compose + plain-View overlay). Offline-first; AI sirf optional toggle (default OFF).
Package `com.orbo.assistant` | module `app` | minSdk 26 | targetSdk 35 | compileSdk 36

## Naya kya hai (v0.3.0)
- Jelly liquid-glass Orb: tap par dent/wobble, aankhein ungli ko follow, expressions (wink, hairan, chakkar), zyada tap par bunde
- Edge docking (kinare par aadha chhup + fade), notch(top-center) = Orb ka "home", unlock ke baad upar se liquid drop
- Screen off -> Orb home mein; unlock -> drop + suspicious face + verification
- Verification: Face (CameraX + ML Kit + TFLite + liveness) -> Orb poochta hai -> Fingerprint -> poori-screen PIN overlay page
- Quick-exit option, Face enroll/test/delete, model import
- Commands screen (saari list on/off, live test, apne trained commands), swipe/cut/select-all/speak/screenshot/notifications/lock-screen
- Contact naam se WhatsApp/SMS message (preview + confirm), YouTube par chalao
- Optional AI (OpenAI/Gemini/Claude/OpenRouter/Groq/Custom): toggle OFF = poora local
- Mic fix: on-device recognizer fail ho to normal recognizer par fallback (voice engine)

## Face model (zaroori)
`face_model.tflite` (MobileFaceNet jaisi) repo root mein rakho ya app mein import karo. Bina model ke face "unavailable" dikhata hai.

## Build
`.github/workflows/android-apk.yml` (Gradle 8.13 khud setup; gradlew nahi). JDK 17 | AGP 8.13.2 | Kotlin 2.2.21

## IMPORTANT
Kuch bhi compile ya phone par test nahi hua. Pehla build GitHub par hoga.
