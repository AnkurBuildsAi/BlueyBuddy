package com.orbo.assistant.orb

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Central reaction state machine (spec sections 6 and 27).
 * Sirf allowed transitions accept hoti hain; baaki reject hoti hain (false return).
 * IDLE aur ERROR har state se allowed hain (cancel / failure ke liye).
 */
class OrbStateMachine(initial: OrbState = OrbState.IDLE) {

    private val lock = Any()
    private val _state = MutableStateFlow(initial)
    val state: StateFlow<OrbState> = _state.asStateFlow()

    /** @return true agar transition ho gayi, false agar allowed nahi thi. */
    fun transitionTo(target: OrbState): Boolean = synchronized(lock) {
        val current = _state.value
        if (!canTransition(current, target)) return false
        _state.value = target
        true
    }

    /** Sirf Orbo.force ke liye: rule ignore karke state set karta hai (UI sync ke liye). */
    fun forceSet(target: OrbState) = synchronized(lock) { _state.value = target }

    /** Cancel / reset: hamesha IDLE par le jata hai. */
    fun reset() = synchronized(lock) { _state.value = OrbState.IDLE }

    companion object {
        private val allowed: Map<OrbState, Set<OrbState>> = mapOf(
            OrbState.IDLE to setOf(
                OrbState.LISTENING, OrbState.THINKING, OrbState.UNLOCK_WELCOME,
                OrbState.VERIFICATION_PENDING, OrbState.SECURITY_REQUIRED, OrbState.SLEEPY,
            ),
            OrbState.UNLOCK_WELCOME to setOf(
                OrbState.VERIFICATION_PENDING, OrbState.LISTENING,
            ),
            OrbState.LISTENING to setOf(OrbState.THINKING),
            OrbState.THINKING to setOf(
                OrbState.EXECUTING, OrbState.WAITING, OrbState.SEARCH_FOUND, OrbState.COMPLETED,
            ),
            OrbState.EXECUTING to setOf(
                OrbState.COMPLETED, OrbState.WAITING, OrbState.SEARCH_FOUND,
            ),
            OrbState.WAITING to setOf(
                OrbState.THINKING, OrbState.EXECUTING, OrbState.COMPLETED,
            ),
            OrbState.COMPLETED to setOf(OrbState.LISTENING),
            OrbState.SEARCH_FOUND to setOf(
                OrbState.EXECUTING, OrbState.WAITING, OrbState.COMPLETED,
            ),
            OrbState.ERROR to setOf(OrbState.LISTENING),
            OrbState.VERIFICATION_PENDING to setOf(
                OrbState.VERIFIED, OrbState.FACE_FAILED, OrbState.SECURITY_REQUIRED,
            ),
            OrbState.FACE_FAILED to setOf(
                OrbState.VERIFICATION_PENDING, OrbState.VERIFIED, OrbState.SECURITY_REQUIRED,
            ),
            OrbState.VERIFIED to emptySet(),
            OrbState.SECURITY_REQUIRED to setOf(
                OrbState.VERIFICATION_PENDING, OrbState.VERIFIED,
            ),
            OrbState.SLEEPY to setOf(OrbState.LISTENING, OrbState.UNLOCK_WELCOME),
        )

        fun canTransition(from: OrbState, to: OrbState): Boolean {
            if (from == to) return false
            if (to == OrbState.IDLE || to == OrbState.ERROR) return true
            return allowed[from]?.contains(to) == true
        }
    }
}
