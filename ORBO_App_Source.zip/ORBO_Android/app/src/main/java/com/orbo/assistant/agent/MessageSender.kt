package com.orbo.assistant.agent

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.orbo.assistant.command.Cmd
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.phone.AppMatcher
import com.orbo.assistant.phone.OrboAccessibilityService
import com.orbo.assistant.phone.PhoneActions
import com.orbo.assistant.ui.PermissionActivity
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import java.net.URLEncoder

/** Contact naam se dhundhna, preview + confirm, phir WhatsApp (chat + Send tap) ya SMS. Bina confirm kuch nahi bhejta. */
object MessageSender {

    private class Contact(val name: String, val number: String, val score: Int)

    private fun fail(m: String) = Res(false, m, m)

    private fun normalizeNumber(raw: String): String {
        val plus = raw.trim().startsWith("+")
        var d = raw.filter { it.isDigit() }
        if (plus) return d
        if (d.startsWith("00")) return d.drop(2)
        val cc = Orbo.prefs.countryCode
        if (d.length == 10) return cc + d
        if (d.length == 11 && d.startsWith("0")) return cc + d.drop(1)
        return d
    }

    private fun findContacts(ctx: Context, query: String): List<Contact> {
        val q = query.lowercase().filter { it.isLetterOrDigit() || it == ' ' }.trim()
        if (q.isEmpty()) return emptyList()
        val out = LinkedHashMap<String, Contact>()
        val proj = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER)
        var rows = 0
        ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, proj, null, null, null)?.use { c ->
            while (c.moveToNext() && rows < 6000) {
                rows++
                val name = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                val n = name.lowercase().filter { it.isLetterOrDigit() || it == ' ' }.trim()
                var score = 0
                if (n == q) score = 100
                else if (n.split(' ').any { it == q }) score = 90
                else if (n.split(' ').any { it.startsWith(q) } || n.startsWith(q)) score = 80
                else if (n.contains(q)) score = 60
                else if (q.length >= 4 && n.split(' ').any { AppMatcher.distance(it, q) <= 1 }) score = 40
                if (score > 0) {
                    val digits = normalizeNumber(num)
                    if (digits.length >= 8) {
                        val old = out[digits]
                        if (old == null || old.score < score) out[digits] = Contact(name, digits, score)
                    }
                }
            }
        }
        val sorted = out.values.sortedByDescending { it.score }
        if (sorted.isEmpty()) return sorted
        val top = sorted[0].score
        return sorted.filter { it.score >= top - 10 }
    }

    suspend fun send(c: Cmd.SendMessage): Res {
        val ctx = Orbo.app
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            PermissionActivity.request(ctx, arrayOf(Manifest.permission.READ_CONTACTS))
            return fail("Contacts ki permission do, phir command dobara bolo.")
        }
        val matches = findContacts(ctx, c.to)
        if (matches.isEmpty()) {
            return fail("'${c.to}' naam ka contact nahi mila. Contact jis naam se save hai (Roman letters mein) wahi bolo/likho.")
        }
        val chosen: Contact = if (matches.size == 1) {
            matches[0]
        } else {
            val opts = matches.take(4).map { Pair("${it.name} \u2022${it.number.takeLast(4)}", it.number) }
            val num = Assistant.choose("Kaunsa '${c.to}'?", opts) ?: return Res(true, "Cancel kar diya.")
            matches.first { it.number == num }
        }
        var body = c.body.trim()
        if (body.isEmpty()) {
            body = Assistant.ask("${chosen.name} ko kya message bhejun? (bolo ya likho)") ?: return Res(true, "Cancel kar diya.")
        }
        body = body.trim().replaceFirstChar { it.uppercase() }
        val via = if (c.via == "sms") "SMS" else "WhatsApp"
        val ok = Assistant.confirm(
            "Message bhejun?",
            "To: ${chosen.name} (+${chosen.number})\nVia: $via\n\n$body",
            "Haan, bhejo", "Cancel",
        )
        if (!ok) return Res(true, "Cancel kar diya. Kuch bheja nahi gaya.")
        return if (c.via == "sms") sendSms(chosen, body) else sendWhatsapp(chosen, body)
    }

    private suspend fun sendWhatsapp(to: Contact, body: String): Res {
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { PhoneActions.hasPackage(it) }
            ?: return fail("WhatsApp installed nahi mila.")
        val url = "https://wa.me/${to.number}?text=${URLEncoder.encode(body, "UTF-8")}"
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            Orbo.app.startActivity(i)
        } catch (e: Exception) {
            return fail("WhatsApp chat nahi khul payi: ${e.message}")
        }
        val s = OrboAccessibilityService.instance
            ?: return Res(true, "${to.name} ki WhatsApp chat khul gayi aur text taiyar hai. Accessibility off hai, isliye Send aap dabao.")
        val fg = withTimeoutOrNull(7000) {
            OrboAccessibilityService.foreground.first { it == pkg }
        }
        if (fg == null) return fail("WhatsApp foreground mein nahi aaya.")
        delay(2500)
        val clicked = listOf("Send", "\u092D\u0947\u091C\u0947\u0902").any { s.clickByText(it) }
        if (!clicked) return Res(true, "Chat khul gayi par Send button nahi mila; aap Send dabao.")
        delay(1500)
        return Res(true, "${to.name} ke liye Send dabaya. WhatsApp se delivery confirm nahi ho sakti; chat dekh lena.", "Message bhej diya")
    }

    private suspend fun sendSms(to: Contact, body: String): Res {
        val ctx = Orbo.app
        if (ctx.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            PermissionActivity.request(ctx, arrayOf(Manifest.permission.SEND_SMS))
            return fail("SMS permission do, phir command dobara bolo.")
        }
        if (body.length > 160) return fail("SMS 160 characters se chhota rakho.")
        val sms: SmsManager? = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else {
            @Suppress("DEPRECATION")
            SmsManager.getDefault()
        }
        if (sms == null) return fail("Is phone par SMS service nahi hai.")
        val action = "com.orbo.assistant.SMS_SENT"
        val d = CompletableDeferred<Int>()
        val rcv = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                d.complete(resultCode)
            }
        }
        ContextCompat.registerReceiver(ctx, rcv, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED)
        try {
            val pi = PendingIntent.getBroadcast(
                ctx, 7, Intent(action).setPackage(ctx.packageName),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            sms.sendTextMessage("+" + to.number, null, body, pi, null)
            val code = withTimeoutOrNull(15000) { d.await() }
            return when (code) {
                null -> fail("SMS ka result nahi mila (15 sec). Messages app mein check karo.")
                Activity.RESULT_OK -> Res(true, "SMS ${to.name} ko bhej diya (network ne accept kiya).", "SMS bhej diya")
                else -> fail("SMS fail hua (code $code).")
            }
        } catch (e: Exception) {
            return fail("SMS bhejne mein error: ${e.message}")
        } finally {
            try { ctx.unregisterReceiver(rcv) } catch (e: Exception) { }
        }
    }
}
