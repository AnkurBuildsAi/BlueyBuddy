package com.orbo.assistant.face

import android.content.Context
import com.orbo.assistant.security.KeystoreCipher
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Face template: sirf embeddings (numbers), Keystore AES-GCM se encrypted. Original photo kabhi save nahi hoti. */
object FaceStore {
    private fun file(ctx: Context) = File(ctx.filesDir, "face_template.bin")

    fun isEnrolled(ctx: Context): Boolean = file(ctx).exists()

    fun save(ctx: Context, samples: List<FloatArray>) {
        val arr = JSONArray()
        for (s in samples) {
            val a = JSONArray()
            for (v in s) a.put(v.toDouble())
            arr.put(a)
        }
        val json = JSONObject().put("dim", samples.firstOrNull()?.size ?: 0).put("samples", arr).toString()
        file(ctx).writeBytes(KeystoreCipher.encrypt(json.toByteArray(Charsets.UTF_8)))
    }

    fun load(ctx: Context): List<FloatArray>? {
        val f = file(ctx)
        if (!f.exists()) return null
        return try {
            val json = JSONObject(String(KeystoreCipher.decrypt(f.readBytes()), Charsets.UTF_8))
            val arr = json.getJSONArray("samples")
            val out = ArrayList<FloatArray>()
            for (i in 0 until arr.length()) {
                val a = arr.getJSONArray(i)
                out.add(FloatArray(a.length()) { a.getDouble(it).toFloat() })
            }
            out
        } catch (e: Exception) {
            null
        }
    }

    fun delete(ctx: Context) {
        file(ctx).delete()
    }
}
