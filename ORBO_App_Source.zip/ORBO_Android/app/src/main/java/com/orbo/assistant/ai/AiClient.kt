package com.orbo.assistant.ai

import android.util.Base64
import com.orbo.assistant.command.CommandCatalog
import com.orbo.assistant.core.NetworkUtil
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.security.KeystoreCipher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

enum class AiProvider(val label: String, val baseUrl: String, val model: String, val anthropic: Boolean) {
    OPENAI("OpenAI", "https://api.openai.com/v1", "gpt-4o-mini", false),
    GEMINI("Gemini", "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.0-flash", false),
    CLAUDE("Claude", "https://api.anthropic.com/v1", "claude-haiku-5-5", true),
    OPENROUTER("OpenRouter", "https://openrouter.ai/api/v1", "openai/gpt-4o-mini", false),
    GROQ("Groq", "https://api.groq.com/openai/v1", "llama-3.1-8b-instant", false),
    CUSTOM("Custom (OpenAI-compatible)", "", "", false),
}

class AiResult(val ok: Boolean, val command: String?, val reply: String?, val error: String?)

object AiKeyStore {
    fun save(key: String) {
        val k = key.trim()
        if (k.isEmpty()) {
            Orbo.prefs.aiKeyBlob = null
            return
        }
        Orbo.prefs.aiKeyBlob = Base64.encodeToString(KeystoreCipher.encrypt(k.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }

    fun load(): String? {
        val b = Orbo.prefs.aiKeyBlob ?: return null
        return try {
            String(KeystoreCipher.decrypt(Base64.decode(b, Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }

    fun has(): Boolean = Orbo.prefs.aiKeyBlob != null
}

/**
 * OPTIONAL AI. Toggle OFF (default) = is file ka koi code kabhi nahi chalta; app poori tarah local rehti hai.
 * ON hone par sirf tab use hota hai jab local command engine command na samjhe.
 * AI sirf ek command-text (ya chhota jawab) lautata hai; wo command phir bhi ORBO ke local parser se guzarta hai,
 * isliye AI seedha phone par kuch nahi chala sakta.
 */
object AiClient {
    fun provider(): AiProvider = try { AiProvider.valueOf(Orbo.prefs.aiProvider) } catch (e: Exception) { AiProvider.OPENAI }
    fun baseUrl(): String = Orbo.prefs.aiBaseUrl.ifBlank { provider().baseUrl }
    fun model(): String = Orbo.prefs.aiModel.ifBlank { provider().model }

    fun enabled(): Boolean = Orbo.prefs.aiEnabled && AiKeyStore.has() && baseUrl().isNotBlank() && model().isNotBlank()

    private fun systemPrompt(): String {
        val sb = StringBuilder()
        sb.append("You translate a user's request into ONE command for an Android assistant called ORBO.\n")
        sb.append("Reply ONLY with a JSON object: {\"command\": string or null, \"reply\": string or null}. No markdown.\n")
        sb.append("'command' must be a short Hinglish/English command in exactly the style of these examples:\n")
        for (c in CommandCatalog.all) sb.append("- ").append(c.examples.first()).append("\n")
        sb.append("If the request is a normal question or chat (not a phone action), set command to null and put a short helpful answer in 'reply' in the user's language.\n")
        sb.append("Never invent commands outside these styles. Never include secrets.")
        return sb.toString()
    }

    suspend fun ask(userText: String): AiResult = withContext(Dispatchers.IO) {
        val key = AiKeyStore.load() ?: return@withContext AiResult(false, null, null, "API key save nahi hai.")
        if (!NetworkUtil.isOnline(Orbo.app)) return@withContext AiResult(false, null, null, "Internet nahi hai.")
        val p = provider()
        val base = baseUrl().trimEnd('/')
        val url = if (p.anthropic) "$base/messages" else "$base/chat/completions"
        val sys = systemPrompt()
        val body = JSONObject()
        body.put("model", model())
        if (p.anthropic) {
            body.put("max_tokens", 300)
            body.put("system", sys)
            body.put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", userText)))
        } else {
            body.put("temperature", 0)
            body.put("max_tokens", 300)
            body.put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", sys))
                    .put(JSONObject().put("role", "user").put("content", userText)),
            )
        }
        var conn: HttpURLConnection? = null
        try {
            conn = URL(url).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 10000
            conn.readTimeout = 25000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            if (p.anthropic) {
                conn.setRequestProperty("x-api-key", key)
                conn.setRequestProperty("anthropic-version", "2023-06-01")
            } else {
                conn.setRequestProperty("Authorization", "Bearer $key")
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try { JSONObject(text).optJSONObject("error")?.optString("message") } catch (e: Exception) { null }
                return@withContext AiResult(false, null, null, "AI error HTTP $code: ${(msg ?: text).take(160)}")
            }
            val json = JSONObject(text)
            val content = if (p.anthropic) {
                json.getJSONArray("content").getJSONObject(0).getString("text")
            } else {
                json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            }
            parse(content)
        } catch (e: Exception) {
            AiResult(false, null, null, "AI request fail: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            conn?.disconnect()
        }
    }

    private fun parse(content: String): AiResult {
        val s = content.indexOf('{')
        val e = content.lastIndexOf('}')
        if (s >= 0 && e > s) {
            try {
                val j = JSONObject(content.substring(s, e + 1))
                val cmd = if (j.isNull("command")) null else j.optString("command").ifBlank { null }
                val rep = if (j.isNull("reply")) null else j.optString("reply").ifBlank { null }
                return AiResult(true, cmd, rep, null)
            } catch (ex: Exception) {
            }
        }
        return AiResult(true, null, content.trim().take(600), null)
    }

    suspend fun test(): String {
        val r = ask("ping: JSON mein reply 'ok' do")
        return if (r.ok) "Connection OK" + (r.reply?.let { " (jawab: ${it.take(40)})" } ?: "") else r.error ?: "Fail"
    }
}
