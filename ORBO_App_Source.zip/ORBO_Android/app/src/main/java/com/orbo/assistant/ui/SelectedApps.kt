package com.orbo.assistant.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.phone.AppInfo
import com.orbo.assistant.phone.OrboAccessibilityService
import com.orbo.assistant.phone.PhoneActions
import com.orbo.assistant.security.PinManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Selected-app protection ka honest status. "ARMED" sirf tab jab sab zaroori cheezein sach mein ON hain. */
fun protectionNotActiveReason(): String? = when {
    !Orbo.prefs.securityEnabled -> "Security switch OFF hai"
    !PinManager.isSet() -> "ORBO PIN set nahi hai"
    OrboAccessibilityService.instance == null -> "Accessibility service connected nahi hai"
    else -> null
}

@Composable
fun SelectedAppsSection(editable: Boolean) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var selected by remember { mutableStateOf(Orbo.prefs.selectedApps) }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.Default) { PhoneActions.launchableApps() } }

    val reason = protectionNotActiveReason()
    Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        Text(
            if (reason == null) {
                "Lock check ARMED (best-effort). Accessibility se foreground app dekhta hai; ye unbreakable lock nahi hai. Real-device test baaki."
            } else {
                "NOT ACTIVE: $reason"
            },
            style = MaterialTheme.typography.bodySmall,
            color = if (reason == null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
        )
        val shown = if (editable) apps else apps.filter { it.pkg in selected }
        if (shown.isEmpty()) Text(if (editable) "Apps load ho rahe hain..." else "Koi app selected nahi.", style = MaterialTheme.typography.bodySmall)
        shown.forEach { app ->
            val icon = remember(app.pkg) {
                try { ctx.packageManager.getApplicationIcon(app.pkg).toBitmap(72, 72).asImageBitmap() } catch (e: Exception) { null }
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                if (icon != null) Image(bitmap = icon, contentDescription = null, modifier = Modifier.size(32.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(app.label, style = MaterialTheme.typography.bodyMedium)
                    val sel = app.pkg in selected
                    Text(
                        if (!sel) "Not selected" else if (reason == null) "Selected: lock check ARMED" else "Selected: NOT ACTIVE",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                if (editable) {
                    Switch(checked = app.pkg in selected, onCheckedChange = { on ->
                        val n = if (on) selected + app.pkg else selected - app.pkg
                        selected = n
                        Orbo.prefs.selectedApps = n
                    })
                }
            }
        }
    }
}
