package com.orbo.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.orbo.assistant.ui.CommandsScreen
import com.orbo.assistant.ui.HistoryScreen
import com.orbo.assistant.ui.HomeScreen
import com.orbo.assistant.ui.SecurityTab
import com.orbo.assistant.ui.SettingsScreen
import com.orbo.assistant.ui.SkillsScreen
import com.orbo.assistant.ui.theme.OrbTheme

class MainActivity : ComponentActivity() {

    // Settings se wapas aane par permission status dobara compute karne ke liye.
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            OrbTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    var tab by remember { mutableIntStateOf(0) }
                    var sub by remember { mutableStateOf<String?>(null) }
                    BackHandler(enabled = sub != null) { sub = null }
                    Scaffold(
                        modifier = Modifier.safeDrawingPadding(),
                        containerColor = MaterialTheme.colorScheme.background,
                        bottomBar = {
                            NavigationBar {
                                val items = listOf("\uD83C\uDFE0" to "Home", "\uD83D\uDCDC" to "History", "\u26A1" to "Skills", "\uD83D\uDD12" to "Security", "\u2699" to "Settings")
                                items.forEachIndexed { i, (icon, label) ->
                                    NavigationBarItem(
                                        selected = tab == i,
                                        onClick = { tab = i },
                                        icon = { Text(icon) },
                                        label = { Text(label) },
                                    )
                                }
                            }
                        },
                    ) { pad ->
                        val m = Modifier.padding(pad)
                        if (sub == "commands") {
                            CommandsScreen(onBack = { sub = null }, modifier = m)
                        } else {
                            when (tab) {
                                0 -> HomeScreen(tick, m)
                                1 -> HistoryScreen(m)
                                2 -> SkillsScreen(m)
                                3 -> SecurityTab(tick, m)
                                else -> SettingsScreen(onOpenCommands = { sub = "commands" }, modifier = m)
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }
}
