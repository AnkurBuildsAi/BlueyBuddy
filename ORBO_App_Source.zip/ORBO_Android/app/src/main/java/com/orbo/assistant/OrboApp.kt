package com.orbo.assistant

import android.app.Application
import com.orbo.assistant.command.CommandParser
import com.orbo.assistant.core.CustomCommands
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.core.Skills

class OrboApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Orbo.init(this)
        Skills.seedIfEmpty()
        CommandParser.disabledKeys = { Orbo.prefs.disabledCommands }
        CommandParser.customPhrases = { try { CustomCommands.all() } catch (e: Exception) { emptyList() } }
    }
}
