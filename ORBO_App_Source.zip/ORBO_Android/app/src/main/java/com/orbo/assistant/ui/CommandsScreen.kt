package com.orbo.assistant.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.orbo.assistant.command.Cmd
import com.orbo.assistant.command.CommandCatalog
import com.orbo.assistant.command.CommandParser
import com.orbo.assistant.command.describe
import com.orbo.assistant.core.CustomCommands
import com.orbo.assistant.core.Orbo

/** Saare commands ki list (on/off), live test box, aur bina-AI ke apne "train kiye" commands. */
@Composable
fun CommandsScreen(onBack: () -> Unit, modifier: Modifier = Modifier) {
    var rev by remember { mutableIntStateOf(0) }
    var disabled by remember { mutableStateOf(Orbo.prefs.disabledCommands) }
    val customs = remember(rev) { CustomCommands.all() }
    var test by remember { mutableStateOf("") }
    var adding by remember { mutableStateOf(false) }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = onBack) { Text("\u2190 Wapas") }
            Text("Commands", style = MaterialTheme.typography.headlineSmall)
        }
        Text(
            "Ye sab bina AI ke, phone ke andar samjhe jaate hain (Hindi / Hinglish / English). " +
                "Jo command yahan band karoge wo ORBO nahi chalayega.",
            style = MaterialTheme.typography.bodySmall,
        )

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Test box (kuch execute nahi hota)", style = MaterialTheme.typography.titleSmall)
                OutlinedTextField(value = test, onValueChange = { test = it }, singleLine = true, label = { Text("Koi bhi command likho") }, modifier = Modifier.fillMaxWidth())
                if (test.isNotBlank()) {
                    val c = CommandParser.parse(test)
                    Text(
                        if (c is Cmd.Unknown) "Samajh nahi aaya: ${c.hint}" else "Samjha: ${c.describe()}",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (c is Cmd.Unknown) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                    )
                }
            }
        }

        Text("Apne commands (train karo)", style = MaterialTheme.typography.titleMedium)
        Text("Ek phrase ko kisi bhi ORBO command se jodo. Jaise: 'padhai shuru' -> '25 minute ka timer lagao'.", style = MaterialTheme.typography.bodySmall)
        Button(onClick = { adding = true }) { Text("Naya command jodo") }
        if (customs.isEmpty()) Text("Abhi koi custom command nahi.", style = MaterialTheme.typography.bodySmall)
        customs.forEach { (phrase, target) ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("\"$phrase\"", style = MaterialTheme.typography.titleSmall)
                    Text("\u2192 $target", style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = { CustomCommands.remove(phrase); rev++ }) { Text("Delete") }
            }
        }

        Text("Saare built-in commands", style = MaterialTheme.typography.titleMedium)
        CommandCatalog.all.forEach { info ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(info.title, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                        Switch(checked = info.key !in disabled, onCheckedChange = { on ->
                            val n = if (on) disabled - info.key else disabled + info.key
                            disabled = n
                            Orbo.prefs.disabledCommands = n
                        })
                    }
                    Text(info.what, style = MaterialTheme.typography.bodySmall)
                    Text(info.examples.joinToString("\n") { "\u2022 $it" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }

    if (adding) {
        var phrase by remember { mutableStateOf("") }
        var target by remember { mutableStateOf("") }
        val parsed = if (target.isBlank()) null else CommandParser.parse(target)
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("Naya command") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = phrase, onValueChange = { phrase = it }, singleLine = true, label = { Text("Aap kya bologe?") })
                    OutlinedTextField(value = target, onValueChange = { target = it }, singleLine = true, label = { Text("ORBO kya kare? (koi command)") })
                    if (parsed != null) {
                        Text(
                            if (parsed is Cmd.Unknown) "Ye target samajh nahi aaya." else "Target: ${parsed.describe()}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (parsed is Cmd.Unknown) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = phrase.isNotBlank() && parsed != null && parsed !is Cmd.Unknown,
                    onClick = {
                        CustomCommands.add(phrase, target)
                        adding = false
                        rev++
                    },
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel") } },
        )
    }
}
