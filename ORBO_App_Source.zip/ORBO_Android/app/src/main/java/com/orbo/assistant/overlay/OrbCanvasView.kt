package com.orbo.assistant.overlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import com.orbo.assistant.orb.EyeStyle
import com.orbo.assistant.orb.MouthStyle
import com.orbo.assistant.orb.OrbFace
import com.orbo.assistant.orb.OrbState
import com.orbo.assistant.orb.OrbTimings
import com.orbo.assistant.orb.toFace
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Liquid-glass jelly Orb (plain Canvas View).
 * - Body: 20-point spring blob (tap par dent + wobble), squash/stretch springs
 * - Eyes: white sclera + navy pupil jo touch ki taraf dekhta hai, blink, expressions
 * - Rapid taps: face badalta hai (wink -> hairan -> chakkar) aur bunde bikharti hain
 * View ka size = orb ka 1.5x (bahar ka hissa glow aur bundon ke liye).
 */
class OrbCanvasView(context: Context) : View(context) {

    private class Drop(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val maxLife: Float, val r: Float)

    private val n = 20
    private val cosA = FloatArray(n) { cos(2.0 * PI * it / n).toFloat() }
    private val sinA = FloatArray(n) { sin(2.0 * PI * it / n).toFloat() }
    private val off = FloatArray(n)
    private val vel = FloatArray(n)
    private val xs = FloatArray(n)
    private val ys = FloatArray(n)

    private var sx = 1f
    private var sxv = 0f
    private var sy = 1f
    private var syv = 0f
    private var lookX = 0f
    private var lookY = 0f
    private var lookTX = 0f
    private var lookTY = 0f
    private var lookHoldUntil = 0L

    private var state: OrbState = OrbState.IDLE
    private var temp: OrbFace? = null
    private var tempUntil = 0L
    private var blink = 1f
    private var pulse = 1f
    private var ripple = -1f
    private var spin = 0f
    private var tapCount = 0
    private var lastTapAt = 0L
    private val drops = ArrayList<Drop>()

    // animated face parameters (fractions of bodyR)
    private var cEw = 0.20f
    private var cEh = 0.30f
    private var cTilt = 0f
    private var cCurve = 0.25f
    private var tEw = 0.20f
    private var tEh = 0.30f
    private var tTilt = 0f
    private var tCurve = 0.25f

    var reducedMotion: Boolean = false
        set(v) {
            field = v
            refreshAnimators()
            applyFaceTargets(snap = true)
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }
    private val rect = RectF()
    private val body = Path()
    private val tmpPath = Path()
    private var cx = 0f
    private var cy = 0f
    private var outerR = 0f
    private var bodyR = 0f
    private var glowShader: Shader? = null
    private var violetShader: Shader? = null
    private var bodyShader: Shader? = null

    private val navy = Color.parseColor("#0B1230")
    private var pulseAnim: ValueAnimator? = null
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var lastFrame = 0L
    private val ticker = Runnable { step() }
    private val blinkTask = object : Runnable {
        override fun run() {
            doBlink()
            scheduleBlink()
        }
    }

    init {
        applyFaceTargets(snap = true)
    }

    // ------------------------------------------------------------------ public API
    fun setOrbState(s: OrbState) {
        if (s == state) return
        state = s
        refreshAnimators()
        applyFaceTargets(snap = reducedMotion)
        if (s == OrbState.VERIFIED || s == OrbState.COMPLETED) jiggle(8f)
        if (s == OrbState.FACE_FAILED || s == OrbState.ERROR) jiggle(5f)
        kick()
        invalidate()
    }

    /** Orb par tap: dent + wobble + look + expression; zyada tap par bunde. */
    fun tap(x: Float, y: Float) {
        val now = SystemClock.uptimeMillis()
        tapCount = if (now - lastTapAt < 800) tapCount + 1 else 1
        lastTapAt = now
        look(x, y)
        playRipple()
        val face = when {
            tapCount == 1 -> OrbFace(EyeStyle.WINK, MouthStyle.SMILE)
            tapCount == 2 -> OrbFace(EyeStyle.WIDE, MouthStyle.SURPRISED)
            tapCount == 3 -> OrbFace(EyeStyle.HAPPY, MouthStyle.GRIN)
            else -> OrbFace(EyeStyle.DIZZY, MouthStyle.WAVY)
        }
        temp = face
        tempUntil = now + if (tapCount >= 4) 1600L else 900L
        applyFaceTargets(snap = reducedMotion)
        if (!reducedMotion) {
            val ang = atan2(y - cy, x - cx)
            poke(ang, 16f + tapCount * 3f)
            if (tapCount >= 4) splash(6 + tapCount)
        }
        kick()
        invalidate()
    }

    /** Ungli kahan hai: aankhein usi taraf dekhengi. */
    fun look(x: Float, y: Float) {
        if (outerR <= 0f) return
        lookTX = ((x - cx) / outerR).coerceIn(-1f, 1f)
        lookTY = ((y - cy) / outerR).coerceIn(-1f, 1f)
        lookHoldUntil = SystemClock.uptimeMillis() + 1400L
        kick()
    }

    fun jiggle(strength: Float) {
        if (reducedMotion) return
        poke((PI / 2).toFloat(), strength)
        syv -= strength * 0.25f
        sxv += strength * 0.15f
        kick()
    }

    fun playSquash() = jiggle(14f)

    fun splash(count: Int) {
        if (reducedMotion || bodyR <= 0f) return
        for (i in 0 until count) {
            val a = Random.nextFloat() * 2f * PI.toFloat()
            val sp = bodyR * (2.2f + Random.nextFloat() * 2.8f)
            val r = bodyR * (0.07f + Random.nextFloat() * 0.10f)
            val life = 0.6f + Random.nextFloat() * 0.5f
            drops.add(Drop(cx + cos(a) * bodyR * 0.9f, cy + sin(a) * bodyR * 0.9f, cos(a) * sp, sin(a) * sp - bodyR * 0.8f, life, life, r))
        }
        kick()
    }

    // ------------------------------------------------------------------ lifecycle
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        refreshAnimators()
        kick()
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(blinkTask)
        handler.removeCallbacks(ticker)
        running = false
        pulseAnim?.cancel()
        pulseAnim = null
        super.onDetachedFromWindow()
    }

    private fun refreshAnimators() {
        pulseAnim?.cancel()
        pulseAnim = null
        pulse = 1f
        handler.removeCallbacks(blinkTask)
        if (!isAttachedToWindow || reducedMotion) return
        val pulsing = state == OrbState.LISTENING || state == OrbState.THINKING ||
            state == OrbState.EXECUTING || state == OrbState.VERIFICATION_PENDING
        if (pulsing) {
            pulseAnim = ValueAnimator.ofFloat(0.75f, 1f).apply {
                duration = 900
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                addUpdateListener {
                    pulse = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }
        scheduleBlink()
    }

    private fun scheduleBlink() {
        val sleepy = state == OrbState.SLEEPY
        val gap = if (sleepy) Random.nextLong(6000L, 9000L) else Random.nextLong(2200L, 4800L)
        handler.postDelayed(blinkTask, gap)
    }

    private fun doBlink() {
        val ms = if (state == OrbState.SLEEPY) OrbTimings.BLINK_MS * 3 else OrbTimings.BLINK_MS
        ValueAnimator.ofFloat(1f, 0.08f, 1f).apply {
            duration = ms.toLong()
            addUpdateListener {
                blink = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun playRipple() {
        ripple = 0f
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = OrbTimings.RIPPLE_MS.toLong()
            addUpdateListener {
                ripple = it.animatedValue as Float
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    ripple = -1f
                    invalidate()
                }
            })
            start()
        }
    }

    // ------------------------------------------------------------------ physics
    private fun poke(angle: Float, strength: Float) {
        for (i in 0 until n) {
            val ai = (2.0 * PI * i / n).toFloat()
            val d = cos(ai - angle)
            vel[i] += -strength * 0.15f * d
        }
        val nx = cos(angle)
        val ny = sin(angle)
        syv += -abs(ny) * 3f + abs(nx) * 1.5f
        sxv += -abs(nx) * 3f + abs(ny) * 1.5f
    }

    private fun kick() {
        if (reducedMotion || !isAttachedToWindow || running) return
        running = true
        lastFrame = 0L
        postOnAnimation(ticker)
    }

    private fun faceNow(): OrbFace = temp ?: state.toFace()

    private fun applyFaceTargets(snap: Boolean) {
        val f = faceNow()
        when (f.eyes) {
            EyeStyle.OPEN -> { tEw = 0.20f; tEh = 0.30f; tTilt = 0f }
            EyeStyle.FOCUSED -> { tEw = 0.22f; tEh = 0.17f; tTilt = 0.15f }
            EyeStyle.CURIOUS -> { tEw = 0.24f; tEh = 0.34f; tTilt = 0f }
            EyeStyle.SLEEPY -> { tEw = 0.22f; tEh = 0.06f; tTilt = 0f }
            EyeStyle.SERIOUS -> { tEw = 0.23f; tEh = 0.16f; tTilt = 0.35f }
            EyeStyle.CONFUSED -> { tEw = 0.20f; tEh = 0.30f; tTilt = 0f }
            EyeStyle.SIDE -> { tEw = 0.20f; tEh = 0.30f; tTilt = 0f }
            EyeStyle.SUSPICIOUS -> { tEw = 0.25f; tEh = 0.13f; tTilt = 0.45f }
            EyeStyle.WIDE -> { tEw = 0.26f; tEh = 0.40f; tTilt = 0f }
            EyeStyle.HAPPY, EyeStyle.WINK, EyeStyle.DIZZY -> { tEw = 0.22f; tEh = 0.24f; tTilt = 0f }
        }
        tCurve = when (f.mouth) {
            MouthStyle.NEUTRAL -> 0.25f
            MouthStyle.SMILE -> 0.8f
            MouthStyle.FROWN -> -0.55f
            else -> 0.25f
        }
        if (snap) {
            cEw = tEw; cEh = tEh; cTilt = tTilt; cCurve = tCurve
        }
    }

    private fun step() {
        running = false
        val now = SystemClock.uptimeMillis()
        var dt = if (lastFrame == 0L) 0.016f else (now - lastFrame) / 1000f
        lastFrame = now
        dt = dt.coerceIn(0.001f, 0.032f)
        var energy = 0f

        for (i in 0 until n) {
            val l = off[(i + n - 1) % n]
            val r = off[(i + 1) % n]
            val a = -150f * off[i] - 7f * vel[i] + 45f * (l + r - 2f * off[i])
            vel[i] += a * dt
        }
        for (i in 0 until n) {
            off[i] += vel[i] * dt
            energy += abs(off[i]) + abs(vel[i])
        }
        syv += (-170f * (sy - 1f) - 8f * syv) * dt
        sy += syv * dt
        sxv += (-170f * (sx - 1f) - 8f * sxv) * dt
        sx += sxv * dt
        energy += abs(sx - 1f) + abs(sy - 1f) + abs(sxv) + abs(syv)

        if (now > lookHoldUntil) {
            lookTX = 0f
            lookTY = 0f
        }
        val f = min(1f, 12f * dt)
        lookX += (lookTX - lookX) * f
        lookY += (lookTY - lookY) * f
        energy += abs(lookTX - lookX) + abs(lookTY - lookY)

        if (temp != null && now > tempUntil) {
            temp = null
            applyFaceTargets(snap = false)
        }
        val g = min(1f, 14f * dt)
        cEw += (tEw - cEw) * g
        cEh += (tEh - cEh) * g
        cTilt += (tTilt - cTilt) * g
        cCurve += (tCurve - cCurve) * g
        energy += abs(tEw - cEw) + abs(tEh - cEh) + abs(tTilt - cTilt) + abs(tCurve - cCurve)

        val eyes = faceNow().eyes
        val needSpin = eyes == EyeStyle.DIZZY || eyes == EyeStyle.SUSPICIOUS
        if (needSpin) spin += 5f * dt

        val it = drops.iterator()
        while (it.hasNext()) {
            val d = it.next()
            d.x += d.vx * dt
            d.y += d.vy * dt
            d.vy += bodyR * 6f * dt
            d.life -= dt
            if (d.life <= 0f) it.remove()
        }

        if (energy > 0.004f || drops.isNotEmpty() || temp != null || needSpin) {
            running = true
            postOnAnimation(ticker)
        } else {
            for (i in 0 until n) { off[i] = 0f; vel[i] = 0f }
            sx = 1f; sy = 1f; sxv = 0f; syv = 0f
        }
        invalidate()
    }

    // ------------------------------------------------------------------ drawing
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cx = w / 2f
        cy = h / 2f
        outerR = min(w, h) / 2f
        bodyR = min(w, h) / 3f
        if (outerR <= 0f) return
        val blue = Color.parseColor("#2EA8FF")
        val violet = Color.parseColor("#8B5CF6")
        glowShader = RadialGradient(cx, cy, outerR, intArrayOf(blue, Color.argb(0, 46, 168, 255)), floatArrayOf(0.35f, 1f), Shader.TileMode.CLAMP)
        val vx = cx + bodyR * 0.45f
        val vy = cy + bodyR * 0.55f
        violetShader = RadialGradient(vx, vy, outerR * 0.85f, intArrayOf(violet, Color.argb(0, 139, 92, 246)), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        bodyShader = RadialGradient(
            cx - bodyR * 0.35f, cy - bodyR * 0.4f, bodyR * 1.9f,
            intArrayOf(Color.parseColor("#B8E6FF"), Color.parseColor("#4FA8FF"), Color.parseColor("#2B4FD8"), Color.parseColor("#4A1FA0")),
            floatArrayOf(0f, 0.30f, 0.65f, 1f), Shader.TileMode.CLAMP,
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (outerR <= 0f) return

        // outer glow (squash ke bina)
        paint.shader = glowShader
        paint.alpha = (255 * 0.55f * pulse).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, outerR, paint)
        paint.shader = violetShader
        paint.alpha = (255 * 0.42f * pulse).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx + bodyR * 0.45f, cy + bodyR * 0.55f, outerR * 0.85f, paint)
        paint.shader = null
        paint.alpha = 255

        canvas.save()
        canvas.scale(sx, sy, cx, cy)

        // body path
        for (i in 0 until n) {
            val r = bodyR * (1f + off[i])
            xs[i] = cx + cosA[i] * r
            ys[i] = cy + sinA[i] * r
        }
        body.reset()
        body.moveTo((xs[n - 1] + xs[0]) / 2f, (ys[n - 1] + ys[0]) / 2f)
        for (i in 0 until n) {
            val j = (i + 1) % n
            body.quadTo(xs[i], ys[i], (xs[i] + xs[j]) / 2f, (ys[i] + ys[j]) / 2f)
        }
        body.close()

        paint.style = Paint.Style.FILL
        paint.shader = bodyShader
        canvas.drawPath(body, paint)
        paint.shader = null

        // glass rim
        line.strokeWidth = bodyR * 0.05f
        line.color = Color.argb(120, 255, 255, 255)
        canvas.drawPath(body, line)
        // inner lower shade
        paint.color = Color.argb(46, 20, 0, 80)
        rect.set(cx - bodyR * 0.8f, cy + bodyR * 0.35f, cx + bodyR * 0.8f, cy + bodyR * 0.95f)
        canvas.drawOval(rect, paint)
        // specular highlights
        paint.color = Color.argb(150, 255, 255, 255)
        rect.set(cx - bodyR * 0.62f, cy - bodyR * 0.88f, cx + bodyR * 0.30f, cy - bodyR * 0.42f)
        canvas.drawOval(rect, paint)
        paint.color = Color.argb(110, 255, 255, 255)
        canvas.drawCircle(cx + bodyR * 0.55f, cy + bodyR * 0.55f, bodyR * 0.07f, paint)

        drawFace(canvas, faceNow())
        canvas.restore()

        // ripple
        if (ripple >= 0f) {
            line.strokeWidth = bodyR * 0.05f
            line.color = Color.argb(((1f - ripple) * 180).toInt().coerceIn(0, 255), 255, 255, 255)
            canvas.drawCircle(cx, cy, bodyR * (0.9f + 0.5f * ripple), line)
            line.color = Color.WHITE
        }

        // droplets
        for (d in drops) {
            val a = (d.life / d.maxLife).coerceIn(0f, 1f)
            paint.color = Color.argb((190 * a).toInt(), 90, 190, 255)
            canvas.drawCircle(d.x, d.y, d.r, paint)
            paint.color = Color.argb((200 * a).toInt(), 255, 255, 255)
            canvas.drawCircle(d.x - d.r * 0.3f, d.y - d.r * 0.3f, d.r * 0.35f, paint)
        }
    }

    private fun drawFace(canvas: Canvas, face: OrbFace) {
        val eyeY = cy - bodyR * 0.12f
        val gap = bodyR * 0.38f
        val w = cEw * bodyR
        val h = cEh * bodyR
        drawEye(canvas, cx - gap, eyeY, w, h, true, face.eyes)
        drawEye(canvas, cx + gap, eyeY, w, h, false, face.eyes)
        drawMouth(canvas, face)
    }

    private fun drawEye(canvas: Canvas, ex: Float, ey: Float, w: Float, hBase: Float, left: Boolean, style: EyeStyle) {
        val sw = bodyR * 0.07f
        line.strokeWidth = sw
        line.color = Color.WHITE
        when {
            style == EyeStyle.HAPPY || (style == EyeStyle.WINK && !left) -> {
                rect.set(ex - w, ey - hBase * 0.5f, ex + w, ey + hBase * 1.1f)
                canvas.drawArc(rect, 200f, 140f, false, line)
                return
            }
            style == EyeStyle.SLEEPY -> {
                rect.set(ex - w, ey - hBase * 2f, ex + w, ey + hBase * 2f)
                canvas.drawArc(rect, 20f, 140f, false, line)
                return
            }
            style == EyeStyle.DIZZY -> {
                line.color = Color.WHITE
                line.strokeWidth = bodyR * 0.05f
                val r1 = w * 0.95f
                rect.set(ex - r1, ey - r1, ex + r1, ey + r1)
                val a0 = spin * 57.3f * if (left) 1f else -1f
                canvas.drawArc(rect, a0, 300f, false, line)
                val r2 = r1 * 0.55f
                rect.set(ex - r2, ey - r2, ex + r2, ey + r2)
                canvas.drawArc(rect, a0 + 90f, 260f, false, line)
                return
            }
        }
        var h = hBase
        if (style == EyeStyle.CONFUSED) h = if (left) hBase * 1.25f else hBase * 0.7f
        val hh = h * blink
        paint.color = Color.WHITE
        rect.set(ex - w, ey - hh, ex + w, ey + hh)
        canvas.drawOval(rect, paint)
        // pupil
        var lx = lookX
        var ly = lookY
        if (style == EyeStyle.SIDE) lx = 0.8f
        if (style == EyeStyle.SUSPICIOUS) lx = sin(spin * 0.9f) * 0.9f
        val pr = min(w, hh) * 0.62f
        if (pr > 1f) {
            val px = ex + lx * (w - pr) * 0.9f
            val py = ey + ly * (hh - pr).coerceAtLeast(0f) * 0.9f
            paint.color = navy
            canvas.drawCircle(px, py, pr, paint)
            paint.color = Color.WHITE
            canvas.drawCircle(px - pr * 0.35f, py - pr * 0.35f, pr * 0.30f, paint)
        }
        // brow
        if (cTilt > 0.06f) {
            line.color = Color.argb(200, 11, 18, 48)
            line.strokeWidth = bodyR * 0.06f
            val by = ey - hBase * 1.25f
            val dy = cTilt * w * 0.8f
            if (left) canvas.drawLine(ex - w, by - dy, ex + w, by + dy, line)
            else canvas.drawLine(ex - w, by + dy, ex + w, by - dy, line)
            line.color = Color.WHITE
        }
    }

    private fun drawMouth(canvas: Canvas, face: OrbFace) {
        val my = cy + bodyR * 0.40f
        val mw = bodyR * 0.30f
        line.color = Color.WHITE
        line.strokeWidth = bodyR * 0.06f
        when (face.mouth) {
            MouthStyle.NEUTRAL, MouthStyle.SMILE, MouthStyle.FROWN -> {
                tmpPath.reset()
                tmpPath.moveTo(cx - mw, my)
                tmpPath.quadTo(cx, my + cCurve * mw * 1.6f, cx + mw, my)
                canvas.drawPath(tmpPath, line)
            }
            MouthStyle.GRIN -> {
                tmpPath.reset()
                tmpPath.moveTo(cx - mw * 1.1f, my - mw * 0.1f)
                tmpPath.quadTo(cx, my + mw * 1.5f, cx + mw * 1.1f, my - mw * 0.1f)
                tmpPath.close()
                paint.color = navy
                canvas.drawPath(tmpPath, paint)
                line.strokeWidth = bodyR * 0.04f
                canvas.drawPath(tmpPath, line)
            }
            MouthStyle.SURPRISED -> {
                rect.set(cx - mw * 0.3f, my - mw * 0.2f, cx + mw * 0.3f, my + mw * 0.5f)
                paint.color = navy
                canvas.drawOval(rect, paint)
            }
            MouthStyle.THINKING -> {
                canvas.drawLine(cx - mw * 0.5f, my + mw * 0.1f, cx + mw * 0.7f, my - mw * 0.2f, line)
            }
            MouthStyle.WAVY -> {
                tmpPath.reset()
                tmpPath.moveTo(cx - mw, my)
                val seg = 4
                for (i in 0 until seg) {
                    val x0 = cx - mw + (2f * mw) * i / seg
                    val x1 = cx - mw + (2f * mw) * (i + 1) / seg
                    val amp = mw * 0.28f * if (i % 2 == 0) 1f else -1f
                    tmpPath.quadTo((x0 + x1) / 2f, my + amp * 2f, x1, my)
                }
                canvas.drawPath(tmpPath, line)
            }
        }
    }
}
