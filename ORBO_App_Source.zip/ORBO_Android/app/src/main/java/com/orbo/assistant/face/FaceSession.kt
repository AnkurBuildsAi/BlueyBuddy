package com.orbo.assistant.face

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Rect
import android.os.SystemClock
import androidx.camera.core.ImageProxy
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Camera frames ka logic: face detect (ML Kit) -> crop -> embedding (TFLite) -> cosine match.
 * VERIFY mein liveness challenge (sar ghumao ya palak jhapkao) bhi hota hai taaki seedhi photo se na khule.
 * (Video replay se dhoka phir bhi mumkin hai: isliye PIN aur fingerprint backup hamesha rehte hain.)
 */
class FaceSession(
    private val ctx: Context,
    private val mode: Mode,
    private val templates: List<FloatArray>,
    private val threshold: Float,
    private val preproc: Int,
    private val listener: Listener,
) {
    enum class Mode { ENROLL, VERIFY, TEST }

    interface Listener {
        fun onStatus(msg: String, progress: Float, score: Float?)
        fun onFinished(ok: Boolean, msg: String, samples: List<FloatArray>?)
    }

    var suggestedThreshold: Float = 0.65f
        private set

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .setMinFaceSize(0.2f)
            .build(),
    )

    @Volatile
    private var finished = false
    private var lastProcess = 0L
    private val startAt = SystemClock.uptimeMillis()
    private var stable = 0

    // enroll
    private val prompts = listOf("Seedha dekho", "Sar thoda ek taraf ghumao", "Ab doosri taraf ghumao", "Phir seedha dekho", "Thoda muskurao")
    private val samples = ArrayList<FloatArray>()
    private var yawSign = 0
    private var lastCapture = 0L

    // verify
    private var phase = 0 // 0 detect, 1 challenge, 2 match
    private var challenge = 0 // 0 blink, 1 turn
    private var baselineYaw = 0f
    private var challengeStart = 0L
    private var blinkStage = 0
    private val scores = ArrayList<Float>()

    fun stop() {
        finished = true
    }

    fun release() {
        finished = true
        try { detector.close() } catch (e: Exception) { }
    }

    fun analyze(proxy: ImageProxy) {
        try {
            if (finished) return
            val now = SystemClock.uptimeMillis()
            if (now - lastProcess < 60) return
            lastProcess = now
            if (mode == Mode.VERIFY && now - startAt > 20000) {
                finish(false, "Time out: face verify nahi ho paya.")
                return
            }
            val bmp = upright(proxy)
            handle(bmp)
        } catch (t: Throwable) {
            finish(false, "Face check error: ${t.message ?: t.javaClass.simpleName}")
        } finally {
            proxy.close()
        }
    }

    private fun upright(proxy: ImageProxy): Bitmap {
        val b = proxy.toBitmap()
        val rot = proxy.imageInfo.rotationDegrees
        if (rot == 0) return b
        val m = Matrix()
        m.postRotate(rot.toFloat())
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }

    private fun handle(bmp: Bitmap) {
        val faces = Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0)))
        if (faces.isEmpty()) {
            stable = 0
            listener.onStatus("Face nahi dikh raha. Camera ki taraf dekho.", progress(), null)
            return
        }
        if (faces.size > 1) {
            stable = 0
            listener.onStatus("Sirf ek insaan camera ke saamne aaye.", progress(), null)
            return
        }
        val f = faces[0]
        val bb = f.boundingBox
        if (bb.width() < bmp.width * 0.22f) {
            stable = 0
            listener.onStatus("Thoda paas aao.", progress(), null)
            return
        }
        val crop = cropFace(bmp, bb, f.headEulerAngleZ)
        if (luma(crop) < 50f) {
            stable = 0
            listener.onStatus("Roshni bahut kam hai. Roshan jagah par aao.", progress(), null)
            return
        }
        val emb = FaceModel.embed(ctx, crop, preproc)
        if (emb == null) {
            finish(false, "Face model chala nahi paya (Security tab mein model check karo).")
            return
        }
        val yaw = f.headEulerAngleY
        val pitch = f.headEulerAngleX
        val l = f.leftEyeOpenProbability
        val r = f.rightEyeOpenProbability
        val eyesOpen = if (l != null && r != null) (l + r) / 2f else null

        when (mode) {
            Mode.ENROLL -> enroll(emb, yaw, pitch, eyesOpen)
            Mode.TEST -> {
                val s = bestScore(emb)
                listener.onStatus(
                    String.format("Score %.2f  (limit %.2f)  %s", s, threshold, if (s >= threshold) "MATCH" else "no match"),
                    0f, s,
                )
            }
            Mode.VERIFY -> verify(emb, yaw, eyesOpen)
        }
    }

    private fun progress(): Float = if (mode == Mode.ENROLL) samples.size / 5f else 0f

    private fun bestScore(e: FloatArray): Float {
        var best = -1f
        for (t in templates) best = max(best, FaceModel.cosine(e, t))
        return best
    }

    // ---------------------------------------------------------------- enroll
    private fun enroll(emb: FloatArray, yaw: Float, pitch: Float, eyesOpen: Float?) {
        val step = samples.size
        if (step >= 5) return
        val msgPrefix = "${step + 1}/5: ${prompts[step]}"
        val ok = when (step) {
            0, 3, 4 -> abs(yaw) < 10f && abs(pitch) < 15f
            1 -> abs(yaw) in 12f..40f
            else -> abs(yaw) in 12f..40f && (if (yaw > 0) 1 else -1) == -yawSign
        }
        if (!ok || (eyesOpen != null && eyesOpen < 0.4f)) {
            stable = 0
            listener.onStatus(msgPrefix, progress(), null)
            return
        }
        stable++
        val now = SystemClock.uptimeMillis()
        if (stable >= 3 && now - lastCapture > 700) {
            if (step == 1) yawSign = if (yaw > 0) 1 else -1
            samples.add(emb)
            lastCapture = now
            stable = 0
            if (samples.size >= 5) {
                var sum = 0f
                var cnt = 0
                for (i in samples.indices) for (j in i + 1 until samples.size) {
                    sum += FaceModel.cosine(samples[i], samples[j])
                    cnt++
                }
                val mean = if (cnt > 0) sum / cnt else 0.8f
                suggestedThreshold = (mean - 0.15f).coerceIn(0.45f, 0.85f)
                finish(true, String.format("Face save ho gaya. Samples ka average match %.2f; suggested limit %.2f.", mean, suggestedThreshold), ArrayList(samples))
                return
            }
        }
        listener.onStatus(msgPrefix, progress(), null)
    }

    // ---------------------------------------------------------------- verify
    private fun verify(emb: FloatArray, yaw: Float, eyesOpen: Float?) {
        val now = SystemClock.uptimeMillis()
        when (phase) {
            0 -> {
                stable++
                listener.onStatus("Face dekh raha hoon...", 0.1f, null)
                if (stable >= 3) {
                    baselineYaw = yaw
                    challenge = if (eyesOpen == null || Random.nextInt(10) < 6) 1 else 0
                    challengeStart = now
                    blinkStage = 0
                    phase = 1
                }
            }
            1 -> {
                if (now - challengeStart > 7000) {
                    finish(false, "Liveness challenge pass nahi hua.")
                    return
                }
                if (challenge == 1) {
                    listener.onStatus("Sar thoda ghumao", 0.4f, null)
                    if (abs(yaw - baselineYaw) >= 15f) {
                        phase = 2
                        scores.clear()
                    }
                } else {
                    listener.onStatus("Ek baar palak jhapkao", 0.4f, null)
                    val e = eyesOpen ?: 1f
                    when (blinkStage) {
                        0 -> if (e > 0.6f) blinkStage = 1
                        1 -> if (e < 0.45f) blinkStage = 2
                        else -> if (e > 0.6f) {
                            phase = 2
                            scores.clear()
                        }
                    }
                }
            }
            else -> {
                if (abs(yaw) > 25f) {
                    listener.onStatus("Ab seedha dekho", 0.7f, null)
                    return
                }
                val s = bestScore(emb)
                scores.add(s)
                listener.onStatus(String.format("Match check... %.2f", s), 0.85f, s)
                if (scores.size >= 3) {
                    val sorted = scores.sorted()
                    val median = sorted[sorted.size / 2]
                    if (median >= threshold) {
                        finish(true, String.format("Face match hua (score %.2f).", median), null)
                    } else if (scores.size >= 5) {
                        finish(false, String.format("Face match nahi hua (score %.2f, limit %.2f).", median, threshold), null)
                    }
                }
            }
        }
    }

    private fun finish(ok: Boolean, msg: String, s: List<FloatArray>?) {
        if (finished) return
        finished = true
        listener.onFinished(ok, msg, s)
    }

    // ---------------------------------------------------------------- image helpers
    private fun cropFace(bmp: Bitmap, bb: Rect, rollDeg: Float): Bitmap {
        var side = (max(bb.width(), bb.height()) * 1.3f).toInt()
        side = min(side, min(bmp.width, bmp.height))
        val left = (bb.centerX() - side / 2).coerceIn(0, bmp.width - side)
        val top = (bb.centerY() - side / 2).coerceIn(0, bmp.height - side)
        var c = Bitmap.createBitmap(bmp, left, top, side, side)
        if (abs(rollDeg) > 4f) {
            val m = Matrix()
            m.postRotate(-rollDeg)
            c = Bitmap.createBitmap(c, 0, 0, c.width, c.height, m, true)
        }
        return c
    }

    private fun luma(b: Bitmap): Float {
        val s = Bitmap.createScaledBitmap(b, 16, 16, true)
        var sum = 0f
        for (y in 0 until 16) for (x in 0 until 16) {
            val p = s.getPixel(x, y)
            sum += 0.299f * Color.red(p) + 0.587f * Color.green(p) + 0.114f * Color.blue(p)
        }
        if (s !== b) s.recycle()
        return sum / 256f
    }
}
