package com.orbo.assistant.core

import android.app.Application
import com.orbo.assistant.orb.OrbState
import com.orbo.assistant.orb.OrbStateMachine
import kotlinx.coroutines.flow.MutableStateFlow

enum class PillKind { IDLE, LISTENING, THINKING, EXECUTING, RESULT, VERIFICATION, TIMER, ERROR }

class PillAction(val label: String, val run: () -> Unit)

class PillStatus(
    val text: String,
    val kind: PillKind = PillKind.IDLE,
    val detail: String = "",
    val actions: List<PillAction> = emptyList(),
)

/** Poore app ka shared state: ek Orb state machine aur ek Pill status. */
object Orbo {
    lateinit var app: Application
        private set
    lateinit var prefs: Prefs
        private set

    val machine = OrbStateMachine()
    val pill = MutableStateFlow(PillStatus("ORBO ready"))

    fun init(a: Application) {
        app = a
        prefs = Prefs(a)
    }

    /** Naye state par jao; agar rule allow nahi karta to pehle IDLE par reset. */
    fun force(s: OrbState) {
        if (machine.state.value == s) return
        if (!machine.transitionTo(s)) machine.forceSet(s)
    }

    fun say(text: String, kind: PillKind, detail: String = "", actions: List<PillAction> = emptyList()) {
        pill.value = PillStatus(text, kind, detail, actions)
    }
}
