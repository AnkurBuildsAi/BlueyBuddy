package com.orbo.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val OrbBlue = Color(0xFF2EA8FF)
val OrbViolet = Color(0xFF8B5CF6)

private val OrbDarkScheme = darkColorScheme(
    primary = OrbBlue,
    secondary = OrbViolet,
    background = Color(0xFF070B1A),
    surface = Color(0xFF111833),
    onPrimary = Color(0xFF00121F),
    onBackground = Color(0xFFE8ECFF),
    onSurface = Color(0xFFE8ECFF),
)

/** Phase 1: dark theme only. Light theme (spec section 8) baad ke phase mein. */
@Composable
fun OrbTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = OrbDarkScheme, content = content)
}
