package com.orbo.assistant.face

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import com.orbo.assistant.core.Orbo

/** Face verification use karne layak hai ya nahi: seedha, honest reason ke saath. */
object FaceGate {
    /** null = ready */
    fun status(ctx: Context): String? {
        if (!Orbo.prefs.faceEnabled) return "Face verification OFF hai (Security tab)."
        if (!FaceModel.hasModel(ctx)) return "Face model nahi hai. Security tab se model import karo."
        if (!FaceStore.isEnrolled(ctx)) return "Face enroll nahi hua. Security tab se enroll karo."
        if (ctx.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            return "Camera permission nahi hai."
        }
        return null
    }

    fun ready(ctx: Context): Boolean = status(ctx) == null
}
