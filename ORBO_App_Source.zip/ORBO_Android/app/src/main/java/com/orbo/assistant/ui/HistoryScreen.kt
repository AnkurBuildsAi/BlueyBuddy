package com.orbo.assistant.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.orbo.assistant.core.Stores
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(modifier: Modifier = Modifier) {
    var rev by remember { mutableIntStateOf(0) }
    val fmt = remember { SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()) }
    val history = remember(rev) { Stores.history.read().reversed() }
    val memory = remember(rev) { Stores.memory.read().reversed() }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("History", style = MaterialTheme.typography.headlineSmall)
        OutlinedButton(onClick = { Stores.history.clear(); rev++ }, enabled = history.isNotEmpty()) { Text("History clear karo") }
        if (history.isEmpty()) Text("Abhi koi task history nahi.")
        history.forEach {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(it.optString("command"), style = MaterialTheme.typography.titleSmall)
                    Text("${it.optString("state")}  •  ${fmt.format(Date(it.optLong("start")))}", style = MaterialTheme.typography.bodySmall)
                    Text(it.optString("result"), style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        Text("Saved memory", style = MaterialTheme.typography.headlineSmall)
        Text("Sirf wahi jo aapne 'yaad rakho' bolkar confirm kiya. Password/PIN/OTP kabhi save nahi hota.", style = MaterialTheme.typography.bodySmall)
        if (memory.isEmpty()) Text("Koi memory saved nahi.")
        memory.forEach { m ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(m.optString("text"), Modifier.weight(1f))
                TextButton(onClick = {
                    val id = m.optLong("id")
                    Stores.memory.write(Stores.memory.read().filter { it.optLong("id") != id })
                    rev++
                }) { Text("Delete") }
            }
        }
        OutlinedButton(onClick = { Stores.memory.clear(); rev++ }, enabled = memory.isNotEmpty()) { Text("Saari memory delete karo") }
    }
}
