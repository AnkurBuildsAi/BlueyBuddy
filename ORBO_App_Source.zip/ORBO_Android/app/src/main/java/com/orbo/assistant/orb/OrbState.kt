package com.orbo.assistant.orb

/** Spec section 6: Orb ke saare reaction states. Ye single source of truth hai. */
enum class OrbState {
    IDLE,
    UNLOCK_WELCOME,
    LISTENING,
    THINKING,
    EXECUTING,
    WAITING,
    COMPLETED,
    SEARCH_FOUND,
    ERROR,
    VERIFICATION_PENDING,
    FACE_FAILED,
    VERIFIED,
    SECURITY_REQUIRED,
    SLEEPY,
}
