package com.orbo.assistant.phone

class AppInfo(val label: String, val pkg: String)
class AppMatch(val app: AppInfo, val score: Int)

object AppMatcher {
    private val aliases: Map<String, List<String>> = mapOf(
        "whatsapp" to listOf("whatsapp"),
        "youtube" to listOf("youtube"),
        "gallery" to listOf("gallery", "photos"),
        "photos" to listOf("photos", "gallery"),
        "messages" to listOf("messages", "messaging", "sms"),
        "message" to listOf("messages", "messaging", "sms"),
        "phone" to listOf("phone", "dialer"),
        "dialer" to listOf("phone", "dialer"),
        "browser" to listOf("chrome", "browser", "firefox", "brave"),
        "camera" to listOf("camera"),
        "calculator" to listOf("calculator"),
        "clock" to listOf("clock"),
        "maps" to listOf("maps"),
        "settings" to listOf("settings"),
    )

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    fun match(query: String, apps: List<AppInfo>): List<AppMatch> {
        val q = norm(query)
        if (q.isEmpty()) return emptyList()
        val aliasTargets = aliases[query.lowercase().trim()] ?: aliases[q] ?: emptyList()
        val out = mutableListOf<AppMatch>()
        for (a in apps) {
            val l = norm(a.label)
            if (l.isEmpty()) continue
            var score = 0
            if (l == q) score = 100
            else if (l.startsWith(q)) score = 80
            else if (aliasTargets.any { l.contains(it) }) score = 70
            else if (l.contains(q)) score = 60
            else if (q.contains(l) && l.length >= 4) score = 50
            else {
                val d = distance(l, q)
                if (q.length >= 5 && d <= 1) score = 40 else if (q.length >= 8 && d <= 2) score = 30
            }
            if (score > 0) out.add(AppMatch(a, score))
        }
        return out.sortedByDescending { it.score }
    }

    fun distance(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }
}
