package com.orbo.assistant.command

class CommandInfo(val key: String, val title: String, val what: String, val examples: List<String>)

/** Settings > Commands mein dikhane wali poori list. Parser jo samajhta hai wahi yahan likha hai. */
object CommandCatalog {
    val all: List<CommandInfo> = listOf(
        CommandInfo("open_app", "App kholo", "Installed app naam se kholta hai (kholne ke baad verify bhi karta hai).",
            listOf("YouTube kholo", "WhatsApp open karo", "gallery kholo")),
        CommandInfo("back", "Back", "Back button ka action.", listOf("back jao", "peeche jao")),
        CommandInfo("home", "Phone Home", "Phone ki home screen par jao.", listOf("home screen par jao", "home jao")),
        CommandInfo("recents", "Recent apps", "Recent apps screen.", listOf("recents kholo")),
        CommandInfo("scroll", "Scroll", "Screen ko upar/neeche scroll karta hai.", listOf("scroll down", "scroll up", "neeche jao")),
        CommandInfo("swipe", "Swipe", "Screen par left/right/up/down swipe.", listOf("swipe left", "swipe right", "swipe up")),
        CommandInfo("time", "Time batao", "Abhi ka samay bolta hai.", listOf("current time batao", "kitne baje hain")),
        CommandInfo("timer", "Timer / reminder", "Timer lagao, cancel, pause, resume.", listOf("10 minute ka timer lagao", "timer cancel karo", "timer pause karo")),
        CommandInfo("stopwatch", "Stopwatch", "Stopwatch chalu/band.", listOf("stopwatch chalu karo", "stopwatch band karo")),
        CommandInfo("stop_cancel", "Stop / Cancel", "Chal raha kaam rokta hai.", listOf("stop", "cancel", "ruko")),
        CommandInfo("pause_resume", "Pause / Resume", "Padhna ya timer pause/resume.", listOf("pause", "resume")),
        CommandInfo("read_aloud", "Screen padho", "Screen ka visible text bolkar sunata hai.", listOf("is page ko padho", "padhkar sunao")),
        CommandInfo("explain_screen", "Screen samjhao", "Screen ka text rule-based summary mein batata hai.", listOf("screen par kya likha hai", "samjhao")),
        CommandInfo("explain_error", "Error ka matlab", "Common error text ka simple matlab.", listOf("is error ka matlab batao")),
        CommandInfo("summarize", "Summary", "Page ka chhota summary (AI nahi, rule-based).", listOf("summary do")),
        CommandInfo("copy", "Copy", "Selected text ya screen text copy.", listOf("is text ko copy karo", "copy karo")),
        CommandInfo("cut", "Cut", "Selected text cut.", listOf("cut karo")),
        CommandInfo("paste", "Paste", "Focus wale field mein paste.", listOf("paste karo")),
        CommandInfo("select_all", "Select all", "Field ka saara text select.", listOf("select all", "sab select karo")),
        CommandInfo("type_text", "Type karo", "Focus wale field mein text likhta hai (password field nahi).", listOf("type karo hello kaise ho")),
        CommandInfo("speak", "Bolo", "Diya hua text bolta hai.", listOf("bolo namaste", "speak hello")),
        CommandInfo("click", "Click / tap", "Screen par naam wale element ko dabata hai.", listOf("click karo Subscribe", "tap login")),
        CommandInfo("search", "Search", "Google ya YouTube par search (internet chahiye).", listOf("Physics lecture search karo", "youtube par arijit search karo")),
        CommandInfo("open_result", "Result kholo", "Search ka pehla/doosra result kholta hai.", listOf("pehla result kholo")),
        CommandInfo("settings_page", "Settings page", "Phone ke Settings pages.", listOf("wifi settings kholo", "bluetooth settings kholo", "battery settings kholo")),
        CommandInfo("message_draft", "Message draft", "Text taiyar karke share chooser kholta hai (khud nahi bhejta).", listOf("message draft karo", "Rahul ko message draft karo ki main late aaunga")),
        CommandInfo("send_message", "Message bhejo", "Contact dhundhta hai, preview dikhata hai, confirm ke baad WhatsApp/SMS bhejta hai.", listOf("Rahul ko whatsapp par message bhejo ki main late aaunga", "mummy ko sms bhejo ki call karna")),
        CommandInfo("remember", "Yaad rakho", "Aapke confirm karne par yaad rakhta hai (password/PIN nahi).", listOf("yaad rakho meri chai meethi hai")),
        CommandInfo("skill", "Skill chalao", "Aapki banayi skill chalata hai.", listOf("skill chalao Study Start")),
        CommandInfo("screenshot", "Screenshot", "Screenshot leta hai (Android 9+).", listOf("screenshot lo")),
        CommandInfo("notifications", "Notifications", "Notification shade kholta hai.", listOf("notification kholo")),
        CommandInfo("lock_screen", "Screen lock", "Phone lock karta hai (Android 9+).", listOf("lock screen karo")),
        CommandInfo("orb_go_home", "Orb home jaye", "Orb notch (top-center) mein chhup jata hai.", listOf("orbo andar jao", "chhup jao", "go to home")),
        CommandInfo("orb_come_out", "Orb bahar aaye", "Orb home se upar se girta hai.", listOf("bahar aao", "come from home")),
        CommandInfo("orb_sleep", "Orb so jaye", "Orb sleepy mode.", listOf("so jao", "get sleep")),
        CommandInfo("orb_wake", "Orb jaage", "Orb sleepy se jaag jata hai.", listOf("jaago", "wake up")),
    )
}
