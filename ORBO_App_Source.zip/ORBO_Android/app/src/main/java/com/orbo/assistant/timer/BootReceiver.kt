package com.orbo.assistant.timer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val missed = TimerManager.rescheduleAfterBoot()
        missed.forEach { Notifier.timerDone(context, it.label, true) }
    }
}
