package com.orbo.assistant.security

import android.os.Handler
import android.os.Looper
import com.orbo.assistant.agent.Assistant
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.core.PillAction
import com.orbo.assistant.core.PillKind
import com.orbo.assistant.face.FaceActivity
import com.orbo.assistant.face.FaceBus
import com.orbo.assistant.face.FaceGate
import com.orbo.assistant.orb.OrbState
import com.orbo.assistant.overlay.OrbOverlayService

/**
 * Unlock ke baad / protected app khulne par verification ladder:
 * Face -> (fail) Orb poochta hai -> Device Biometric -> (fail) poori screen ka PIN page.
 * Face fail hone par kisi ko "intruder" nahi kaha jata; failed-attempt count sirf PIN page par hota hai.
 */
object VerificationFlow {
    enum class Stage { IDLE, FACE, ASK, BIOMETRIC, PIN }

    @Volatile
    var stage: Stage = Stage.IDLE
        private set
    private var target: String? = null
    private var faceFromLock = false
    private val main = Handler(Looper.getMainLooper())

    fun active(): Boolean = stage != Stage.IDLE

    fun start(pkg: String?) {
        if (active()) return
        if (!PinManager.isSet()) return
        target = pkg
        faceFromLock = false
        PinManager.logEvent("VERIFY_START", if (pkg == null) "Unlock ke baad verification" else "Protected app: $pkg")
        Orbo.force(OrbState.VERIFICATION_PENDING)
        Orbo.say("Verification Required", PillKind.VERIFICATION, "Pehchaan ho rahi hai...")
        if (FaceGate.ready(Orbo.app)) {
            startFace(false)
        } else {
            nextAfterFace("Face ready nahi: ${FaceGate.status(Orbo.app)}")
        }
    }

    private fun startFace(fromLock: Boolean) {
        faceFromLock = fromLock
        stage = Stage.FACE
        Orbo.force(OrbState.VERIFICATION_PENDING)
        Orbo.say("Face check", PillKind.VERIFICATION, "Camera ki taraf dekho. Jo kahe wo karo (sar ghumao / palak jhapkao).")
        FaceBus.listener = { ok, msg -> main.post { onFaceResult(ok, msg) } }
        try {
            FaceActivity.launch(Orbo.app, FaceActivity.MODE_VERIFY)
        } catch (e: Exception) {
            FaceBus.listener = null
            onFaceResult(false, "Face screen khul nahi payi: ${e.message}")
        }
    }

    /** Lock page ke "Face" button se. */
    fun retryFace() {
        if (!FaceGate.ready(Orbo.app)) {
            OrbOverlayService.instance?.setLockMessage(FaceGate.status(Orbo.app) ?: "Face ready nahi.")
            return
        }
        OrbOverlayService.instance?.hideLock(keepFlow = true)
        startFace(true)
    }

    private fun onFaceResult(ok: Boolean, msg: String) {
        if (stage != Stage.FACE) return
        if (ok) {
            verified("Face")
            return
        }
        Orbo.force(OrbState.FACE_FAILED)
        if (faceFromLock) {
            showPin(msg)
        } else {
            nextAfterFace(msg)
        }
    }

    private fun nextAfterFace(reason: String) {
        stage = Stage.ASK
        val bio = BiometricHelper.availability(Orbo.app)
        val actions = ArrayList<PillAction>()
        if (bio.first) actions.add(PillAction("Fingerprint / Biometric") { startBiometric() })
        if (FaceGate.ready(Orbo.app)) actions.add(PillAction("Dobara Face") { startFace(false) })
        actions.add(PillAction("PIN") { showPin(null) })
        Orbo.say(
            "Face match nahi hua. Kya karun?", PillKind.VERIFICATION,
            reason + if (bio.first) "\n\nFingerprint se verify karein?" else "\n\nBiometric available nahi; PIN use karo.",
            actions,
        )
        if (Orbo.prefs.speakReplies) Assistant.speaker.speak(if (bio.first) "Face match nahi hua. Fingerprint lagao." else "Face match nahi hua. PIN daalo.")
        if (!bio.first && !FaceGate.ready(Orbo.app)) {
            // koi aasan raasta nahi: seedha PIN page
            showPin(reason)
        }
    }

    fun startBiometric() {
        stage = Stage.BIOMETRIC
        Orbo.force(OrbState.VERIFICATION_PENDING)
        Orbo.say("Fingerprint / Biometric", PillKind.VERIFICATION, "Sensor par ungli rakho.")
        OrbOverlayService.instance?.hideLock(keepFlow = true)
        try {
            BiometricActivity.launch(Orbo.app)
        } catch (e: Exception) {
            showPin("Biometric screen khul nahi payi.")
        }
    }

    fun onBiometricResult(ok: Boolean) {
        main.post {
            if (stage != Stage.BIOMETRIC) return@post
            if (ok) verified("Device Biometric") else showPin("Biometric verify nahi hua.")
        }
    }

    fun showPin(note: String?) {
        stage = Stage.PIN
        Orbo.force(OrbState.SECURITY_REQUIRED)
        Orbo.say("PIN chahiye", PillKind.VERIFICATION, note ?: "Poori screen ka verification page khul raha hai.")
        val svc = OrbOverlayService.instance
        if (svc != null) {
            svc.showLock(note)
        } else {
            SecurityActivity.launch(Orbo.app, target)
        }
    }

    fun verified(method: String) {
        val wasActive = active()
        stage = Stage.IDLE
        val p = Orbo.prefs
        p.verifiedUntil = System.currentTimeMillis() + p.graceMinutes * 60_000L
        PinManager.logEvent("VERIFIED", "Verify hua: $method")
        OrbOverlayService.instance?.hideLock(keepFlow = false)
        target = null
        Orbo.force(OrbState.VERIFIED)
        Orbo.say("Verified \u2713", PillKind.RESULT, "$method se verify hua.")
        if (wasActive && p.speakReplies) Assistant.speaker.speak("Verified")
        main.postDelayed({
            if (Orbo.machine.state.value == OrbState.VERIFIED) Orbo.force(OrbState.IDLE)
        }, 1800)
    }

    /** Optional quick-exit (settings mein ON ho to). */
    fun escape() {
        PinManager.logEvent("LOCK_ESCAPE", "Quick-exit se verification page band kiya (verify nahi hua)")
        stage = Stage.IDLE
        target = null
        OrbOverlayService.instance?.hideLock(keepFlow = false)
        Orbo.force(OrbState.IDLE)
        Orbo.say("Verification page band kiya", PillKind.RESULT, "Quick-exit use hua (verify nahi hua).")
    }

    fun reset() {
        stage = Stage.IDLE
        target = null
    }
}
