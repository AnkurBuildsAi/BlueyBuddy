package com.orbo.assistant.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.core.Stores
import com.orbo.assistant.face.FaceActivity
import com.orbo.assistant.face.FaceGate
import com.orbo.assistant.face.FaceModel
import com.orbo.assistant.face.FaceStore
import com.orbo.assistant.security.BiometricHelper
import com.orbo.assistant.security.PinManager
import com.orbo.assistant.security.PinResult
import com.orbo.assistant.security.SecurityActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SecurityTab(tick: Int, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = Orbo.prefs
    var rev by remember { mutableIntStateOf(0) }
    var pinSet by remember(rev, tick) { mutableStateOf(PinManager.isSet()) }
    var secOn by remember(rev, tick) { mutableStateOf(p.securityEnabled) }
    var unlockOn by remember(rev, tick) { mutableStateOf(p.verifyOnUnlock) }
    var comeOut by remember(rev) { mutableStateOf(p.comeOutOnUnlock) }
    var faceOn by remember(rev) { mutableStateOf(p.faceEnabled) }
    var escOn by remember(rev) { mutableStateOf(p.escapeEnabled) }
    var esc by remember(rev) { mutableStateOf(p.escapeCount.toFloat()) }
    var threshold by remember(rev) { mutableStateOf(p.failThreshold.toFloat()) }
    var grace by remember(rev) { mutableStateOf(p.graceMinutes.toFloat()) }
    var faceThr by remember(rev) { mutableStateOf(p.faceThreshold) }
    var preproc by remember(rev) { mutableStateOf(p.facePreproc) }
    var dialog by remember { mutableStateOf<String?>(null) } // set | remove | enroll | deleteFace
    var faceMsg by remember { mutableStateOf<String?>(null) }
    val bio = remember(tick) { BiometricHelper.availability(ctx) }
    val faceStatus = remember(rev, tick, faceOn) { FaceGate.status(ctx) }
    val enrolled = remember(rev, tick) { FaceStore.isEnrolled(ctx) }
    val hasModel = remember(rev, tick) { FaceModel.hasModel(ctx) }
    val events = remember(rev) { Stores.securityEvents.read().takeLast(20).reversed() }
    val fmt = remember { SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault()) }

    val pickModel = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            faceMsg = "Model check ho raha hai..."
            scope.launch {
                val err = withContext(Dispatchers.IO) { FaceModel.importFrom(ctx, uri) }
                faceMsg = err ?: "Model import ho gaya (${FaceModel.summary()}). Ab Face enroll karo."
                rev++
            }
        }
    }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Security", style = MaterialTheme.typography.headlineSmall)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("ORBO PIN: ${if (pinSet) "SET" else "NOT SET"}", style = MaterialTheme.typography.titleMedium)
                Text("PIN salted PBKDF2 verifier ke roop mein, Android Keystore se encrypt hoke store hota hai. Plaintext kabhi save nahi.", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { dialog = "set" }) { Text(if (pinSet) "PIN badlo" else "PIN set karo") }
                    if (pinSet) OutlinedButton(onClick = { dialog = "remove" }) { Text("PIN hatao") }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Face verification", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Status: " + (faceStatus ?: "READY"),
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (faceStatus == null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                )
                Text(
                    "Model: ${if (hasModel) "mila" else "nahi hai"}  |  Face enroll: ${if (enrolled) "ho chuka" else "nahi hua"}",
                    style = MaterialTheme.typography.bodySmall,
                )
                Text(
                    "Face model (MobileFaceNet jaisi .tflite, 112x112 input) ek baar import karni hoti hai: ya phone se yahan chuno, " +
                        "ya GitHub repo ke root mein `face_model.tflite` rakhkar APK dobara banao. Liveness: sar ghumao / palak jhapkao. " +
                        "Video replay se dhoka possible hai, isliye PIN/fingerprint backup rehte hain.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Face verification ON", Modifier.weight(1f))
                    Switch(checked = faceOn, onCheckedChange = { p.faceEnabled = it; faceOn = it })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pickModel.launch(arrayOf("*/*")) }) { Text("Model import") }
                    Button(enabled = pinSet && hasModel, onClick = { dialog = "enroll" }) { Text(if (enrolled) "Dobara enroll" else "Face enroll") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(enabled = enrolled && hasModel, onClick = { FaceActivity.launch(ctx, FaceActivity.MODE_TEST) }) { Text("Face test (score)") }
                    OutlinedButton(enabled = enrolled, onClick = { dialog = "deleteFace" }) { Text("Face delete") }
                }
                if (!pinSet) Text("Face enroll karne se pehle ORBO PIN set karo.", style = MaterialTheme.typography.bodySmall)
                Text("Match limit: ${"%.2f".format(faceThr)}  (kam = aasaan, zyada = sakht)", style = MaterialTheme.typography.bodySmall)
                Slider(value = faceThr, onValueChange = { faceThr = it }, valueRange = 0.30f..0.95f,
                    onValueChangeFinished = { p.faceThreshold = faceThr })
                Text("Image preprocessing (model ke hisaab se; Face test se score dekhkar chuno)", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "-1..1", 1 to "0..1", 2 to "ImageNet").forEach { (v, label) ->
                        FilterChip(selected = preproc == v, onClick = { preproc = v; p.facePreproc = v }, label = { Text(label) })
                    }
                }
                faceMsg?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Verification methods", style = MaterialTheme.typography.titleMedium)
                Text("1. Face: ${faceStatus ?: "ready"}", style = MaterialTheme.typography.bodySmall)
                Text("2. Device Biometric: ${bio.second}", style = MaterialTheme.typography.bodySmall)
                Text("3. ORBO PIN: ${if (pinSet) "ready" else "pehle PIN set karo"}", style = MaterialTheme.typography.bodySmall)
                OutlinedButton(enabled = pinSet, onClick = { SecurityActivity.launch(ctx, null) }) { Text("Security Page kholo (test)") }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Unlock ke baad verification (Face -> Fingerprint -> PIN page)", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    Switch(checked = unlockOn, enabled = pinSet, onCheckedChange = { p.verifyOnUnlock = it; unlockOn = it })
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Selected-app protection", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    Switch(checked = secOn, enabled = pinSet, onCheckedChange = { p.securityEnabled = it; secOn = it })
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Unlock par Orb home se bahar aaye (drop)", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    Switch(checked = comeOut, onCheckedChange = { p.comeOutOnUnlock = it; comeOut = it })
                }
                Text("Galat PIN limit: ${threshold.toInt()} (sirf ORBO ke PIN page ke attempts gine jaate hain)", style = MaterialTheme.typography.bodySmall)
                Slider(value = threshold, onValueChange = { threshold = it }, valueRange = 3f..10f, steps = 6,
                    onValueChangeFinished = { p.failThreshold = threshold.toInt() })
                Text("Verify ke baad grace (protected apps): ${grace.toInt()} minute", style = MaterialTheme.typography.bodySmall)
                Slider(value = grace, onValueChange = { grace = it }, valueRange = 0f..30f, steps = 29,
                    onValueChangeFinished = { p.graceMinutes = grace.toInt() })
                Text(
                    "PIN page poori screen ka overlay hai: Home/Back dabane par bhi upar rehta hai. Limits: notification shade, power button " +
                        "aur phone restart se bacha nahi ja sakta; Recents/gesture ko Android app ke liye 100% block nahi karta.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Quick-exit (optional, KHATRA)", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    Switch(checked = escOn, onCheckedChange = { p.escapeEnabled = it; escOn = it })
                }
                Text(
                    "ON hone par PIN page par khali input ke saath \u2713 ${esc.toInt()} baar dabane se page band ho jata hai " +
                        "(galti se page khule to bachne ke liye). Dhyan: ye chor ko bhi nikalne dega; isliye default OFF hai.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Slider(value = esc, onValueChange = { esc = it }, valueRange = 3f..10f, steps = 6,
                    onValueChangeFinished = { p.escapeCount = esc.toInt() })
            }
        }

        Text("Protected apps chuno", style = MaterialTheme.typography.titleMedium)
        Text(
            "Honest note: normal Android app arbitrary apps ko unbreakable lock nahi kar sakti. ORBO Accessibility se dekhta hai " +
                "ki selected app foreground mein aaya, aur tab verification chalata hai. Ye best-effort hai.",
            style = MaterialTheme.typography.bodySmall,
        )
        SelectedAppsSection(editable = true)

        Text("Security events", style = MaterialTheme.typography.titleMedium)
        if (events.isEmpty()) Text("Koi event nahi.", style = MaterialTheme.typography.bodySmall)
        events.forEach {
            Text("${fmt.format(Date(it.optLong("at")))}  ${it.optString("type")}: ${it.optString("note")}", style = MaterialTheme.typography.bodySmall)
        }
        OutlinedButton(onClick = { Stores.securityEvents.clear(); rev++ }, enabled = events.isNotEmpty()) { Text("Events clear karo") }
    }

    when (dialog) {
        "set" -> PinDialog(requireCurrent = pinSet, title = if (pinSet) "PIN badlo" else "PIN set karo", onDone = { dialog = null; rev++ })
        "remove" -> PinDialog(requireCurrent = true, title = "PIN hatao", removeMode = true, onDone = { dialog = null; rev++ })
        "enroll" -> PinConfirmDialog("Face enroll: PIN daalo", onCancel = { dialog = null }) {
            dialog = null
            FaceActivity.launch(ctx, FaceActivity.MODE_ENROLL)
        }
        "deleteFace" -> PinConfirmDialog("Face delete: PIN daalo", onCancel = { dialog = null }) {
            dialog = null
            FaceStore.delete(ctx)
            PinManager.logEvent("FACE_DELETED", "Face template delete kiya")
            rev++
        }
    }
}

@Composable
private fun PinConfirmDialog(title: String, onCancel: () -> Unit, onOk: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = pin, onValueChange = { if (it.length <= 12 && it.all { c -> c.isDigit() }) pin = it },
                    label = { Text("ORBO PIN") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                )
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when (val r = PinManager.verify(pin)) {
                    PinResult.Success -> onOk()
                    is PinResult.Wrong -> err = "Galat PIN (${r.failCount}/${r.threshold})."
                    is PinResult.Locked -> err = "Lockout chal raha hai, thodi der baad try karo."
                    PinResult.NotSet -> err = "PIN set nahi hai."
                    is PinResult.Error -> err = r.msg
                }
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } },
    )
}

@Composable
private fun PinDialog(requireCurrent: Boolean, title: String, removeMode: Boolean = false, onDone: () -> Unit) {
    var cur by remember { mutableStateOf("") }
    var n1 by remember { mutableStateOf("") }
    var n2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }

    @Composable
    fun field(v: String, label: String, set: (String) -> Unit) {
        OutlinedTextField(
            value = v, onValueChange = { if (it.length <= 12 && it.all { c -> c.isDigit() }) set(it) },
            label = { Text(label) }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        )
    }

    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (requireCurrent) field(cur, "Abhi ka PIN") { cur = it }
                if (!removeMode) {
                    Text("Naya PIN: kam se kam 6 digits.", style = MaterialTheme.typography.bodySmall)
                    field(n1, "Naya PIN") { n1 = it }
                    field(n2, "PIN dobara") { n2 = it }
                }
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (requireCurrent) {
                    when (val r = PinManager.verify(cur)) {
                        PinResult.Success -> {}
                        is PinResult.Wrong -> { err = "Abhi ka PIN galat (${r.failCount}/${r.threshold})."; return@TextButton }
                        is PinResult.Locked -> { err = "Lockout chal raha hai, thodi der baad try karo."; return@TextButton }
                        PinResult.NotSet -> {}
                        is PinResult.Error -> { err = r.msg; return@TextButton }
                    }
                }
                if (removeMode) {
                    PinManager.removePin()
                    onDone()
                    return@TextButton
                }
                if (n1 != n2) { err = "Dono PIN same nahi hain."; return@TextButton }
                val e = PinManager.setPin(n1)
                if (e == null) onDone() else err = e
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDone) { Text("Cancel") } },
    )
}
