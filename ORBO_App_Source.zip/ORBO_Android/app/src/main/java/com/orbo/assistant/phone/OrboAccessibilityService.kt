package com.orbo.assistant.phone

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.security.PinManager
import com.orbo.assistant.security.VerificationFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * User ne explicitly Settings se enable karna hota hai. Kaam: global actions, scroll/click/type,
 * visible text padhna (password fields skip), foreground package track karna, selected-app check.
 */
class OrboAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: OrboAccessibilityService? = null
        val foreground = MutableStateFlow("")

        fun isEnabledInSettings(ctx: Context): Boolean {
            val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            val me = ComponentName(ctx, OrboAccessibilityService::class.java).flattenToString()
            return enabled.split(':').any { it.equals(me, ignoreCase = true) }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == "com.android.systemui" || pkg.contains("inputmethod")) return
        foreground.value = pkg
        checkAppLock(pkg)
    }

    private fun checkAppLock(pkg: String) {
        try {
            val p = Orbo.prefs
            if (!p.securityEnabled || pkg == packageName) return
            if (pkg !in p.selectedApps || !PinManager.isSet()) return
            if (System.currentTimeMillis() < p.verifiedUntil) return
            if (VerificationFlow.active()) return
            VerificationFlow.start(pkg)
        } catch (e: Exception) {
            // lock check fail ho to app crash nahi hona chahiye
        }
    }

    // ---------- global actions ----------
    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)

    // ---------- tree helpers ----------
    /** Neeche wali app ka root (hamari apni overlay window nahi). */
    fun appRoot(): AccessibilityNodeInfo? {
        try {
            val ws = windows
            if (ws != null) {
                val apps = ws.filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }.sortedByDescending { it.layer }
                for (w in apps) {
                    val r = w.root ?: continue
                    if (r.packageName?.toString() != packageName) return r
                }
            }
        } catch (e: Exception) {
        }
        val r = rootInActiveWindow
        return if (r != null && r.packageName?.toString() != packageName) r else null
    }

    fun visibleText(): String {
        val root = appRoot() ?: return ""
        val sb = StringBuilder()
        val seen = HashSet<String>()
        var count = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40 || count > 3000 || sb.length > 20000) return
            count++
            if (!n.isVisibleToUser) return
            if (!n.isPassword) {
                val t = (n.text ?: n.contentDescription)?.toString()?.trim()
                if (!t.isNullOrEmpty() && seen.add(t)) sb.append(t).append('\n')
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return sb.toString().trim()
    }

    fun textHash(): Int = visibleText().hashCode()

    /** Click hone layak, lambe text wale nodes (search result links jaise). */
    fun candidateLinks(): List<AccessibilityNodeInfo> {
        val root = appRoot() ?: return emptyList()
        val out = mutableListOf<AccessibilityNodeInfo>()
        var count = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40 || count > 3000) return
            count++
            if (!n.isVisibleToUser || n.isPassword) return
            val t = (n.text ?: n.contentDescription)?.toString().orEmpty()
            if (t.length >= 20 && (n.isClickable || isInsideClickable(n))) out.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return out
    }

    private fun isInsideClickable(n: AccessibilityNodeInfo): Boolean {
        var p = n.parent
        var d = 0
        while (p != null && d < 5) {
            if (p.isClickable) return true
            p = p.parent
            d++
        }
        return false
    }

    fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        var d = 0
        while (cur != null && d < 6) {
            if (cur.isClickable && cur.isEnabled) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
            d++
        }
        return false
    }

    fun clickByText(text: String): Boolean {
        val root = appRoot() ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(text) ?: return false
        for (n in nodes) {
            if (n.isVisibleToUser && !n.isPassword && clickNode(n)) return true
        }
        return false
    }

    fun scrollable(): AccessibilityNodeInfo? {
        val root = appRoot() ?: return null
        var best: AccessibilityNodeInfo? = null
        var bestArea = -1
        val r = Rect()
        var count = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40 || count > 3000) return
            count++
            if (n.isScrollable && n.isVisibleToUser) {
                n.getBoundsInScreen(r)
                val area = r.width() * r.height()
                if (area > bestArea) {
                    bestArea = area
                    best = n
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return best
    }

    fun scroll(down: Boolean): Boolean {
        val n = scrollable() ?: return false
        return n.performAction(if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    suspend fun swipe(down: Boolean): Boolean {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val y1 = dm.heightPixels * (if (down) 0.70f else 0.30f)
        val y2 = dm.heightPixels * (if (down) 0.30f else 0.70f)
        val path = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 300)).build()
        return suspendCancellableCoroutine { cont ->
            val started = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(false)
                }
            }, null)
            if (!started && cont.isActive) cont.resume(false)
        }
    }

    fun focusedInput(): AccessibilityNodeInfo? = appRoot()?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)

    /** @return null = ok, warna error message */
    fun typeText(text: String): String? {
        val n = focusedInput() ?: return "Koi text field focus mein nahi hai. Pehle field par tap karo."
        if (n.isPassword) return "Password field mein main type nahi karta."
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        if (!n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return "Is field mein text set nahi ho paya."
        n.refresh()
        return if (n.text?.toString() == text) null else "Text set request gayi par field mein dikha nahi (verify fail)."
    }

    fun copySelection(): Boolean {
        val n = focusedInput() ?: return false
        return n.performAction(AccessibilityNodeInfo.ACTION_COPY)
    }

    fun pasteIntoFocused(): Boolean {
        val n = focusedInput() ?: return false
        if (n.isPassword) return false
        return n.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    fun globalAction(action: Int): Boolean = performGlobalAction(action)

    fun cutSelection(): Boolean {
        val n = focusedInput() ?: return false
        if (n.isPassword) return false
        return n.performAction(AccessibilityNodeInfo.ACTION_CUT)
    }

    fun selectAllText(): Boolean {
        val n = focusedInput() ?: return false
        if (n.isPassword) return false
        val len = n.text?.length ?: return false
        val args = Bundle().apply {
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, len)
        }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, args)
    }

    suspend fun swipeDir(dir: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val path = Path()
        when (dir) {
            "left" -> { path.moveTo(w * 0.8f, h * 0.5f); path.lineTo(w * 0.2f, h * 0.5f) }
            "right" -> { path.moveTo(w * 0.2f, h * 0.5f); path.lineTo(w * 0.8f, h * 0.5f) }
            "up" -> { path.moveTo(w * 0.5f, h * 0.7f); path.lineTo(w * 0.5f, h * 0.3f) }
            else -> { path.moveTo(w * 0.5f, h * 0.3f); path.lineTo(w * 0.5f, h * 0.7f) }
        }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 300)).build()
        return suspendCancellableCoroutine { cont ->
            val started = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(false)
                }
            }, null)
            if (!started && cont.isActive) cont.resume(false)
        }
    }
}
