package com.orbo.assistant.face

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.orb.OrbState
import com.orbo.assistant.security.PinManager
import com.orbo.assistant.ui.OrbView
import com.orbo.assistant.ui.theme.OrbTheme
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Face result ko Verification flow / Security page tak pahunchane ke liye. */
object FaceBus {
    @Volatile
    var listener: ((Boolean, String) -> Unit)? = null
}

/** Camera preview ke saath face enroll / verify / test. Camera sirf tabhi chalta hai jab ye screen dikh rahi ho. */
class FaceActivity : ComponentActivity() {

    companion object {
        const val MODE_ENROLL = "ENROLL"
        const val MODE_VERIFY = "VERIFY"
        const val MODE_TEST = "TEST"
        private const val EXTRA_MODE = "mode"

        fun launch(ctx: Context, mode: String) {
            ctx.startActivity(
                Intent(ctx, FaceActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra(EXTRA_MODE, mode),
            )
        }
    }

    private lateinit var mode: String
    private lateinit var previewView: PreviewView
    private lateinit var executor: ExecutorService
    private var session: FaceSession? = null
    private var provider: ProcessCameraProvider? = null
    private var reported = false
    private val main = Handler(Looper.getMainLooper())

    private var status by mutableStateOf("Camera taiyar ho raha hai...")
    private var progress by mutableFloatStateOf(0f)
    private var finalOk by mutableStateOf<Boolean?>(null)

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) beginSession() else report(false, "Camera permission nahi mili.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_TEST
        executor = Executors.newSingleThreadExecutor()
        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        setContent {
            OrbTheme {
                FaceScreen()
            }
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            beginSession()
        } else {
            permLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun beginSession() {
        val err = FaceModel.load(this)
        if (err != null) {
            report(false, err)
            return
        }
        val templates: List<FloatArray> = if (mode == MODE_ENROLL) emptyList() else {
            val t = FaceStore.load(this)
            if (t == null || t.isEmpty() || t[0].size != FaceModel.dim) {
                report(false, "Face enroll nahi hua (ya model badal gaya hai). Security tab se dobara enroll karo.")
                return
            }
            t
        }
        val m = when (mode) {
            MODE_ENROLL -> FaceSession.Mode.ENROLL
            MODE_VERIFY -> FaceSession.Mode.VERIFY
            else -> FaceSession.Mode.TEST
        }
        val s = FaceSession(
            this, m, templates, Orbo.prefs.faceThreshold, Orbo.prefs.facePreproc,
            object : FaceSession.Listener {
                override fun onStatus(msg: String, progress: Float, score: Float?) {
                    main.post {
                        status = msg
                        this@FaceActivity.progress = progress
                    }
                }

                override fun onFinished(ok: Boolean, msg: String, samples: List<FloatArray>?) {
                    main.post { onSessionDone(ok, msg, samples) }
                }
            },
        )
        session = s
        startCamera(s)
    }

    private fun startCamera(s: FaceSession) {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            try {
                val p = f.get()
                provider = p
                val preview = Preview.Builder().build()
                preview.setSurfaceProvider(previewView.surfaceProvider)
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(executor) { img -> s.analyze(img) }
                p.unbindAll()
                p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis)
            } catch (e: Exception) {
                report(false, "Front camera nahi khul paya: ${e.message ?: "unknown"}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onSessionDone(ok: Boolean, msg: String, samples: List<FloatArray>?) {
        if (mode == MODE_ENROLL && ok && samples != null) {
            try {
                FaceStore.save(this, samples)
                Orbo.prefs.faceThreshold = session?.suggestedThreshold ?: 0.65f
                PinManager.logEvent("FACE_ENROLLED", "Face template save hua (sirf encrypted numbers)")
            } catch (e: Exception) {
                report(false, "Face save nahi ho paya: ${e.message}")
                return
            }
        }
        report(ok, msg)
    }

    private fun report(ok: Boolean, msg: String) {
        if (reported) return
        reported = true
        status = msg
        finalOk = ok
        session?.stop()
        if (mode == MODE_VERIFY) {
            val l = FaceBus.listener
            FaceBus.listener = null
            l?.invoke(ok, msg)
        }
        main.postDelayed({ finish() }, if (ok) 700L else 1600L)
    }

    private fun cancel() {
        if (mode == MODE_VERIFY) {
            report(false, "Cancel kiya.")
        } else {
            finish()
        }
    }

    override fun onDestroy() {
        session?.release()
        try { provider?.unbindAll() } catch (e: Exception) { }
        executor.shutdown()
        if (mode == MODE_VERIFY && !reported) {
            val l = FaceBus.listener
            FaceBus.listener = null
            l?.invoke(false, "Face screen band ho gayi.")
        }
        super.onDestroy()
    }

    @Composable
    private fun FaceScreen() {
        val orb by Orbo.machine.state.collectAsState()
        val shownState = when {
            finalOk == true && mode == MODE_VERIFY -> OrbState.VERIFIED
            finalOk == false && mode == MODE_VERIFY -> OrbState.FACE_FAILED
            mode == MODE_VERIFY -> orb
            else -> OrbState.IDLE
        }
        Box(
            Modifier.fillMaxSize().background(if (mode == MODE_VERIFY) Color(0xF2070B1A) else Color(0xFF070B1A)).safeDrawingPadding(),
        ) {
            Column(
                Modifier.fillMaxSize().padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
            ) {
                OrbView(state = shownState, orbSize = 72.dp, reducedMotion = Orbo.prefs.reducedMotion)
                Text(
                    when (mode) {
                        MODE_ENROLL -> "Face enroll"
                        MODE_VERIFY -> "Face verification"
                        else -> "Face test"
                    },
                    style = MaterialTheme.typography.headlineSmall,
                )
                Box(
                    Modifier.size(240.dp).clip(CircleShape).border(3.dp, MaterialTheme.colorScheme.primary, CircleShape),
                ) {
                    AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                }
                Text(status, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
                if (mode == MODE_ENROLL) {
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                }
                Text(
                    "Camera sirf is screen ke dauran chalta hai. Photo save nahi hoti; sirf encrypted numbers.",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                )
                if (mode == MODE_TEST) {
                    OutlinedButton(onClick = { finish() }) { Text("Band karo") }
                } else {
                    Button(onClick = { cancel() }) { Text("Cancel") }
                }
            }
        }
    }
}
