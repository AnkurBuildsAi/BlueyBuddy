package com.orbo.assistant.overlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.orbo.assistant.MainActivity
import com.orbo.assistant.R
import com.orbo.assistant.agent.Assistant
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.core.PillAction
import com.orbo.assistant.core.PillKind
import com.orbo.assistant.core.PillStatus
import com.orbo.assistant.orb.OrbState
import com.orbo.assistant.orb.OrbTimings
import com.orbo.assistant.security.PinManager
import com.orbo.assistant.security.PinResult
import com.orbo.assistant.security.VerificationFlow
import com.orbo.assistant.timer.Notifier
import com.orbo.assistant.timer.TimerManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Floating Orb + Smart Pill + notch "home" + edge docking + poori-screen verification page (overlay).
 * Lock screen par Android normal app ka overlay dikhane nahi deta: isliye Orb unlock ke BAAD upar se girta hai.
 */
class OrbOverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.orbo.assistant.STOP_OVERLAY"
        const val ACTION_COME_OUT = "com.orbo.assistant.COME_OUT"
        private const val NOTIF_ID = 1001

        @Volatile
        var instance: OrbOverlayService? = null

        fun start(ctx: Context) {
            Orbo.prefs.overlayEnabled = true
            ContextCompat.startForegroundService(ctx, Intent(ctx, OrbOverlayService::class.java))
        }

        fun stop(ctx: Context) {
            Orbo.prefs.overlayEnabled = false
            ctx.stopService(Intent(ctx, OrbOverlayService::class.java))
        }
    }

    private class MaxHeightScroll(c: Context, private val maxH: Int) : ScrollView(c) {
        override fun onMeasure(w: Int, h: Int) {
            super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST))
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var root: LinearLayout
    private lateinit var header: LinearLayout
    private lateinit var headerLp: LinearLayout.LayoutParams
    private lateinit var orbLp: LinearLayout.LayoutParams
    private lateinit var orb: OrbCanvasView
    private lateinit var status: TextView
    private lateinit var mic: TextView
    private lateinit var arrow: TextView
    private lateinit var body: LinearLayout
    private lateinit var detail: TextView
    private lateinit var actionsRow: LinearLayout
    private lateinit var input: EditText
    private lateinit var bg: GradientDrawable

    private var built = false
    private var orbPx = 0
    private var boxPx = 0
    private var padPx = 0
    private var pillMode = false
    private var expanded = false
    private var dock = 0 // 0 none, 1 left, 2 right, 3 top, 4 bottom
    private var homeHidden = false
    private var lastKind = PillKind.IDLE
    private var hasActions = false

    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var morphAnim: ValueAnimator? = null
    private var posAnim: ValueAnimator? = null

    // hotspot (notch ke neeche chhota tap-spot)
    private var hotspot: View? = null

    // lock overlay
    private var lockRoot: FrameLayout? = null
    private var lockOrb: OrbCanvasView? = null
    private var lockStatus: TextView? = null
    private var lockDots: TextView? = null
    private val pinBuf = StringBuilder()
    private var escapeTaps = 0
    private var lockJob: Job? = null
    private var lockedUntil = 0L
    private var verifying = false

    // gesture state
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false
    private var longFired = false
    private var vt: VelocityTracker? = null
    private val longTask = Runnable {
        if (!moved) {
            longFired = true
            root.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            if (dock != 0) undock(false)
            orb.jiggle(12f)
            showPill()
            Assistant.startVoice()
        }
    }
    private val collapseTask = Runnable {
        if (!expanded && !hasActions && lastKind != PillKind.LISTENING && lastKind != PillKind.THINKING &&
            lastKind != PillKind.EXECUTING && lastKind != PillKind.VERIFICATION
        ) collapsePill()
    }
    private val sleepTask = Runnable {
        if (Orbo.prefs.sleepyEnabled && Orbo.machine.state.value == OrbState.IDLE) Orbo.force(OrbState.SLEEPY)
    }
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> onScreenOff()
                Intent.ACTION_USER_PRESENT -> onUnlocked()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Orbo.prefs.overlayEnabled = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent == null && !Orbo.prefs.overlayEnabled) {
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        if (!Settings.canDrawOverlays(this)) {
            Orbo.prefs.overlayEnabled = false
            Orbo.say("Overlay permission chahiye", PillKind.ERROR, "Android Settings mein 'Display over other apps' allow karo.")
            stopSelf()
            return START_NOT_STICKY
        }
        if (!built) {
            try {
                build()
            } catch (e: Exception) {
                Orbo.prefs.overlayEnabled = false
                Orbo.say("Orb overlay nahi bana", PillKind.ERROR, e.message ?: "unknown error")
                stopSelf()
                return START_NOT_STICKY
            }
        }
        if (intent?.action == ACTION_COME_OUT) comeOut(true)
        return START_STICKY
    }

    private fun startFg() {
        Notifier.ensureChannels(this)
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, OrbOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val outPi = PendingIntent.getService(
            this, 3, Intent(this, OrbOverlayService::class.java).setAction(ACTION_COME_OUT),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val openPi = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(this, Notifier.CH_OVERLAY)
            .setSmallIcon(R.drawable.ic_stat_orbo)
            .setContentTitle("ORBO Orb chalu hai")
            .setContentText("Orb home mein ho to 'Orb bulao' dabao.")
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(0, "Orb bulao", outPi)
            .addAction(0, "Orb band karo", stopPi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------------------------------------------------------------- helpers
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** [width, height, topInset, bottomInset] */
    private fun bounds(): IntArray {
        if (Build.VERSION.SDK_INT >= 30) {
            val m = wm.currentWindowMetrics
            val ins = m.windowInsets.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            return intArrayOf(m.bounds.width(), m.bounds.height(), ins.top, ins.bottom)
        }
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        val sb = if (id > 0) resources.getDimensionPixelSize(id) else dp(24)
        return intArrayOf(dm.widthPixels, dm.heightPixels, sb, 0)
    }

    private fun applyParams() {
        try {
            if (root.isAttachedToWindow) wm.updateViewLayout(root, params)
        } catch (e: Exception) {
        }
    }

    private fun clampAndApply() {
        if (dock != 0 || homeHidden) {
            applyParams()
            return
        }
        val b = bounds()
        val w = if (root.width > 0) root.width else boxPx
        val h = if (root.height > 0) root.height else boxPx
        val px = if (pillMode) 0 else padPx
        params.x = params.x.coerceIn(-px, max(-px, b[0] - w + px))
        params.y = params.y.coerceIn(b[2] - px, max(b[2] - px, b[1] - b[3] - h + px))
        applyParams()
    }

    private fun chip(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.parseColor("#00121F"))
        textSize = 14f
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#2EA8FF"))
            cornerRadius = dp(16).toFloat()
        }
        setOnClickListener { onClick() }
    }

    private fun iconText(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 20f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(10), dp(10), dp(10))
        visibility = View.GONE
        setOnClickListener { onClick() }
    }

    private fun reduced(): Boolean = Orbo.prefs.reducedMotion

    private fun animateTo(tx: Int, ty: Int, dur: Long, interp: TimeInterpolator, onEnd: (() -> Unit)? = null) {
        posAnim?.cancel()
        val fx = params.x
        val fy = params.y
        val a = ValueAnimator.ofFloat(0f, 1f)
        var cancelled = false
        a.duration = if (reduced()) 0L else dur
        a.interpolator = interp
        a.addUpdateListener {
            val f = it.animatedValue as Float
            params.x = (fx + (tx - fx) * f).toInt()
            params.y = (fy + (ty - fy) * f).toInt()
            applyParams()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (posAnim === a) posAnim = null
                if (!cancelled) onEnd?.invoke()
            }
        })
        posAnim = a
        a.start()
    }

    // ---------------------------------------------------------------- build
    private fun build() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val p = Orbo.prefs
        orbPx = dp(p.orbSizeDp)
        boxPx = (orbPx * 1.5f).toInt()
        padPx = (boxPx - orbPx) / 2

        bg = GradientDrawable().apply {
            setColor(Color.parseColor("#E60B1230"))
            cornerRadius = dp(32).toFloat()
            alpha = 0
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
        }
        header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        orb = OrbCanvasView(this).apply { reducedMotion = p.reducedMotion }
        orbLp = LinearLayout.LayoutParams(boxPx, boxPx)
        header.addView(orb, orbLp)

        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(4), 0, dp(4), 0)
            visibility = View.GONE
        }
        header.addView(status, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        mic = iconText("\uD83C\uDFA4") { Assistant.startVoice() }
        arrow = iconText("\u25BC") { setExpanded(!expanded) }
        header.addView(mic)
        header.addView(arrow)

        headerLp = LinearLayout.LayoutParams(boxPx, boxPx)
        root.addView(header, headerLp)

        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(12))
            visibility = View.GONE
        }
        val scroll = MaxHeightScroll(this, dp(200))
        detail = TextView(this).apply {
            setTextColor(Color.parseColor("#DDE6FF"))
            textSize = 14f
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        scroll.addView(detail)
        body.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        actionsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val actionsScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(actionsRow)
        }
        body.addView(actionsScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })

        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "Command likho..."
            setHintTextColor(Color.parseColor("#8894B8"))
            setTextColor(Color.WHITE)
            textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            maxLines = 1
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    sendInput()
                    true
                } else false
            }
        }
        inputRow.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val send = chip("Send") { sendInput() }
        val stop = chip("Stop") { Assistant.stopAll("Stop kar diya") }
        inputRow.addView(send, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(6) })
        inputRow.addView(stop, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(6) })
        body.addView(inputRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        root.addView(body, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }
        val b = bounds()
        params.x = if (p.orbX != Int.MIN_VALUE) p.orbX else (b[0] - boxPx) / 2
        params.y = if (p.orbY != Int.MIN_VALUE) p.orbY else b[2] + dp(8) - padPx
        dock = p.dockEdge
        homeHidden = p.homeHidden

        root.setOnTouchListener { _, ev -> onTouch(ev) }
        wm.addView(root, params)
        built = true
        if (dock != 0) root.alpha = 0.55f
        if (homeHidden) {
            root.visibility = View.GONE
            showHotspot()
        }
        root.post { clampAndApply() }

        val f = IntentFilter()
        f.addAction(Intent.ACTION_SCREEN_OFF)
        f.addAction(Intent.ACTION_USER_PRESENT)
        ContextCompat.registerReceiver(this, screenReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)

        scope.launch {
            Orbo.machine.state.collect { s ->
                orb.setOrbState(s)
                lockOrb?.setOrbState(s)
                if (s != OrbState.SLEEPY) resetSleepTimer()
            }
        }
        scope.launch { Orbo.pill.collect { applyPill(it) } }
        scope.launch {
            while (isActive) {
                delay(1000)
                tickTimer()
            }
        }
        resetSleepTimer()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        morphAnim?.cancel()
        posAnim?.cancel()
        lockJob?.cancel()
        scope.cancel()
        try { unregisterReceiver(screenReceiver) } catch (e: Exception) { }
        if (built) {
            removeLockView()
            hideHotspot()
            try { wm.removeView(root) } catch (e: Exception) { }
            built = false
        }
        VerificationFlow.reset()
        instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- pill content
    private fun applyPill(p: PillStatus) {
        if (!built) return
        lastKind = p.kind
        status.text = p.text
        detail.text = p.detail
        detail.visibility = if (p.detail.isBlank()) View.GONE else View.VISIBLE
        actionsRow.removeAllViews()
        hasActions = p.actions.isNotEmpty()
        for (a: PillAction in p.actions) {
            actionsRow.addView(chip(a.label) { a.run() }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(6) })
        }
        if (p.kind == PillKind.IDLE || lockRoot != null) return
        if (homeHidden) {
            if (p.kind == PillKind.VERIFICATION) comeOut(true) else return
        }
        showPill()
        if (hasActions && !expanded) setExpanded(true)
        handler.removeCallbacks(collapseTask)
        handler.postDelayed(collapseTask, 8000)
    }

    private fun tickTimer() {
        if (!built || !pillMode || lastKind != PillKind.TIMER) return
        val t = TimerManager.active().firstOrNull() ?: return
        status.text = TimerManager.format(TimerManager.remainingMs(t)) + " remaining"
    }

    private fun sendInput() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        hideKeyboard()
        Assistant.submit(t)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(root.windowToken, 0)
    }

    // ---------------------------------------------------------------- morph / expand
    private fun showPill() {
        if (dock != 0) undock(false)
        if (pillMode) return
        if (!reduced()) {
            root.animate().scaleX(0.9f).scaleY(0.9f).setDuration(100).withEndAction {
                root.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                morphTo(true)
            }.start()
        } else {
            morphTo(true)
        }
    }

    private fun collapsePill() {
        if (expanded) setExpanded(false)
        morphTo(false)
    }

    private fun morphTo(pill: Boolean) {
        if (pillMode == pill && morphAnim == null) return
        pillMode = pill
        morphAnim?.cancel()
        val b = bounds()
        val pillW = min((b[0] * 0.85f).toInt(), dp(360))
        val pillH = dp(60)
        val fromW = headerLp.width
        val fromH = headerLp.height
        val fromO = orbLp.width
        val toW = if (pill) pillW else boxPx
        val toH = if (pill) pillH else boxPx
        val toO = if (pill) pillH else boxPx
        if (pill) {
            status.visibility = View.VISIBLE
            mic.visibility = View.VISIBLE
            arrow.visibility = View.VISIBLE
        }
        val fromA = bg.alpha
        val toA = if (pill) 255 else 0
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = if (reduced()) 0L else OrbTimings.MORPH_MS.toLong()
        a.interpolator = AccelerateDecelerateInterpolator()
        a.addUpdateListener {
            val f = it.animatedValue as Float
            headerLp.width = (fromW + (toW - fromW) * f).toInt()
            headerLp.height = (fromH + (toH - fromH) * f).toInt()
            orbLp.width = (fromO + (toO - fromO) * f).toInt()
            orbLp.height = orbLp.width
            header.layoutParams = headerLp
            orb.layoutParams = orbLp
            bg.alpha = (fromA + (toA - fromA) * f).toInt()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                morphAnim = null
                if (!pill) {
                    status.visibility = View.GONE
                    mic.visibility = View.GONE
                    arrow.visibility = View.GONE
                }
                root.post { clampAndApply() }
            }
        })
        morphAnim = a
        a.start()
    }

    private fun setExpanded(v: Boolean) {
        expanded = v
        if (v) {
            body.visibility = View.VISIBLE
            body.alpha = 0f
            body.animate().alpha(1f).setDuration(180).start()
            arrow.text = "\u25B2"
            params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        } else {
            body.visibility = View.GONE
            arrow.text = "\u25BC"
            hideKeyboard()
            params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        applyParams()
        root.post { clampAndApply() }
    }

    // ---------------------------------------------------------------- dock / home
    private fun bodyPosForDock(edge: Int, curX: Int, curY: Int): IntArray {
        val b = bounds()
        val hidden = (orbPx * 0.55f).toInt()
        var x = curX
        var y = curY
        when (edge) {
            1 -> x = -hidden - padPx
            2 -> x = b[0] + hidden - (boxPx + orbPx) / 2
            3 -> y = -hidden - padPx
            4 -> y = b[1] + hidden - (boxPx + orbPx) / 2
        }
        return intArrayOf(x, y)
    }

    private fun enterDock(edge: Int) {
        if (pillMode) return
        dock = edge
        Orbo.prefs.dockEdge = edge
        val t = bodyPosForDock(edge, params.x, params.y)
        root.animate().alpha(0.55f).setDuration(250).start()
        animateTo(t[0], t[1], 260, OvershootInterpolator(1.6f)) {
            Orbo.prefs.orbX = params.x
            Orbo.prefs.orbY = params.y
            orb.jiggle(8f)
        }
    }

    private fun undock(animate: Boolean) {
        if (dock == 0) return
        val edge = dock
        dock = 0
        Orbo.prefs.dockEdge = 0
        root.animate().alpha(1f).setDuration(200).start()
        val b = bounds()
        val m = dp(12)
        var x = params.x
        var y = params.y
        when (edge) {
            1 -> x = m - padPx
            2 -> x = b[0] - m - orbPx - padPx
            3 -> y = b[2] + m - padPx
            4 -> y = b[1] - b[3] - m - orbPx - padPx
        }
        if (animate && !reduced()) {
            animateTo(x, y, 300, OvershootInterpolator(1.8f)) {
                Orbo.prefs.orbX = params.x
                Orbo.prefs.orbY = params.y
                orb.jiggle(10f)
            }
        } else {
            params.x = x
            params.y = y
            Orbo.prefs.orbX = x
            Orbo.prefs.orbY = y
            applyParams()
        }
    }

    fun isHomeHidden(): Boolean = homeHidden

    /** Orb notch (top-center) ke andar chala jaye. */
    fun goHome(animated: Boolean = true) {
        if (!built || homeHidden) return
        if (lockRoot != null) return
        if (pillMode) {
            if (expanded) setExpanded(false)
            morphTo(false)
        }
        homeHidden = true
        Orbo.prefs.homeHidden = true
        val b = bounds()
        val tx = (b[0] - boxPx) / 2
        val ty = -boxPx
        val finish = {
            root.visibility = View.GONE
            root.scaleX = 1f
            root.scaleY = 1f
            showHotspot()
        }
        if (animated && !reduced()) {
            root.animate().scaleX(0.3f).scaleY(0.3f).alpha(0f).setDuration(300).start()
            animateTo(tx, ty, 300, AccelerateInterpolator(1.2f)) { finish() }
        } else {
            finish()
        }
    }

    /** Orb home se bahar: upar se liquid ki tarah girke thoda piche, phir theek. */
    fun comeOut(drop: Boolean = true) {
        if (!built || !homeHidden) return
        homeHidden = false
        Orbo.prefs.homeHidden = false
        dock = 0
        Orbo.prefs.dockEdge = 0
        hideHotspot()
        val b = bounds()
        val tx = if (Orbo.prefs.orbX != Int.MIN_VALUE) Orbo.prefs.orbX.coerceIn(-padPx, b[0] - boxPx + padPx) else (b[0] - boxPx) / 2
        val tyRaw = if (Orbo.prefs.orbY != Int.MIN_VALUE) Orbo.prefs.orbY else b[2] + dp(8) - padPx
        val ty = tyRaw.coerceIn(b[2] - padPx, max(b[2] - padPx, b[1] - b[3] - boxPx + padPx))
        params.x = tx
        params.y = -boxPx
        root.scaleX = 1f
        root.scaleY = 1f
        root.alpha = 1f
        root.visibility = View.VISIBLE
        applyParams()
        if (!drop || reduced()) {
            params.y = ty
            applyParams()
            return
        }
        val over = (boxPx * 0.22f).toInt()
        animateTo(tx, ty + over, (OrbTimings.DROP_MS * 0.6f).toLong(), AccelerateInterpolator(1.5f)) {
            orb.playSquash()
            animateTo(tx, ty, (OrbTimings.BOUNCE_MS * 1.4f).toLong(), OvershootInterpolator(2.2f)) {
                orb.jiggle(10f)
            }
        }
    }

    private fun showHotspot() {
        if (hotspot != null || !built) return
        val c = FrameLayout(this)
        val dot = View(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(4).toFloat()
                setColor(Color.parseColor("#662EA8FF"))
                setStroke(dp(1), Color.parseColor("#992EA8FF"))
            }
        }
        c.addView(dot, FrameLayout.LayoutParams(dp(56), dp(6), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(2) })
        c.setOnClickListener { comeOut(true) }
        val lp = WindowManager.LayoutParams(
            dp(96), dp(34),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = bounds()[2]
        }
        try {
            wm.addView(c, lp)
            hotspot = c
        } catch (e: Exception) {
        }
    }

    private fun hideHotspot() {
        val h = hotspot ?: return
        try { wm.removeView(h) } catch (e: Exception) { }
        hotspot = null
    }

    // ---------------------------------------------------------------- gestures
    private fun orbLocal(ev: MotionEvent): FloatArray {
        val loc = IntArray(2)
        orb.getLocationOnScreen(loc)
        return floatArrayOf(ev.rawX - loc[0], ev.rawY - loc[1])
    }

    private fun onTouch(ev: MotionEvent): Boolean {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX
                downY = ev.rawY
                startX = params.x
                startY = params.y
                moved = false
                longFired = false
                posAnim?.cancel()
                vt?.recycle()
                vt = VelocityTracker.obtain().also { it.addMovement(ev) }
                if (Orbo.machine.state.value == OrbState.SLEEPY) Orbo.force(OrbState.IDLE)
                resetSleepTimer()
                val l = orbLocal(ev)
                orb.look(l[0], l[1])
                handler.postDelayed(longTask, Orbo.prefs.longPressMs)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(ev)
                val dx = ev.rawX - downX
                val dy = ev.rawY - downY
                if (!moved && hypot(dx, dy) > slop) {
                    moved = true
                    handler.removeCallbacks(longTask)
                    if (dock != 0) {
                        dock = 0
                        Orbo.prefs.dockEdge = 0
                        root.animate().alpha(1f).setDuration(150).start()
                    }
                }
                if (moved && !longFired) {
                    params.x = startX + dx.toInt()
                    params.y = startY + dy.toInt()
                    clampAndApply()
                }
                val l = orbLocal(ev)
                orb.look(l[0], l[1])
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longTask)
                val tracker = vt
                tracker?.addMovement(ev)
                tracker?.computeCurrentVelocity(1000)
                val vx = tracker?.xVelocity ?: 0f
                val vy = tracker?.yVelocity ?: 0f
                tracker?.recycle()
                vt = null
                if (longFired) return true
                if (!moved) {
                    if (dock != 0) {
                        undock(true)
                    } else if (!pillMode) {
                        val l = orbLocal(ev)
                        orb.tap(l[0], l[1])
                    }
                    return true
                }
                if (pillMode) {
                    Orbo.prefs.orbX = params.x
                    Orbo.prefs.orbY = params.y
                    return true
                }
                val dx = ev.rawX - downX
                val dy = ev.rawY - downY
                val vertical = abs(dy) > abs(dx) && abs(vy) > abs(vx) * 1.5f
                val b = bounds()
                val bodyL = params.x + padPx
                val bodyR = bodyL + orbPx
                val bodyT = params.y + padPx
                val bodyB = bodyT + orbPx
                val cxBody = params.x + boxPx / 2
                val thr = dp(26)
                when {
                    abs(cxBody - b[0] / 2) < dp(64) && bodyT < b[2] + dp(56) -> goHome(true)
                    vertical && vy < -dp(900) -> enterDock(3)
                    bodyL < thr -> enterDock(1)
                    b[0] - bodyR < thr -> enterDock(2)
                    bodyT < thr -> enterDock(3)
                    b[1] - bodyB < thr -> enterDock(4)
                    else -> {
                        Orbo.prefs.orbX = params.x
                        Orbo.prefs.orbY = params.y
                        orb.jiggle(10f)
                    }
                }
                return true
            }
        }
        return true
    }

    // ---------------------------------------------------------------- screen on / off
    private fun onScreenOff() {
        if (!built) return
        Orbo.prefs.verifiedUntil = 0L
        VerificationFlow.reset()
        removeLockView()
        try { Assistant.voice.cancel() } catch (e: Exception) { }
        try { Assistant.speaker.stop() } catch (e: Exception) { }
        if (!homeHidden) {
            if (dock != 0) { dock = 0; Orbo.prefs.dockEdge = 0; root.alpha = 1f }
            goHome(false)
        }
    }

    private fun onUnlocked() {
        if (!built) return
        val p = Orbo.prefs
        val needVerify = p.securityEnabled && p.verifyOnUnlock && PinManager.isSet()
        if (homeHidden && (p.comeOutOnUnlock || needVerify)) {
            comeOut(true)
        }
        Orbo.force(OrbState.UNLOCK_WELCOME)
        handler.postDelayed({
            if (needVerify) {
                VerificationFlow.start(null)
            } else if (Orbo.machine.state.value == OrbState.UNLOCK_WELCOME) {
                Orbo.force(OrbState.IDLE)
            }
        }, 900)
    }

    private fun resetSleepTimer() {
        handler.removeCallbacks(sleepTask)
        if (Orbo.prefs.sleepyEnabled) handler.postDelayed(sleepTask, 60000)
    }

    // ---------------------------------------------------------------- full-screen lock page (overlay)
    fun setLockMessage(msg: String) {
        lockStatus?.text = msg
    }

    fun showLock(note: String?) {
        if (!built) return
        if (lockRoot != null) {
            setLockMessage(note ?: "PIN daalo")
            return
        }
        pinBuf.setLength(0)
        escapeTaps = 0
        verifying = false
        if (pillMode) {
            if (expanded) setExpanded(false)
            morphTo(false)
        }
        val ctx = this
        val rootV = FrameLayout(ctx).apply { setBackgroundColor(Color.parseColor("#F5070B1A")) }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), bounds()[2] + dp(12), dp(16), bounds()[3] + dp(12))
        }
        val lo = OrbCanvasView(ctx).apply { reducedMotion = Orbo.prefs.reducedMotion }
        lockOrb = lo
        col.addView(lo, LinearLayout.LayoutParams(dp(150), dp(150)))
        lo.setOrbState(Orbo.machine.state.value)
        col.addView(TextView(ctx).apply {
            text = "Verification Required"
            setTextColor(Color.WHITE)
            textSize = 22f
            gravity = Gravity.CENTER
        })
        val st = TextView(ctx).apply {
            text = note ?: "ORBO PIN daalo"
            setTextColor(Color.parseColor("#FFC9C9"))
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(6))
        }
        lockStatus = st
        col.addView(st)
        val dots = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            textSize = 26f
            gravity = Gravity.CENTER
            letterSpacing = 0.2f
        }
        lockDots = dots
        col.addView(dots)
        updateDots()

        fun key(label: String, onClick: () -> Unit): TextView = TextView(ctx).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 24f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#26FFFFFF"))
            }
            setOnClickListener {
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                onClick()
            }
        }
        val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("\u232B", "0", "\u2713"))
        for (r in rows) {
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            for (k in r) {
                val v = key(k) { onKey(k) }
                row.addView(v, LinearLayout.LayoutParams(dp(68), dp(68)).apply { setMargins(dp(8), dp(5), dp(8), dp(5)) })
            }
            col.addView(row)
        }
        val extra = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        extra.addView(chip("Fingerprint") { VerificationFlow.startBiometric() }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(8), dp(10), dp(8), 0) })
        extra.addView(chip("Face") { VerificationFlow.retryFace() }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(8), dp(10), dp(8), 0) })
        col.addView(extra)
        rootV.addView(col, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        @Suppress("DEPRECATION")
        rootV.systemUiVisibility = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.OPAQUE,
        )
        try {
            wm.addView(rootV, lp)
            lockRoot = rootV
            root.visibility = View.GONE
            hideHotspot()
            val until = PinManager.lockedUntil()
            if (until > System.currentTimeMillis()) startLockCountdown(until)
        } catch (e: Exception) {
            lockRoot = null
            lockOrb = null
            SecurityActivityFallback()
        }
    }

    @Suppress("FunctionName")
    private fun SecurityActivityFallback() {
        try {
            com.orbo.assistant.security.SecurityActivity.launch(this, null)
        } catch (e: Exception) {
        }
    }

    fun hideLock(keepFlow: Boolean) {
        removeLockView()
        if (built && !homeHidden) root.visibility = View.VISIBLE
        if (!keepFlow) lockedUntil = 0L
    }

    private fun removeLockView() {
        lockJob?.cancel()
        lockJob = null
        val v = lockRoot ?: return
        try { wm.removeView(v) } catch (e: Exception) { }
        lockRoot = null
        lockOrb = null
        lockStatus = null
        lockDots = null
        pinBuf.setLength(0)
    }

    private fun updateDots() {
        val n = max(6, pinBuf.length)
        val sb = StringBuilder()
        for (i in 0 until n) sb.append(if (i < pinBuf.length) "\u25CF " else "\u25CB ")
        lockDots?.text = sb.toString().trim()
    }

    private fun onKey(k: String) {
        if (verifying || System.currentTimeMillis() < lockedUntil) return
        when (k) {
            "\u232B" -> {
                if (pinBuf.isNotEmpty()) pinBuf.setLength(pinBuf.length - 1)
                updateDots()
            }
            "\u2713" -> submitPin()
            else -> {
                if (pinBuf.length < 12) pinBuf.append(k)
                escapeTaps = 0
                updateDots()
                lockOrb?.let { it.tap(it.width / 2f, it.height / 2f) }
            }
        }
    }

    private fun submitPin() {
        val p = Orbo.prefs
        if (pinBuf.length < 4) {
            if (p.escapeEnabled) {
                escapeTaps++
                if (escapeTaps >= p.escapeCount) {
                    VerificationFlow.escape()
                    return
                }
                setLockMessage("Quick-exit: ${p.escapeCount - escapeTaps} baar aur")
            } else {
                setLockMessage("PIN kam se kam 4 digit ka daalo.")
            }
            return
        }
        val pin = pinBuf.toString()
        pinBuf.setLength(0)
        updateDots()
        verifying = true
        setLockMessage("Check ho raha hai...")
        scope.launch {
            val r = withContext(Dispatchers.Default) { PinManager.verify(pin) }
            verifying = false
            when (r) {
                PinResult.Success -> VerificationFlow.verified("PIN")
                is PinResult.Wrong -> {
                    setLockMessage("Galat PIN. Attempt ${r.failCount}/${r.threshold}.")
                    shake()
                    lockOrb?.setOrbState(OrbState.FACE_FAILED)
                    handler.postDelayed({ lockOrb?.setOrbState(Orbo.machine.state.value) }, 1200)
                }
                is PinResult.Locked -> {
                    shake()
                    startLockCountdown(r.untilMs)
                }
                PinResult.NotSet -> setLockMessage("PIN set nahi hai.")
                is PinResult.Error -> setLockMessage(r.msg)
            }
        }
    }

    private fun shake() {
        val v = lockRoot ?: return
        if (reduced()) return
        v.animate().translationX(dp(14).toFloat()).setDuration(60).withEndAction {
            v.animate().translationX(-dp(14).toFloat()).setDuration(60).withEndAction {
                v.animate().translationX(0f).setDuration(60).start()
            }.start()
        }.start()
    }

    private fun startLockCountdown(until: Long) {
        lockedUntil = until
        lockJob?.cancel()
        lockJob = scope.launch {
            while (isActive && System.currentTimeMillis() < until) {
                val s = (until - System.currentTimeMillis()) / 1000
                setLockMessage("Bahut zyada galat attempts. ${s}s baad try karo.")
                delay(1000)
            }
            lockedUntil = 0L
            setLockMessage("PIN daalo")
        }
    }
}
