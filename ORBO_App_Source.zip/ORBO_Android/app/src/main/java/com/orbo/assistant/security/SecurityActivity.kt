package com.orbo.assistant.security

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.face.FaceActivity
import com.orbo.assistant.face.FaceBus
import com.orbo.assistant.face.FaceGate
import com.orbo.assistant.orb.OrbState
import com.orbo.assistant.ui.OrbView
import com.orbo.assistant.ui.SelectedAppsSection
import com.orbo.assistant.ui.theme.OrbTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Full-screen ORBO Security Page: PIN, Device Biometric, Face (honestly unavailable), recovery, selected-app status. */
class SecurityActivity : FragmentActivity() {

    companion object {
        @Volatile
        var showing = false
        private const val EXTRA_TARGET = "target"

        fun launch(ctx: Context, targetPkg: String?) {
            val i = Intent(ctx, SecurityActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(EXTRA_TARGET, targetPkg)
            ctx.startActivity(i)
        }
    }

    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        if (!PinManager.isSet()) {
            finish()
            return
        }
        showing = true
        Orbo.force(OrbState.VERIFICATION_PENDING)
        // Back button se is page se nikalna block (ORBO ke apne page tak; system Home ko ye rok nahi sakta).
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {}
        })
        val target = intent.getStringExtra(EXTRA_TARGET)
        setContent {
            OrbTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    SecurityPage(this@SecurityActivity, target) { method -> onVerified(method) }
                }
            }
        }
    }

    private fun onVerified(method: String) {
        if (done) return
        done = true
        VerificationFlow.verified(method)
        finish()
    }

    override fun onDestroy() {
        showing = false
        super.onDestroy()
    }
}

@Composable
private fun SecurityPage(activity: SecurityActivity, target: String?, onVerified: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val state by Orbo.machine.state.collectAsState()
    var pin by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var lockedUntil by remember { mutableStateOf(PinManager.lockedUntil()) }
    var remaining by remember { mutableStateOf(0L) }
    var busy by remember { mutableStateOf(false) }
    var recovery by remember { mutableStateOf(false) }
    var newPin by remember { mutableStateOf("") }
    var newPin2 by remember { mutableStateOf("") }
    val bio = remember { BiometricHelper.availability(activity) }

    LaunchedEffect(lockedUntil) {
        while (System.currentTimeMillis() < lockedUntil) {
            remaining = (lockedUntil - System.currentTimeMillis()) / 1000
            delay(1000)
        }
        remaining = 0
    }
    val locked = remaining > 0

    Column(
        modifier = Modifier.fillMaxSize().safeDrawingPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        OrbView(state = state, orbSize = 96.dp, reducedMotion = Orbo.prefs.reducedMotion)
        Text("Verification Required", style = MaterialTheme.typography.headlineSmall)
        if (target != null) Text("Protected app khulne se pehle verify karo.", style = MaterialTheme.typography.bodyMedium)

        if (!recovery) {
            OutlinedTextField(
                value = pin,
                onValueChange = { if (it.length <= 12 && it.all { c -> c.isDigit() }) pin = it },
                label = { Text("ORBO PIN") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth(),
                enabled = !locked && !busy,
            )
            Button(
                modifier = Modifier.fillMaxWidth(),
                enabled = pin.length >= 4 && !locked && !busy,
                onClick = {
                    busy = true
                    val entered = pin
                    scope.launch {
                        val r = withContext(Dispatchers.Default) { PinManager.verify(entered) }
                        busy = false
                        pin = ""
                        when (r) {
                            PinResult.Success -> onVerified("PIN")
                            is PinResult.Wrong -> message = "Galat PIN. Attempt ${r.failCount}/${r.threshold}."
                            is PinResult.Locked -> {
                                lockedUntil = r.untilMs
                                Orbo.force(OrbState.SECURITY_REQUIRED)
                                message = "Bahut zyada galat attempts. Kuch der rukna padega."
                            }
                            PinResult.NotSet -> message = "PIN set nahi hai."
                            is PinResult.Error -> message = r.msg
                        }
                    }
                },
            ) { Text("Verify") }
            if (locked) Text("Retry ${remaining}s baad.", color = MaterialTheme.colorScheme.error)

            OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    if (!bio.first) {
                        message = bio.second + " PIN use karo."
                    } else {
                        BiometricHelper.prompt(
                            activity, "Device Biometric", false,
                            onSuccess = { onVerified("Device Biometric") },
                            onError = { code, msg, lockout ->
                                message = if (lockout) "Biometric lockout hai. PIN use karo." else "Biometric: $msg"
                                if (lockout) PinManager.logEvent("BIOMETRIC_LOCKOUT", "code $code")
                            },
                        )
                    }
                },
            ) { Text("Device Biometric") }
            Text(bio.second, style = MaterialTheme.typography.bodySmall)

            OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val st = FaceGate.status(activity)
                    if (st != null) {
                        message = st
                        PinManager.logEvent("FACE_UNAVAILABLE", st)
                    } else {
                        FaceBus.listener = { ok, msg ->
                            activity.runOnUiThread { if (ok) onVerified("Face") else message = msg }
                        }
                        FaceActivity.launch(activity, FaceActivity.MODE_VERIFY)
                    }
                },
            ) { Text("Match Face") }

            TextButton(onClick = {
                if (BiometricHelper.credentialRecoveryAvailable(activity)) {
                    BiometricHelper.prompt(
                        activity, "Recovery: phone ka PIN/pattern/biometric", true,
                        onSuccess = { recovery = true; message = "Verify ho gaya. Naya ORBO PIN set karo." },
                        onError = { _, msg, _ -> message = "Recovery fail: $msg" },
                    )
                } else {
                    message = "Is phone par device-credential recovery available nahi (Android 11+ aur screen lock chahiye)."
                }
            }) { Text("PIN bhool gaye? (Recovery)") }
        } else {
            Text("Naya ORBO PIN (6+ digits)", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = newPin, onValueChange = { if (it.length <= 12 && it.all { c -> c.isDigit() }) newPin = it },
                label = { Text("Naya PIN") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = newPin2, onValueChange = { if (it.length <= 12 && it.all { c -> c.isDigit() }) newPin2 = it },
                label = { Text("PIN dobara") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth(),
            )
            Button(modifier = Modifier.fillMaxWidth(), onClick = {
                if (newPin != newPin2) {
                    message = "Dono PIN same nahi hain."
                } else {
                    val err = PinManager.resetViaRecovery(newPin)
                    if (err == null) onVerified("Recovery") else message = err
                }
            }) { Text("PIN save karo") }
        }

        message?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }

        Spacer(Modifier.height(12.dp))
        Text("Selected apps ka status", style = MaterialTheme.typography.titleMedium)
        SelectedAppsSection(editable = false)
    }
}
