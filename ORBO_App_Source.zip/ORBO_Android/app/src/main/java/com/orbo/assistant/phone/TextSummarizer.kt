package com.orbo.assistant.phone

/** Rule-based local summary (AI nahi): frequency-scored extractive sentences. */
object TextSummarizer {
    private val stop = setOf(
        "the", "and", "for", "with", "that", "this", "from", "are", "was", "you", "your", "have", "has", "not",
        "hai", "hain", "ka", "ki", "ke", "ko", "se", "me", "mein", "par", "aur", "ya", "tha", "the", "ek", "ye", "wo",
    )

    fun summarize(text: String, maxSentences: Int = 3): String {
        val clean = text.replace(Regex("\\s+"), " ").trim()
        if (clean.length < 200) return clean
        val sentences = clean.split(Regex("(?<=[.!?\u0964])\\s+")).map { it.trim() }.filter { it.length >= 25 }
        if (sentences.size <= maxSentences) return sentences.joinToString(" ").ifBlank { clean.take(400) }
        val freq = HashMap<String, Int>()
        fun words(s: String) = s.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length > 2 && it !in stop }
        sentences.forEach { s -> words(s).forEach { w -> freq[w] = (freq[w] ?: 0) + 1 } }
        val scored = sentences.mapIndexed { i, s ->
            val w = words(s)
            val score = if (w.isEmpty()) 0.0 else w.sumOf { (freq[it] ?: 0).toDouble() } / Math.sqrt(w.size.toDouble())
            Triple(i, s, score)
        }
        return scored.sortedByDescending { it.third }.take(maxSentences).sortedBy { it.first }.joinToString(" ") { it.second }
    }

    /** Common error text ka simple matlab. null = pehchana nahi. */
    fun explainError(text: String): String? {
        val t = text.lowercase()
        return when {
            "no internet" in t || "no connection" in t || "network" in t && "error" in t ->
                "Internet connection nahi hai ya weak hai. Wi-Fi/mobile data check karo."
            "permission denied" in t || "permission required" in t ->
                "App ko zaroori permission nahi mili. Settings > Apps > Permissions mein allow karo."
            "storage" in t && ("full" in t || "not enough" in t) ->
                "Phone ki storage bhar gayi hai. Kuch files/apps hatao."
            "login failed" in t || "incorrect password" in t || "wrong password" in t ->
                "Login galat hai. Username/password dobara check karo."
            "404" in t || "not found" in t -> "Ye page ya file mili nahi (404 / not found)."
            "500" in t || "server error" in t || "something went wrong" in t ->
                "Server side problem hai. Thodi der baad dobara try karo."
            "timed out" in t || "timeout" in t -> "Request time out ho gayi. Connection check karke dobara try karo."
            "update" in t && ("required" in t || "available" in t) -> "App/system update chahiye."
            else -> null
        }
    }
}
