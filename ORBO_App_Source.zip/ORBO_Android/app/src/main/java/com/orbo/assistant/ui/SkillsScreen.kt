package com.orbo.assistant.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.orbo.assistant.agent.Assistant
import com.orbo.assistant.core.Skill
import com.orbo.assistant.core.Skills

@Composable
fun SkillsScreen(modifier: Modifier = Modifier) {
    var rev by remember { mutableIntStateOf(0) }
    val skills = remember(rev) { Skills.all() }
    var editing by remember { mutableStateOf<Skill?>(null) }
    var creating by remember { mutableStateOf(false) }
    var testText by remember { mutableStateOf<String?>(null) }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Custom Skills", style = MaterialTheme.typography.headlineSmall)
        Text("Har skill ke steps normal ORBO commands hote hain (ek line = ek step). Unsupported step safely fail hota hai.", style = MaterialTheme.typography.bodySmall)
        Button(onClick = { creating = true }) { Text("Nayi skill banao") }

        skills.forEach { s ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(s.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        Switch(checked = s.enabled, onCheckedChange = { on ->
                            val all = Skills.all()
                            all.firstOrNull { it.id == s.id }?.enabled = on
                            Skills.saveAll(all)
                            rev++
                        })
                    }
                    Text(s.steps.mapIndexed { i, st -> "${i + 1}. $st" }.joinToString("\n"), style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(enabled = s.enabled, onClick = { Assistant.runSkill(s) }) { Text("Run") }
                        OutlinedButton(onClick = { testText = Assistant.dryRun(s) }) { Text("Test") }
                        OutlinedButton(onClick = { editing = s }) { Text("Edit") }
                        TextButton(onClick = {
                            Skills.saveAll(Skills.all().filter { it.id != s.id })
                            rev++
                        }) { Text("Delete") }
                    }
                }
            }
        }
    }

    if (creating || editing != null) {
        val base = editing
        var name by remember(base, creating) { mutableStateOf(base?.name ?: "") }
        var steps by remember(base, creating) { mutableStateOf(base?.steps?.joinToString("\n") ?: "") }
        AlertDialog(
            onDismissRequest = { creating = false; editing = null },
            title = { Text(if (base == null) "Nayi skill" else "Skill edit") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Naam") }, singleLine = true)
                    OutlinedTextField(
                        value = steps, onValueChange = { steps = it },
                        label = { Text("Steps (ek line = ek command)") }, minLines = 3,
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = name.isNotBlank() && steps.isNotBlank(),
                    onClick = {
                        val lines = steps.lines().map { it.trim() }.filter { it.isNotEmpty() }
                        val all = Skills.all().toMutableList()
                        if (base == null) {
                            all.add(Skill(System.currentTimeMillis(), name.trim(), lines, true))
                        } else {
                            all.firstOrNull { it.id == base.id }?.let { it.name = name.trim(); it.steps = lines }
                        }
                        Skills.saveAll(all)
                        creating = false
                        editing = null
                        rev++
                    },
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { creating = false; editing = null }) { Text("Cancel") } },
        )
    }

    testText?.let {
        AlertDialog(
            onDismissRequest = { testText = null },
            title = { Text("Skill test (dry run, kuch execute nahi hua)") },
            text = { Text(it) },
            confirmButton = { TextButton(onClick = { testText = null }) { Text("OK") } },
        )
    }
}
