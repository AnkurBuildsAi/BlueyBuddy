package com.orbo.assistant.security

import android.content.Context
import android.os.Build
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/** "Device Biometric": Android reveal nahi karta ki fingerprint hai ya face, isliye generic label. */
object BiometricHelper {

    fun availability(ctx: Context): Pair<Boolean, String> {
        return when (BiometricManager.from(ctx).canAuthenticate(BIOMETRIC_WEAK)) {
            BiometricManager.BIOMETRIC_SUCCESS -> Pair(true, "Device Biometric available hai.")
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> Pair(false, "Is phone mein biometric hardware nahi hai.")
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> Pair(false, "Biometric hardware abhi available nahi hai.")
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> Pair(false, "Phone Settings mein koi fingerprint/face enrolled nahi hai.")
            BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED -> Pair(false, "Biometric ke liye security update chahiye.")
            BiometricManager.BIOMETRIC_ERROR_UNSUPPORTED -> Pair(false, "Is Android version par ye biometric type supported nahi.")
            else -> Pair(false, "Biometric status unknown.")
        }
    }

    /** Device credential (phone ka PIN/pattern) wala recovery sirf Android 11+ par BIOMETRIC_STRONG|DEVICE_CREDENTIAL ke saath safe hai. */
    fun credentialRecoveryAvailable(ctx: Context): Boolean =
        Build.VERSION.SDK_INT >= 30 &&
            BiometricManager.from(ctx).canAuthenticate(BIOMETRIC_STRONG or DEVICE_CREDENTIAL) == BiometricManager.BIOMETRIC_SUCCESS

    fun prompt(
        activity: FragmentActivity,
        title: String,
        allowCredential: Boolean,
        onSuccess: () -> Unit,
        onError: (code: Int, msg: String, lockout: Boolean) -> Unit,
    ) {
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle("ORBO verification")
            .apply {
                if (allowCredential) {
                    setAllowedAuthenticators(BIOMETRIC_STRONG or DEVICE_CREDENTIAL)
                } else {
                    setAllowedAuthenticators(BIOMETRIC_WEAK)
                    setNegativeButtonText("ORBO PIN use karo")
                }
            }
            .build()
        val cb = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                onSuccess()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                val lock = errorCode == BiometricPrompt.ERROR_LOCKOUT || errorCode == BiometricPrompt.ERROR_LOCKOUT_PERMANENT
                onError(errorCode, errString.toString(), lock)
            }
        }
        BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), cb).authenticate(info)
    }
}
