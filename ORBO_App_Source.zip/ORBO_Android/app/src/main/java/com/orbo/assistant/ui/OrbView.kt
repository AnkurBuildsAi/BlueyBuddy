package com.orbo.assistant.ui

import android.view.MotionEvent
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.orbo.assistant.orb.OrbState
import com.orbo.assistant.overlay.OrbCanvasView

/** App ke andar ka Orb: wahi jelly renderer jo overlay mein hai (touch par react karta hai). */
@Composable
fun OrbView(
    state: OrbState,
    modifier: Modifier = Modifier,
    orbSize: Dp = 68.dp,
    reducedMotion: Boolean = false,
) {
    AndroidView(
        modifier = modifier.size(orbSize * 1.5f),
        factory = { ctx ->
            OrbCanvasView(ctx).apply {
                setOnTouchListener { v, e ->
                    if (e.actionMasked == MotionEvent.ACTION_DOWN) (v as OrbCanvasView).tap(e.x, e.y)
                    if (e.actionMasked == MotionEvent.ACTION_MOVE) (v as OrbCanvasView).look(e.x, e.y)
                    true
                }
            }
        },
        update = { v ->
            v.reducedMotion = reducedMotion
            v.setOrbState(state)
        },
    )
}
