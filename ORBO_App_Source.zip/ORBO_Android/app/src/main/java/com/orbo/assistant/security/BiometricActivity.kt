package com.orbo.assistant.security

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.FragmentActivity

/** Transparent activity: sirf Device Biometric prompt dikhane ke liye (overlay/service se). */
class BiometricActivity : FragmentActivity() {

    companion object {
        fun launch(ctx: Context) {
            ctx.startActivity(Intent(ctx, BiometricActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private var reported = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val a = BiometricHelper.availability(this)
        if (!a.first) {
            report(false)
            return
        }
        BiometricHelper.prompt(
            this, "ORBO verification", false,
            onSuccess = { report(true) },
            onError = { code, _, lockout ->
                if (lockout) PinManager.logEvent("BIOMETRIC_LOCKOUT", "code $code")
                report(false)
            },
        )
    }

    private fun report(ok: Boolean) {
        if (reported) return
        reported = true
        VerificationFlow.onBiometricResult(ok)
        finish()
    }

    override fun onDestroy() {
        if (!reported) {
            reported = true
            VerificationFlow.onBiometricResult(false)
        }
        super.onDestroy()
    }
}
