package com.orbo.assistant.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/** Transparent helper: Service/overlay se runtime permission maangne ke liye. */
class PermissionActivity : ComponentActivity() {

    companion object {
        private const val EXTRA = "perms"

        fun request(ctx: Context, perms: Array<String>) {
            val i = Intent(ctx, PermissionActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(EXTRA, perms)
            ctx.startActivity(i)
        }
    }

    private val launcher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val perms = intent.getStringArrayExtra(EXTRA)
        if (perms == null || perms.isEmpty()) {
            finish()
            return
        }
        launcher.launch(perms)
    }
}
