package com.orbo.assistant.overlay

import android.content.Intent
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.orbo.assistant.MainActivity
import com.orbo.assistant.core.Orbo

/** Quick Settings tile: Orb ko home (notch) mein bhejo / bahar bulao / chalu karo. */
class OrbTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        update()
    }

    override fun onClick() {
        super.onClick()
        val svc = OrbOverlayService.instance
        if (svc == null) {
            if (Settings.canDrawOverlays(this)) {
                OrbOverlayService.start(this)
            } else {
                val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivityAndCollapse(i) } catch (e: Exception) { }
            }
        } else if (svc.isHomeHidden()) {
            svc.comeOut(true)
        } else {
            svc.goHome(true)
        }
        update()
    }

    private fun update() {
        val t = qsTile ?: return
        t.state = if (OrbOverlayService.instance != null && Orbo.prefs.overlayEnabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.updateTile()
    }
}
