package com.orbo.assistant.orb

/**
 * Spec ke suggested starting values (milliseconds). Real device par tune karne hain.
 * Phase 2 mein ye Settings se configurable banenge.
 */
object OrbTimings {
    const val DROP_MS = 400          // spec: 350-450
    const val BOUNCE_MS = 220        // spec: 180-250
    const val BLINK_MS = 150         // spec: 120-180
    const val RIPPLE_MS = 300        // spec: 250-350
    const val MORPH_MS = 380         // spec: 300-450
    const val LONG_PRESS_MS = 500L   // spec: about 500, configurable
}
