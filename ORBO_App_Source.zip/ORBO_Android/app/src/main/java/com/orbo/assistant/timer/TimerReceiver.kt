package com.orbo.assistant.timer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.orbo.assistant.agent.Assistant
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.core.PillKind

class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1L)
        val t = TimerManager.markDone(id) ?: return
        Notifier.timerDone(context, t.label, false)
        Orbo.say("Timer poora hua", PillKind.RESULT, t.label)
        try {
            Assistant.speaker.speak("Timer poora hua")
        } catch (e: Exception) {
        }
    }
}
