package com.orbo.assistant.security

import android.util.Base64
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.core.Stores
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

sealed class PinResult {
    object Success : PinResult()
    data class Wrong(val failCount: Int, val threshold: Int) : PinResult()
    data class Locked(val untilMs: Long) : PinResult()
    object NotSet : PinResult()
    data class Error(val msg: String) : PinResult()
}

/**
 * ORBO PIN: PBKDF2(salted) verifier, Keystore AES-GCM se encrypt hoke store. Plaintext PIN kabhi save/log nahi.
 * Failed attempts sirf ORBO ke apne PIN page par gine jaate hain; count aur lockout persist hote hain.
 */
object PinManager {
    private const val ITER = 120_000

    fun isSet(): Boolean = Orbo.prefs.pinBlob != null

    fun validate(pin: String): String? = when {
        pin.length < 6 -> "PIN kam se kam 6 digits ka rakho."
        !pin.all { it.isDigit() } -> "PIN sirf digits ka hona chahiye."
        pin.toSet().size == 1 -> "Sab digits same mat rakho (jaise 111111)."
        else -> null
    }

    private fun hash(pin: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin, salt, ITER, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    fun setPin(pin: String): String? {
        validate(pin)?.let { return it }
        return try {
            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            val h = hash(pin.toCharArray(), salt)
            val blob = KeystoreCipher.encrypt(salt + h)
            Orbo.prefs.pinBlob = Base64.encodeToString(blob, Base64.NO_WRAP)
            Orbo.prefs.pinFailCount = 0
            Orbo.prefs.pinLockedUntil = 0L
            logEvent("PIN_CHANGED", "PIN set/changed")
            null
        } catch (e: Exception) {
            "PIN save nahi ho paya (Keystore error)."
        }
    }

    fun removePin() {
        Orbo.prefs.pinBlob = null
        Orbo.prefs.pinFailCount = 0
        Orbo.prefs.pinLockedUntil = 0L
        Orbo.prefs.securityEnabled = false
        KeystoreCipher.deleteKey()
        logEvent("PIN_REMOVED", "PIN delete kiya")
    }

    fun lockedUntil(): Long = Orbo.prefs.pinLockedUntil

    fun verify(pin: String): PinResult {
        val p = Orbo.prefs
        val blobStr = p.pinBlob ?: return PinResult.NotSet
        val now = System.currentTimeMillis()
        if (now < p.pinLockedUntil) return PinResult.Locked(p.pinLockedUntil)
        return try {
            val blob = KeystoreCipher.decrypt(Base64.decode(blobStr, Base64.NO_WRAP))
            val salt = blob.copyOfRange(0, 16)
            val stored = blob.copyOfRange(16, blob.size)
            val h = hash(pin.toCharArray(), salt)
            if (MessageDigest.isEqual(h, stored)) {
                p.pinFailCount = 0
                p.pinLockedUntil = 0L
                logEvent("PIN_OK", "PIN se verify hua")
                PinResult.Success
            } else {
                val n = p.pinFailCount + 1
                p.pinFailCount = n
                val th = p.failThreshold
                logEvent("PIN_FAIL", "Galat PIN, attempt $n")
                if (n >= th) {
                    val extra = n - th
                    val delayMs = minOf(30_000L shl minOf(extra, 7), 3_600_000L)
                    p.pinLockedUntil = System.currentTimeMillis() + delayMs
                    logEvent("PIN_LOCKOUT", "Threshold ($th) paar; lockout ${delayMs / 1000}s. Security photo capture: ENABLE NAHI hai.")
                    PinResult.Locked(p.pinLockedUntil)
                } else {
                    PinResult.Wrong(n, th)
                }
            }
        } catch (e: Exception) {
            PinResult.Error("PIN verify nahi ho paya (Keystore error).")
        }
    }

    /** Device credential se recovery ke baad naya PIN (fail count reset). */
    fun resetViaRecovery(newPin: String): String? {
        val err = setPin(newPin)
        if (err == null) logEvent("PIN_RECOVERY", "Device credential se PIN reset hua")
        return err
    }

    fun logEvent(type: String, note: String) {
        try {
            val now = System.currentTimeMillis()
            Stores.securityEvents.append(JSONObject().put("at", now).put("type", type).put("note", note))
        } catch (e: Exception) {
        }
    }
}
