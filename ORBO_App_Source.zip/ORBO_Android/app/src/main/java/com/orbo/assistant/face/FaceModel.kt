package com.orbo.assistant.face

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.ByteArrayInputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipInputStream
import kotlin.math.sqrt

/**
 * On-device face embedding model (TFLite). Model file build mein bundle nahi hai:
 * ya to repo root par `face_model.tflite` rakho (workflow assets mein daal deta hai),
 * ya app ke Security tab se phone se import karo. Shape model se khud padhi jaati hai (112x112 -> 128/192/512-d).
 */
object FaceModel {
    private var interp: Interpreter? = null
    private var inW = 112
    private var inH = 112
    private var nchw = false
    private var inType = DataType.FLOAT32
    var dim = 0
        private set

    fun modelFile(ctx: Context): File = File(File(ctx.filesDir, "models"), "face_model.tflite")

    private fun assetExists(ctx: Context): Boolean = try {
        ctx.assets.open("face_model.tflite").close()
        true
    } catch (e: Exception) {
        false
    }

    fun hasModel(ctx: Context): Boolean = modelFile(ctx).exists() || assetExists(ctx)

    private fun readModelBytes(ctx: Context): ByteArray? {
        val f = modelFile(ctx)
        if (f.exists()) return f.readBytes()
        return try {
            ctx.assets.open("face_model.tflite").use { it.readBytes() }
        } catch (e: Exception) {
            null
        }
    }

    /** @return null = ready, warna error message */
    @Synchronized
    fun load(ctx: Context): String? {
        if (interp != null) return null
        val bytes = readModelBytes(ctx) ?: return "Face model file nahi mili. Security tab se model import karo."
        return try {
            openFrom(bytes)
            null
        } catch (t: Throwable) {
            interp = null
            "Model load nahi hua: ${t.message}"
        }
    }

    private fun openFrom(bytes: ByteArray) {
        val buf = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
        buf.put(bytes)
        buf.rewind()
        val ip = Interpreter(buf, Interpreter.Options().apply { setNumThreads(2) })
        try {
            val ti = ip.getInputTensor(0)
            val shape = ti.shape()
            if (shape.size != 4) throw IllegalArgumentException("Input shape ${shape.contentToString()} supported nahi")
            if (shape[3] == 3) {
                nchw = false
                inH = shape[1]
                inW = shape[2]
            } else if (shape[1] == 3) {
                nchw = true
                inH = shape[2]
                inW = shape[3]
            } else {
                throw IllegalArgumentException("Input shape ${shape.contentToString()} supported nahi")
            }
            inType = ti.dataType()
            if (inType != DataType.FLOAT32 && inType != DataType.UINT8) {
                throw IllegalArgumentException("Input type $inType supported nahi")
            }
            val to = ip.getOutputTensor(0)
            val os = to.shape()
            if (os.size != 2 || to.dataType() != DataType.FLOAT32) {
                throw IllegalArgumentException("Output ${os.contentToString()} / ${to.dataType()} supported nahi")
            }
            dim = os[1]
        } catch (t: Throwable) {
            ip.close()
            throw t
        }
        interp?.close()
        interp = ip
    }

    private fun norm(v: Int, ch: Int, mode: Int): Float = when (mode) {
        1 -> v / 255f
        2 -> {
            val mean = floatArrayOf(0.485f, 0.456f, 0.406f)
            val std = floatArrayOf(0.229f, 0.224f, 0.225f)
            (v / 255f - mean[ch]) / std[ch]
        }
        else -> (v - 127.5f) / 127.5f
    }

    /** L2-normalized embedding; null = model problem. */
    @Synchronized
    fun embed(ctx: Context, bmp: Bitmap, preproc: Int): FloatArray? {
        if (load(ctx) != null) return null
        val ip = interp ?: return null
        val scaled = Bitmap.createScaledBitmap(bmp, inW, inH, true)
        val px = IntArray(inW * inH)
        scaled.getPixels(px, 0, inW, 0, 0, inW, inH)
        if (scaled !== bmp) scaled.recycle()

        val floatIn = inType == DataType.FLOAT32
        val buf = ByteBuffer.allocateDirect(inW * inH * 3 * (if (floatIn) 4 else 1)).order(ByteOrder.nativeOrder())
        if (!nchw) {
            for (p in px) {
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                if (floatIn) {
                    buf.putFloat(norm(r, 0, preproc)); buf.putFloat(norm(g, 1, preproc)); buf.putFloat(norm(b, 2, preproc))
                } else {
                    buf.put(r.toByte()); buf.put(g.toByte()); buf.put(b.toByte())
                }
            }
        } else {
            for (ch in 0 until 3) {
                val shift = 16 - 8 * ch
                for (p in px) {
                    val v = (p shr shift) and 0xFF
                    if (floatIn) buf.putFloat(norm(v, ch, preproc)) else buf.put(v.toByte())
                }
            }
        }
        buf.rewind()
        val out = Array(1) { FloatArray(dim) }
        ip.run(buf, out)
        val e = out[0]
        var s = 0f
        for (v in e) s += v * v
        val n = sqrt(s)
        if (n < 1e-6f) return null
        for (i in e.indices) e[i] = e[i] / n
        return e
    }

    fun cosine(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return -1f
        var s = 0f
        for (i in a.indices) s += a[i] * b[i]
        return s
    }

    /** Phone se chuni .tflite (ya usse bhari .zip) ko validate karke app mein rakhta hai. */
    fun importFrom(ctx: Context, uri: Uri): String? {
        val raw: ByteArray = try {
            ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (e: Exception) {
            null
        } ?: return "File padh nahi payi."
        var bytes = raw
        if (raw.size > 4 && raw[0] == 'P'.code.toByte() && raw[1] == 'K'.code.toByte()) {
            var found: ByteArray? = null
            ZipInputStream(ByteArrayInputStream(raw)).use { zis ->
                var e = zis.nextEntry
                while (e != null) {
                    if (e.name.endsWith(".tflite")) {
                        found = zis.readBytes()
                        break
                    }
                    e = zis.nextEntry
                }
            }
            bytes = found ?: return "ZIP ke andar .tflite file nahi mili."
        }
        if (bytes.size < 100_000) return "File bahut chhoti hai; ye face model nahi lagta."
        synchronized(this) {
            try {
                openFrom(bytes)
            } catch (t: Throwable) {
                return "Ye model use nahi ho sakta: ${t.message}"
            }
        }
        val f = modelFile(ctx)
        f.parentFile?.mkdirs()
        f.writeBytes(bytes)
        return null
    }

    fun summary(): String = if (interp == null) "model abhi load nahi hua" else "input ${inW}x$inH ${if (nchw) "NCHW" else "NHWC"}, embedding $dim-d"

    @Synchronized
    fun close() {
        interp?.close()
        interp = null
    }
}
