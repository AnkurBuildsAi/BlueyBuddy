package com.orbo.assistant.phone

import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import com.orbo.assistant.core.Orbo

object PhoneActions {

    fun launchableApps(): List<AppInfo> {
        val pm = Orbo.app.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(i, 0)
        val seen = HashSet<String>()
        val out = mutableListOf<AppInfo>()
        for (r in list) {
            val pkg = r.activityInfo.packageName
            if (pkg == Orbo.app.packageName || !seen.add(pkg)) continue
            out.add(AppInfo(r.loadLabel(pm).toString(), pkg))
        }
        return out.sortedBy { it.label.lowercase() }
    }

    fun launchIntentFor(pkg: String): Intent? =
        Orbo.app.packageManager.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun settingsIntent(page: String): Intent {
        val action = when (page) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "security" -> Settings.ACTION_SECURITY_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun resolvedPackage(intent: Intent): String? =
        intent.resolveActivity(Orbo.app.packageManager)?.packageName

    fun hasPackage(pkg: String): Boolean = try {
        Orbo.app.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }
}
