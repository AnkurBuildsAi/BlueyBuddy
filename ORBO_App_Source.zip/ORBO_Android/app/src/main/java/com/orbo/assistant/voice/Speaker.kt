package com.orbo.assistant.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** TextToSpeech wrapper: chunked reading, stop, pause, resume. Sirf installed local voice data par depend. */
class Speaker(private val ctx: Context) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var initFailed = false
    private var pendingStart: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())
    private var chunks: List<String> = emptyList()
    private var idx = 0
    private var paused = false
    private var speaking = false
    private var onDone: (() -> Unit)? = null

    val isSpeaking: Boolean get() = speaking
    val isPaused: Boolean get() = paused

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}

        override fun onDone(utteranceId: String?) {
            main.post {
                if (!paused && speaking) {
                    idx++
                    next()
                }
            }
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            main.post {
                if (!paused && speaking) {
                    idx++
                    next()
                }
            }
        }
    }

    fun speak(text: String, done: (() -> Unit)? = null) {
        val clean = text.trim()
        if (clean.isEmpty()) {
            done?.invoke()
            return
        }
        stop()
        onDone = done
        chunks = chunk(clean)
        idx = 0
        paused = false
        speaking = true
        ensure { next() }
    }

    fun stop() {
        speaking = false
        paused = false
        chunks = emptyList()
        idx = 0
        onDone = null
        try { tts?.stop() } catch (e: Exception) { }
    }

    fun pause(): Boolean {
        if (!speaking || paused) return false
        paused = true
        try { tts?.stop() } catch (e: Exception) { }
        return true
    }

    fun resume(): Boolean {
        if (!speaking || !paused) return false
        paused = false
        next()
        return true
    }

    fun shutdown() {
        stop()
        try { tts?.shutdown() } catch (e: Exception) { }
        tts = null
        ready = false
    }

    private fun ensure(then: () -> Unit) {
        if (ready) {
            then()
            return
        }
        if (initFailed) {
            finish()
            return
        }
        pendingStart = then
        if (tts == null) {
            tts = TextToSpeech(ctx.applicationContext) { status ->
                main.post {
                    if (status == TextToSpeech.SUCCESS) {
                        ready = true
                        tts?.setOnUtteranceProgressListener(listener)
                        val p = pendingStart
                        pendingStart = null
                        p?.invoke()
                    } else {
                        initFailed = true
                        pendingStart = null
                        finish()
                    }
                }
            }
        }
    }

    private fun next() {
        if (idx >= chunks.size) {
            finish()
            return
        }
        val c = chunks[idx]
        setLang(c)
        val r = tts?.speak(c, TextToSpeech.QUEUE_FLUSH, null, "orbo_$idx")
        if (r != TextToSpeech.SUCCESS) {
            idx++
            if (idx < chunks.size) next() else finish()
        }
    }

    private fun finish() {
        val cb = onDone
        speaking = false
        paused = false
        onDone = null
        chunks = emptyList()
        idx = 0
        cb?.invoke()
    }

    private fun setLang(text: String) {
        val devanagari = text.any { it.code in 0x0900..0x097F }
        val primary = if (devanagari) Locale("hi", "IN") else Locale("en", "IN")
        val r = tts?.setLanguage(primary)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            val r2 = tts?.setLanguage(Locale.getDefault())
            if (r2 == TextToSpeech.LANG_MISSING_DATA || r2 == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.US)
            }
        }
    }

    private fun chunk(text: String): List<String> {
        val out = mutableListOf<String>()
        val sentences = text.replace("\n", " ").split(Regex("(?<=[.!?\u0964])\\s+"))
        for (s in sentences) {
            var t = s.trim()
            while (t.length > 240) {
                val cut = t.lastIndexOf(' ', 240).let { if (it < 60) 240 else it }
                out.add(t.substring(0, cut).trim())
                t = t.substring(cut).trim()
            }
            if (t.isNotEmpty()) out.add(t)
        }
        return out
    }
}
