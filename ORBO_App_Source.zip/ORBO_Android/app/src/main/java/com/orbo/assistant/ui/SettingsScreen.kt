package com.orbo.assistant.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.orbo.assistant.ai.AiClient
import com.orbo.assistant.ai.AiKeyStore
import com.orbo.assistant.ai.AiProvider
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.core.Stores
import com.orbo.assistant.overlay.OrbOverlayService
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(onOpenCommands: () -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = Orbo.prefs
    var size by remember { mutableStateOf(p.orbSizeDp.toFloat()) }
    var longMs by remember { mutableStateOf(p.longPressMs.toFloat()) }
    var silence by remember { mutableStateOf(p.silenceSec) }
    var lang by remember { mutableStateOf(p.lang) }
    var reduced by remember { mutableStateOf(p.reducedMotion) }
    var sleepy by remember { mutableStateOf(p.sleepyEnabled) }
    var speak by remember { mutableStateOf(p.speakReplies) }
    var country by remember { mutableStateOf(p.countryCode) }

    var aiOn by remember { mutableStateOf(p.aiEnabled) }
    var provider by remember { mutableStateOf(AiClient.provider()) }
    var base by remember { mutableStateOf(p.aiBaseUrl) }
    var model by remember { mutableStateOf(p.aiModel) }
    var key by remember { mutableStateOf("") }
    var keySaved by remember { mutableStateOf(AiKeyStore.has()) }
    var aiNote by remember { mutableStateOf<String?>(null) }

    fun restartOverlay() {
        if (p.overlayEnabled) {
            OrbOverlayService.stop(ctx)
            OrbOverlayService.start(ctx)
        }
    }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)

        Button(onClick = onOpenCommands, modifier = Modifier.fillMaxWidth()) { Text("Saare Commands ki list + apne commands") }

        Text("Orb size: ${size.toInt()} dp", style = MaterialTheme.typography.titleSmall)
        Slider(value = size, onValueChange = { size = it }, valueRange = 48f..100f,
            onValueChangeFinished = { p.orbSizeDp = size.toInt(); restartOverlay() })

        Text("Long-press time: ${longMs.toInt()} ms", style = MaterialTheme.typography.titleSmall)
        Slider(value = longMs, onValueChange = { longMs = it }, valueRange = 300f..1000f,
            onValueChangeFinished = { p.longPressMs = longMs.toLong() })

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { OrbOverlayService.instance?.goHome(true) }) { Text("Orb ko home bhejo") }
            OutlinedButton(onClick = { OrbOverlayService.instance?.comeOut(true) }) { Text("Orb bulao") }
        }
        Text(
            "Orb ko kinare par chhodo to wo thoda andar jakar fade ho jata hai; top-center (notch) tak le jao to home mein chala jata hai. " +
                "Wapas bulane ke liye notch ke neeche wala chhota spot dabao, notification ka 'Orb bulao', ya Quick Settings tile.",
            style = MaterialTheme.typography.bodySmall,
        )

        Text("Voice silence timeout", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(5, 10, 15, 30).forEach { s ->
                FilterChip(selected = silence == s, onClick = { silence = s; p.silenceSec = s }, label = { Text("${s}s") })
            }
        }

        Text("Voice language", style = MaterialTheme.typography.titleSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("hi-IN" to "Hindi/Hinglish", "en-IN" to "English (IN)", "en-US" to "English (US)").forEach { (code, label) ->
                FilterChip(selected = lang == code, onClick = { lang = code; p.lang = code }, label = { Text(label) })
            }
        }
        Text("Language ka offline model device par install hona chahiye; warna voice fail hoga aur text mode chalega.", style = MaterialTheme.typography.bodySmall)

        SwitchRow("Reduced motion (blink/jelly/animation band)", reduced) { reduced = it; p.reducedMotion = it; restartOverlay() }
        SwitchRow("Sleepy mode (60 sec idle ke baad)", sleepy) { sleepy = it; p.sleepyEnabled = it }
        SwitchRow("Jawab bolkar sunao (TextToSpeech)", speak) { speak = it; p.speakReplies = it }

        Text("Message bhejna", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(
            value = country, onValueChange = { country = it.filter { c -> c.isDigit() }.take(4); p.countryCode = country },
            label = { Text("Default country code (10-digit number ke liye), jaise 91") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(),
        )

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("AI (optional)", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                    Switch(checked = aiOn, onCheckedChange = { aiOn = it; p.aiEnabled = it })
                }
                Text(
                    if (aiOn) {
                        "ON: sirf wo command text provider ko jata hai jo local engine nahi samajh paya. Screen ka text, contacts ya PIN kabhi nahi bheje jaate. AI sirf ORBO ki command-list ke andar ka command de sakta hai."
                    } else {
                        "OFF: app poori tarah local hai, jaise AI juda hi nahi hai. Koi internet request nahi jati."
                    },
                    style = MaterialTheme.typography.bodySmall,
                )
                if (aiOn) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AiProvider.entries.forEach { pr ->
                            FilterChip(
                                selected = provider == pr,
                                onClick = {
                                    provider = pr
                                    p.aiProvider = pr.name
                                    base = ""; model = ""
                                    p.aiBaseUrl = ""; p.aiModel = ""
                                },
                                label = { Text(pr.label) },
                            )
                        }
                    }
                    OutlinedTextField(
                        value = base, onValueChange = { base = it; p.aiBaseUrl = it },
                        label = { Text("Base URL (khali = ${provider.baseUrl.ifBlank { "zaroori" }})") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = model, onValueChange = { model = it; p.aiModel = it },
                        label = { Text("Model (khali = ${provider.model.ifBlank { "zaroori" }})") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = key, onValueChange = { key = it },
                        label = { Text(if (keySaved) "API key (saved, naya daalo to badlegi)" else "API key") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            if (key.isNotBlank()) {
                                AiKeyStore.save(key)
                                key = ""
                            }
                            keySaved = AiKeyStore.has()
                            aiNote = if (keySaved) "Save ho gaya (key encrypted)." else "Key khali hai."
                        }) { Text("Save") }
                        OutlinedButton(onClick = {
                            aiNote = "Test ho raha hai..."
                            scope.launch { aiNote = AiClient.test() }
                        }) { Text("Test connection") }
                        OutlinedButton(onClick = {
                            AiKeyStore.save("")
                            keySaved = false
                            aiNote = "Key hata di."
                        }) { Text("Key hatao") }
                    }
                    aiNote?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
                }
            }
        }

        OutlinedButton(onClick = { Stores.history.clear() }, modifier = Modifier.fillMaxWidth()) { Text("History clear karo") }
        Text("ORBO v0.3.0  \u2022  Data phone se bahar nahi jata (sirf web search / AI ON hone par internet).", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = value, onCheckedChange = onChange)
    }
}
