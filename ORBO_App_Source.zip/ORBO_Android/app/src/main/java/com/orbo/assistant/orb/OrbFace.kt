package com.orbo.assistant.orb

enum class EyeStyle { OPEN, FOCUSED, HAPPY, CONFUSED, SLEEPY, SERIOUS, CURIOUS, SIDE, SUSPICIOUS, WIDE, WINK, DIZZY }

enum class MouthStyle { NEUTRAL, SMILE, SURPRISED, THINKING, GRIN, WAVY, FROWN }

data class OrbFace(val eyes: EyeStyle, val mouth: MouthStyle)

/** State -> expression mapping (spec section 6 + verification states). */
fun OrbState.toFace(): OrbFace = when (this) {
    OrbState.IDLE -> OrbFace(EyeStyle.OPEN, MouthStyle.NEUTRAL)
    OrbState.UNLOCK_WELCOME -> OrbFace(EyeStyle.HAPPY, MouthStyle.GRIN)
    OrbState.LISTENING -> OrbFace(EyeStyle.CURIOUS, MouthStyle.NEUTRAL)
    OrbState.THINKING -> OrbFace(EyeStyle.SIDE, MouthStyle.THINKING)
    OrbState.EXECUTING -> OrbFace(EyeStyle.FOCUSED, MouthStyle.NEUTRAL)
    OrbState.WAITING -> OrbFace(EyeStyle.OPEN, MouthStyle.NEUTRAL)
    OrbState.COMPLETED -> OrbFace(EyeStyle.HAPPY, MouthStyle.SMILE)
    OrbState.SEARCH_FOUND -> OrbFace(EyeStyle.WIDE, MouthStyle.SURPRISED)
    OrbState.ERROR -> OrbFace(EyeStyle.CONFUSED, MouthStyle.WAVY)
    OrbState.VERIFICATION_PENDING -> OrbFace(EyeStyle.SUSPICIOUS, MouthStyle.THINKING)
    OrbState.FACE_FAILED -> OrbFace(EyeStyle.CONFUSED, MouthStyle.FROWN)
    OrbState.VERIFIED -> OrbFace(EyeStyle.HAPPY, MouthStyle.GRIN)
    OrbState.SECURITY_REQUIRED -> OrbFace(EyeStyle.SERIOUS, MouthStyle.FROWN)
    OrbState.SLEEPY -> OrbFace(EyeStyle.SLEEPY, MouthStyle.NEUTRAL)
}
