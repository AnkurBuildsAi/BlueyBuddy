package com.orbo.assistant.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.orbo.assistant.agent.Assistant
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.core.Stores
import com.orbo.assistant.overlay.OrbOverlayService
import com.orbo.assistant.phone.OrboAccessibilityService
import com.orbo.assistant.timer.Notifier
import com.orbo.assistant.timer.TimerManager

private fun hasPerm(ctx: Context, p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

@Composable
fun HomeScreen(tick: Int, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val state by Orbo.machine.state.collectAsState()
    val pill by Orbo.pill.collectAsState()
    var cmd by remember { mutableStateOf("") }
    var overlayOn by remember(tick) { mutableStateOf(Orbo.prefs.overlayEnabled) }
    var note by remember { mutableStateOf<String?>(null) }
    var a11yDialog by remember { mutableStateOf(false) }

    val overlayOk = remember(tick) { Settings.canDrawOverlays(ctx) }
    val a11yConnected = remember(tick) { OrboAccessibilityService.instance != null }
    val a11yInSettings = remember(tick) { OrboAccessibilityService.isEnabledInSettings(ctx) }
    val micOk = remember(tick) { hasPerm(ctx, Manifest.permission.RECORD_AUDIO) }
    val notifOk = remember(tick) { Notifier.canNotify(ctx) }
    val exactOk = remember(tick) { TimerManager.usesExactAlarm() }
    val speechNote = remember(tick) {
        val v = Assistant.voice
        when {
            !v.isAvailable() -> "Speech service nahi mili: text command mode use karo."
            v.onDeviceAvailable() -> "On-device speech recognition available (offline ho sakta hai)."
            else -> "Speech service hai, par offline model guaranteed nahi. Fail ho to text mode use karo."
        }
    }

    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("ORBO", style = MaterialTheme.typography.headlineLarge)
        OrbView(state = state, orbSize = 140.dp, reducedMotion = Orbo.prefs.reducedMotion)
        Text(state.name, style = MaterialTheme.typography.titleMedium)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(pill.text, style = MaterialTheme.typography.titleMedium)
                if (pill.detail.isNotBlank()) Text(pill.detail, style = MaterialTheme.typography.bodySmall)
                if (pill.actions.isNotEmpty()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pill.actions.forEach { a -> FilledTonalButton(onClick = { a.run() }) { Text(a.label) } }
                    }
                }
                OutlinedButton(onClick = { Assistant.stopAll("Stop kar diya") }) { Text("Stop / Cancel") }
            }
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("Floating Orb", style = MaterialTheme.typography.titleMedium)
                Text("Doosri apps ke upar Orb dikhta hai. Long-press = Pill + mic.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = overlayOn, onCheckedChange = { on ->
                if (on) {
                    if (!Settings.canDrawOverlays(ctx)) {
                        note = "Pehle neeche 'Overlay' permission do."
                        openOverlaySettings(ctx)
                    } else {
                        OrbOverlayService.start(ctx)
                        overlayOn = true
                        note = null
                    }
                } else {
                    OrbOverlayService.stop(ctx)
                    overlayOn = false
                }
            })
        }
        note?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }

        Button(modifier = Modifier.fillMaxWidth(), onClick = { Assistant.startVoice() }) { Text("\uD83C\uDFA4  Tap to Talk") }
        Text(speechNote, style = MaterialTheme.typography.bodySmall)

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = cmd, onValueChange = { cmd = it }, singleLine = true,
                label = { Text("Command likho (text mode)") }, modifier = Modifier.weight(1f),
            )
            Button(onClick = {
                val t = cmd
                cmd = ""
                Assistant.submit(t)
            }, enabled = cmd.isNotBlank()) { Text("Run") }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val quick = listOf(
                "Time batao" to "current time batao",
                "Back" to "back jao",
                "Home" to "home screen par jao",
                "Scroll down" to "scroll down",
                "Scroll up" to "scroll up",
                "Screen padho" to "is page ko padho",
                "Screen samjhao" to "screen par kya likha hai",
            )
            items(quick) { q -> FilledTonalButton(onClick = { Assistant.submit(q.second) }) { Text(q.first) } }
        }

        Text("Setup (jo feature chahiye wahi on karo)", style = MaterialTheme.typography.titleMedium, modifier = Modifier.fillMaxWidth())
        PermCard("Overlay (Display over other apps)", if (overlayOk) "GRANTED" else "NOT GRANTED",
            "Floating Orb ke liye zaroori.", if (overlayOk) "Settings" else "Allow karo") { openOverlaySettings(ctx) }
        PermCard("Accessibility service", if (a11yConnected) "CONNECTED" else if (a11yInSettings) "ON (connect ho raha hai)" else "OFF",
            "Back/Home/scroll/click, screen text padhna aur app-verify ke liye. Aap hi Android Settings mein on karte ho.",
            "Settings kholo") { a11yDialog = true }
        PermCard("Microphone", if (micOk) "GRANTED" else "NOT GRANTED", "Voice commands ke liye. Idle mein mic kabhi on nahi hota.",
            if (micOk) "OK" else "Allow karo") { if (!micOk) PermissionActivity.request(ctx, arrayOf(Manifest.permission.RECORD_AUDIO)) }
        PermCard("Notifications", if (notifOk) "GRANTED" else "NOT GRANTED", "Timer/reminder aur Orb notification ke liye.",
            if (notifOk) "OK" else "Allow karo") {
            if (!notifOk) {
                if (Build.VERSION.SDK_INT >= 33) PermissionActivity.request(ctx, arrayOf(Manifest.permission.POST_NOTIFICATIONS))
                else ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        PermCard("Exact alarm (optional)", if (exactOk) "ALLOWED" else "NOT ALLOWED",
            "Timer ko sahi waqt par bajane ke liye. Na do to timer thoda late ho sakta hai.",
            "Settings") {
            if (Build.VERSION.SDK_INT >= 31) {
                ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        PermCard("Battery (Vivo/OEM)", "MANUAL", "Orb/timers kill na hon, isliye ORBO ko 'unrestricted/no restriction' battery par rakho.",
            "Battery settings") {
            ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        Spacer(Modifier.height(8.dp))
        Text("Recent tasks", style = MaterialTheme.typography.titleMedium, modifier = Modifier.fillMaxWidth())
        val recent = remember(pill.text, pill.detail) { Stores.history.read().takeLast(5).reversed() }
        if (recent.isEmpty()) Text("Abhi koi task nahi.", style = MaterialTheme.typography.bodySmall)
        recent.forEach {
            Text("${it.optString("state")}: ${it.optString("command")}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.fillMaxWidth())
        }
    }

    if (a11yDialog) {
        AlertDialog(
            onDismissRequest = { a11yDialog = false },
            title = { Text("Accessibility kyun chahiye?") },
            text = {
                Text(
                    "ORBO Accessibility sirf aapke diye commands ke liye use karta hai: Back/Home, scroll, click, " +
                        "text likhna aur screen ka visible text padhna. Password fields nahi padhe jaate. " +
                        "Data phone se bahar nahi jata. Aap kabhi bhi Settings se ise band kar sakte ho.\n\n" +
                        "Settings mein 'ORBO' dhundho aur ON karo.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    a11yDialog = false
                    ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text("Samajh gaya, Settings kholo") }
            },
            dismissButton = { TextButton(onClick = { a11yDialog = false }) { Text("Abhi nahi") } },
        )
    }
}

private fun openOverlaySettings(ctx: Context) {
    ctx.startActivity(
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
    )
}

@Composable
private fun PermCard(title: String, status: String, why: String, button: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text("Status: $status", style = MaterialTheme.typography.bodyMedium)
            Text(why, style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = onClick) { Text(button) }
        }
    }
}
