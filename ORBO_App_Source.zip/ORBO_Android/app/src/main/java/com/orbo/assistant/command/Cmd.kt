package com.orbo.assistant.command

/** Deterministic local commands. Koi AI/network nahi. */
sealed class Cmd {
    data class OpenApp(val query: String) : Cmd()
    object Back : Cmd()
    object Home : Cmd()
    object Recents : Cmd()
    object ScrollDown : Cmd()
    object ScrollUp : Cmd()
    object Time : Cmd()
    data class TimerSet(val seconds: Long, val label: String) : Cmd()
    object TimerCancel : Cmd()
    object TimerPause : Cmd()
    object TimerResume : Cmd()
    data class Stopwatch(val start: Boolean) : Cmd()
    object Stop : Cmd()
    object Cancel : Cmd()
    object Pause : Cmd()
    object Resume : Cmd()
    object ReadAloud : Cmd()
    object ExplainScreen : Cmd()
    object ExplainError : Cmd()
    object Summarize : Cmd()
    object Copy : Cmd()
    object Paste : Cmd()
    data class Search(val query: String, val site: String) : Cmd()
    data class OpenResult(val n: Int) : Cmd()
    data class OpenSettings(val page: String) : Cmd()
    data class DraftMessage(val to: String?, val body: String) : Cmd()
    data class TypeText(val text: String) : Cmd()
    data class ClickText(val text: String) : Cmd()
    data class Remember(val text: String) : Cmd()
    data class RunSkill(val name: String) : Cmd()
    object Cut : Cmd()
    object SelectAll : Cmd()
    data class Speak(val text: String) : Cmd()
    data class Swipe(val dir: String) : Cmd()
    object Screenshot : Cmd()
    object Notifications : Cmd()
    object LockScreen : Cmd()
    object OrbGoHome : Cmd()
    object OrbComeOut : Cmd()
    object OrbSleep : Cmd()
    object OrbWake : Cmd()
    data class SendMessage(val to: String, val body: String, val via: String) : Cmd()
    data class AskAi(val text: String) : Cmd()
    data class Compound(val steps: List<Cmd>) : Cmd()
    data class Unknown(val raw: String, val hint: String) : Cmd()
}

fun Cmd.describe(): String = when (this) {
    is Cmd.OpenApp -> "App kholo: $query"
    Cmd.Back -> "Back jao"
    Cmd.Home -> "Home screen par jao"
    Cmd.Recents -> "Recent apps kholo"
    Cmd.ScrollDown -> "Neeche scroll karo"
    Cmd.ScrollUp -> "Upar scroll karo"
    Cmd.Time -> "Current time batao"
    is Cmd.TimerSet -> "Timer lagao: ${seconds}s"
    Cmd.TimerCancel -> "Timer cancel karo"
    Cmd.TimerPause -> "Timer pause karo"
    Cmd.TimerResume -> "Timer resume karo"
    is Cmd.Stopwatch -> if (start) "Stopwatch chalu karo" else "Stopwatch band karo"
    Cmd.Stop -> "Stop"
    Cmd.Cancel -> "Cancel"
    Cmd.Pause -> "Pause"
    Cmd.Resume -> "Resume"
    Cmd.ReadAloud -> "Screen ka text padho"
    Cmd.ExplainScreen -> "Screen samjhao"
    Cmd.ExplainError -> "Error ka matlab batao"
    Cmd.Summarize -> "Page ka summary do"
    Cmd.Copy -> "Text copy karo"
    Cmd.Paste -> "Paste karo"
    is Cmd.Search -> "Search karo: $query"
    is Cmd.OpenResult -> "Result #$n kholo"
    is Cmd.OpenSettings -> "Settings page kholo: $page"
    is Cmd.DraftMessage -> "Message draft karo"
    is Cmd.TypeText -> "Text likho: $text"
    is Cmd.ClickText -> "Click karo: $text"
    is Cmd.Remember -> "Yaad rakho: $text"
    is Cmd.RunSkill -> "Skill chalao: $name"
    Cmd.Cut -> "Text cut karo"
    Cmd.SelectAll -> "Sab select karo"
    is Cmd.Speak -> "Bolo: $text"
    is Cmd.Swipe -> "Swipe $dir"
    Cmd.Screenshot -> "Screenshot lo"
    Cmd.Notifications -> "Notifications kholo"
    Cmd.LockScreen -> "Screen lock karo"
    Cmd.OrbGoHome -> "Orb home (notch) mein jaye"
    Cmd.OrbComeOut -> "Orb home se bahar aaye"
    Cmd.OrbSleep -> "Orb so jaye"
    Cmd.OrbWake -> "Orb jaage"
    is Cmd.SendMessage -> "Message bhejo: $to ($via)"
    is Cmd.AskAi -> "AI se poochho"
    is Cmd.Compound -> steps.joinToString(" -> ") { it.describe() }
    is Cmd.Unknown -> "Samajh nahi aaya"
}


/** Settings mein enable/disable ke liye command ka key. "" = key nahi (Compound/Unknown). */
fun Cmd.key(): String = when (this) {
    is Cmd.OpenApp -> "open_app"
    Cmd.Back -> "back"
    Cmd.Home -> "home"
    Cmd.Recents -> "recents"
    Cmd.ScrollDown, Cmd.ScrollUp -> "scroll"
    Cmd.Time -> "time"
    is Cmd.TimerSet, Cmd.TimerCancel, Cmd.TimerPause, Cmd.TimerResume -> "timer"
    is Cmd.Stopwatch -> "stopwatch"
    Cmd.Stop, Cmd.Cancel -> "stop_cancel"
    Cmd.Pause, Cmd.Resume -> "pause_resume"
    Cmd.ReadAloud -> "read_aloud"
    Cmd.ExplainScreen -> "explain_screen"
    Cmd.ExplainError -> "explain_error"
    Cmd.Summarize -> "summarize"
    Cmd.Copy -> "copy"
    Cmd.Cut -> "cut"
    Cmd.Paste -> "paste"
    Cmd.SelectAll -> "select_all"
    is Cmd.Search -> "search"
    is Cmd.OpenResult -> "open_result"
    is Cmd.OpenSettings -> "settings_page"
    is Cmd.DraftMessage -> "message_draft"
    is Cmd.SendMessage -> "send_message"
    is Cmd.TypeText -> "type_text"
    is Cmd.Speak -> "speak"
    is Cmd.ClickText -> "click"
    is Cmd.Swipe -> "swipe"
    is Cmd.Remember -> "remember"
    is Cmd.RunSkill -> "skill"
    Cmd.Screenshot -> "screenshot"
    Cmd.Notifications -> "notifications"
    Cmd.LockScreen -> "lock_screen"
    Cmd.OrbGoHome -> "orb_go_home"
    Cmd.OrbComeOut -> "orb_come_out"
    Cmd.OrbSleep -> "orb_sleep"
    Cmd.OrbWake -> "orb_wake"
    is Cmd.AskAi -> ""
    is Cmd.Compound -> ""
    is Cmd.Unknown -> ""
}
