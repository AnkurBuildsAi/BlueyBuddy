package com.orbo.assistant.timer

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.core.Stores
import org.json.JSONObject

class TimerItem(
    val id: Long,
    val label: String,
    val startAt: Long,
    var deadline: Long,
    var pausedRemaining: Long,
    var state: String, // RUNNING, PAUSED, DONE, CANCELLED
)

/** Timers: start/deadline disk par persist hote hain; alarm AlarmManager se; reboot par BootReceiver reschedule karta hai. */
object TimerManager {

    private fun ctx(): Context = Orbo.app

    fun load(): MutableList<TimerItem> = Stores.timers.read().map {
        TimerItem(
            it.optLong("id"), it.optString("label"), it.optLong("startAt"), it.optLong("deadline"),
            it.optLong("pausedRemaining", -1L), it.optString("state", "DONE"),
        )
    }.toMutableList()

    private fun save(list: List<TimerItem>) {
        Stores.timers.write(list.map {
            JSONObject().put("id", it.id).put("label", it.label).put("startAt", it.startAt)
                .put("deadline", it.deadline).put("pausedRemaining", it.pausedRemaining).put("state", it.state)
        })
    }

    fun active(): List<TimerItem> = load().filter { it.state == "RUNNING" || it.state == "PAUSED" }

    fun remainingMs(t: TimerItem): Long =
        if (t.state == "PAUSED") t.pausedRemaining else (t.deadline - System.currentTimeMillis()).coerceAtLeast(0L)

    fun start(seconds: Long, label: String): TimerItem {
        val now = System.currentTimeMillis()
        val t = TimerItem(now, label, now, now + seconds * 1000L, -1L, "RUNNING")
        val l = load()
        l.add(t)
        save(l)
        schedule(t)
        return t
    }

    fun isScheduled(id: Long): Boolean = PendingIntent.getBroadcast(
        ctx(), id.toInt(), Intent(ctx(), TimerReceiver::class.java),
        PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE,
    ) != null

    fun usesExactAlarm(): Boolean {
        val am = ctx().getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
    }

    fun schedule(t: TimerItem) {
        val am = ctx().getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(t.id)
        if (usesExactAlarm()) {
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.deadline, pi)
                return
            } catch (e: SecurityException) {
                // niche inexact par fallback
            }
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.deadline, pi)
    }

    private fun pending(id: Long): PendingIntent {
        val i = Intent(ctx(), TimerReceiver::class.java).putExtra("id", id)
        return PendingIntent.getBroadcast(ctx(), id.toInt(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun cancelAlarm(id: Long) {
        val am = ctx().getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(id))
    }

    fun cancelAll(): Int {
        val l = load()
        var n = 0
        l.forEach {
            if (it.state == "RUNNING" || it.state == "PAUSED") {
                cancelAlarm(it.id)
                it.state = "CANCELLED"
                n++
            }
        }
        save(l)
        return n
    }

    fun pauseAll(): Int {
        val l = load()
        var n = 0
        l.forEach {
            if (it.state == "RUNNING") {
                it.pausedRemaining = (it.deadline - System.currentTimeMillis()).coerceAtLeast(0L)
                it.state = "PAUSED"
                cancelAlarm(it.id)
                n++
            }
        }
        save(l)
        return n
    }

    fun resumeAll(): Int {
        val l = load()
        var n = 0
        l.forEach {
            if (it.state == "PAUSED") {
                it.deadline = System.currentTimeMillis() + it.pausedRemaining
                it.pausedRemaining = -1L
                it.state = "RUNNING"
                schedule(it)
                n++
            }
        }
        save(l)
        return n
    }

    /** Alarm bajne par ya reboot ke baad. */
    fun markDone(id: Long): TimerItem? {
        val l = load()
        val t = l.firstOrNull { it.id == id } ?: return null
        t.state = "DONE"
        save(l)
        return t
    }

    fun rescheduleAfterBoot(): List<TimerItem> {
        val missed = mutableListOf<TimerItem>()
        val l = load()
        val now = System.currentTimeMillis()
        l.forEach {
            if (it.state == "RUNNING") {
                if (it.deadline > now) schedule(it) else {
                    it.state = "DONE"
                    missed.add(it)
                }
            }
        }
        save(l)
        return missed
    }

    fun format(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%02d:%02d", m, sec)
    }
}
