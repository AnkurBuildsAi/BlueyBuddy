package com.orbo.assistant.command

import java.text.Normalizer

/**
 * Offline rule-based command parser (Hindi / Hinglish / English).
 * Ye general AI nahi hai: sirf known patterns pehchanta hai; baaki ko honestly Unknown bolta hai.
 */
object CommandParser {

    private fun nfc(s: String): String = Normalizer.normalize(s, Normalizer.Form.NFC)

    private val devMap: Map<String, String> = mapOf(
        "खोलो" to "kholo", "खोलिए" to "kholo", "खोल" to "kholo", "ओपन" to "open",
        "वापस" to "wapas", "जाओ" to "jao", "पीछे" to "peeche", "बैक" to "back", "होम" to "home",
        "स्क्रीन" to "screen", "नीचे" to "neeche", "ऊपर" to "upar", "स्क्रॉल" to "scroll",
        "समय" to "time", "टाइम" to "time", "बताओ" to "batao", "बताइए" to "batao", "बजे" to "baje", "कितने" to "kitne",
        "टाइमर" to "timer", "लगाओ" to "lagao", "लगा" to "lagao", "मिनट" to "minute", "सेकंड" to "second",
        "घंटा" to "hour", "घंटे" to "hour", "रुको" to "ruko", "बंद" to "band", "रद्द" to "cancel", "कैंसिल" to "cancel",
        "कॉपी" to "copy", "पेस्ट" to "paste", "पढ़ो" to "padho", "पढ़कर" to "padhkar", "पढ़" to "padho", "सुनाओ" to "sunao",
        "समझाओ" to "samjhao", "खोजो" to "khojo", "सर्च" to "search", "करो" to "karo", "कर" to "kar",
        "यूट्यूब" to "youtube", "व्हाट्सएप" to "whatsapp", "सेटिंग" to "settings", "सेटिंग्स" to "settings",
        "मैसेज" to "message", "ड्राफ्ट" to "draft", "फिर" to "phir", "और" to "aur", "रिजल्ट" to "result",
        "पहला" to "pehla", "दूसरा" to "doosra", "तीसरा" to "teesra", "सारांश" to "summary", "एरर" to "error", "मतलब" to "matlab",
        "एक" to "ek", "दो" to "do", "तीन" to "teen", "चार" to "char", "पांच" to "paanch", "पाँच" to "paanch",
        "छह" to "chhe", "सात" to "saat", "आठ" to "aath", "नौ" to "nau", "दस" to "das", "पंद्रह" to "pandrah",
        "बीस" to "bees", "पच्चीस" to "pachis", "तीस" to "tees", "चालीस" to "chalis", "पचास" to "pachas", "साठ" to "saath",
        "गैलरी" to "gallery", "कैमरा" to "camera", "क्रोम" to "chrome", "फोन" to "phone", "कैलकुलेटर" to "calculator",
        "गूगल" to "google", "इंस्टाग्राम" to "instagram", "फेसबुक" to "facebook", "रिज्यूमे" to "resume",
        "रोको" to "roko", "याद" to "yaad", "रखो" to "rakho", "स्टॉपवॉच" to "stopwatch", "स्टॉप" to "stop",
    ).mapKeys { nfc(it.key) }

    private val numWords: Map<String, Double> = mapOf(
        "ek" to 1.0, "do" to 2.0, "teen" to 3.0, "char" to 4.0, "chaar" to 4.0, "paanch" to 5.0, "panch" to 5.0,
        "chhe" to 6.0, "chhah" to 6.0, "che" to 6.0, "saat" to 7.0, "aath" to 8.0, "nau" to 9.0, "das" to 10.0,
        "gyarah" to 11.0, "barah" to 12.0, "pandrah" to 15.0, "bees" to 20.0, "pachis" to 25.0, "tees" to 30.0,
        "paintees" to 35.0, "chalis" to 40.0, "pachas" to 50.0, "pachaas" to 50.0, "saath" to 60.0,
        "one" to 1.0, "two" to 2.0, "three" to 3.0, "four" to 4.0, "five" to 5.0, "six" to 6.0, "seven" to 7.0,
        "eight" to 8.0, "nine" to 9.0, "ten" to 10.0, "fifteen" to 15.0, "twenty" to 20.0, "thirty" to 30.0,
    )

    private val fillers = setOf(
        "ko", "ka", "ki", "ke", "par", "pe", "mein", "me", "kar", "karo", "do", "dena", "please", "plz", "mujhe",
        "app", "application", "jao", "batao", "ab", "zara", "yaar", "orbo", "orbi", "the", "a", "to", "kholna", "kijiye", "kijiye",
        "chalu", "start", "launch", "open", "kholo", "khol", "kholiye", "lagao", "laga",
    )

    private val openWords = setOf("kholo", "khol", "open", "kholiye", "kholna", "launch", "chalu", "start")

    fun normalize(raw: String): List<String> {
        var s = nfc(raw.lowercase())
        s = s.replace(Regex("[\u0966-\u096F]")) { (it.value[0].code - 0x0966).toString() }
        s = s.replace(Regex("[^\\p{L}\\p{M}\\p{N}\\s]"), " ")
        return s.split(Regex("\\s+")).filter { it.isNotBlank() }.map { devMap[it] ?: it }
    }

    /** Settings se jude hooks (unit test mein default khali rehte hain). */
    var disabledKeys: () -> Set<String> = { emptySet() }
    var customPhrases: () -> List<Pair<String, String>> = { emptyList() }

    fun parse(raw: String): Cmd {
        val text = raw.trim()
        if (text.isEmpty()) return Cmd.Unknown(raw, "Khali command")
        // user ke apne (train kiye) phrases pehle
        val norm = normalize(text).joinToString(" ")
        for ((phrase, target) in customPhrases()) {
            val p = normalize(phrase).joinToString(" ")
            if (p.isNotEmpty() && (norm == p || norm.contains(p))) return applyDisabled(parseCore(target))
        }
        return applyDisabled(parseCore(text))
    }

    private fun applyDisabled(c: Cmd): Cmd {
        val off = disabledKeys()
        if (off.isEmpty()) return c
        val steps = if (c is Cmd.Compound) c.steps else listOf(c)
        for (st in steps) {
            val k = st.key()
            if (k.isNotEmpty() && k in off) return Cmd.Unknown("", "Ye command Settings > Commands mein band hai ($k).")
        }
        return c
    }

    private fun parseCore(raw: String): Cmd {
        val text = raw.trim()
        if (text.isEmpty()) return Cmd.Unknown(raw, "Khali command")
        // pehle comma / semicolon / new line par todo, phir har piece ke andar phir/aur/then par.
        val pieces = text.split(Regex("[,;\\n]")).filter { it.isNotBlank() }
        val segs = mutableListOf<List<String>>()
        for (piece in pieces) {
            segs.addAll(splitSegments(normalize(piece)))
        }
        if (segs.size > 1) {
            val parsed = segs.map { parseSingle(it, text) }
            if (parsed.none { it is Cmd.Unknown }) return Cmd.Compound(parsed)
        }
        return parseSingle(normalize(text), text)
    }

    private fun splitSegments(tokens: List<String>): List<List<String>> {
        val out = mutableListOf<MutableList<String>>(mutableListOf())
        var i = 0
        while (i < tokens.size) {
            val t = tokens[i]
            if (t == "phir" || t == "fir" || t == "then") {
                out.add(mutableListOf())
            } else if (t == "uske" && i + 1 < tokens.size && tokens[i + 1] == "baad") {
                out.add(mutableListOf())
                i++
            } else if (t == "aur" || t == "and") {
                val before = out.last().toList()
                val after = tokens.drop(i + 1)
                if (before.isNotEmpty() && after.isNotEmpty() &&
                    parseSingle(before, "") !is Cmd.Unknown && parseSingle(after, "") !is Cmd.Unknown
                ) {
                    out.add(mutableListOf())
                } else {
                    out.last().add(t)
                }
            } else {
                out.last().add(t)
            }
            i++
        }
        return out.filter { it.isNotEmpty() }
    }

    private fun parseSingle(tokens: List<String>, raw: String): Cmd {
        if (tokens.isEmpty()) return Cmd.Unknown(raw, "Khali command")
        fun has(vararg w: String) = tokens.any { it in w }
        val joined = tokens.joinToString(" ")

        // yaad rakho
        if (has("yaad") && has("rakho") || joined.startsWith("remember")) {
            val body = tokens.filter { it !in setOf("yaad", "rakho", "remember", "ki", "ye", "that") }.joinToString(" ")
            return if (body.isBlank()) Cmd.Unknown(raw, "Kya yaad rakhun? Jaise: 'yaad rakho meri chai meethi hai'") else Cmd.Remember(body)
        }
        // skill
        if (has("skill") && (has("chalao", "run", "start", "karo", "chalu"))) {
            val name = tokens.filter { it !in setOf("skill", "chalao", "run", "start", "karo", "chalu", "ko") }.joinToString(" ")
            return Cmd.RunSkill(name)
        }
        // stopwatch
        if (has("stopwatch")) {
            return Cmd.Stopwatch(!has("band", "stop", "ruko", "roko"))
        }
        // message (pehle, kyunki body mein "home" jaise shabd ho sakte hain)
        if (has("message", "msg", "sms", "whatsapp", "text") && has("draft", "likho", "bhejo", "bhej", "send", "bolo")) {
            val sendVerb = has("bhejo", "bhej", "send")
            val stopw = setOf("message", "msg", "sms", "draft", "whatsapp", "text", "par", "pe", "me", "mein", "pr")
            var to: String? = null
            val koIdx = tokens.indexOf("ko")
            if (koIdx > 0) to = tokens.take(koIdx).filter { it !in stopw }.joinToString(" ").ifBlank { null }
            val kiIdx = tokens.indexOfFirst { it == "ki" || it == "ke" || it == "that" }
            var body = ""
            if (kiIdx >= 0) {
                body = tokens.drop(kiIdx + 1).joinToString(" ")
            } else {
                val vIdx = tokens.indexOfFirst { it in setOf("bhejo", "bhej", "send", "likho") }
                if (vIdx >= 0 && vIdx + 1 < tokens.size) body = tokens.drop(vIdx + 1).joinToString(" ")
            }
            val via = if (has("sms") && !has("whatsapp")) "sms" else "whatsapp"
            return if (sendVerb && to != null) Cmd.SendMessage(to, body, via) else Cmd.DraftMessage(to, body)
        }
        // Orb ko control (chhote commands)
        if (tokens.size <= 4) {
            if (has("come") || has("aao") || (has("bahar") && has("aa", "nikalo"))) return Cmd.OrbComeOut
            if ((has("orbo", "orb") && has("andar", "chhup", "gayab", "hide", "home")) || has("chhup", "gayab") ||
                (has("go") && has("to") && has("home"))
            ) return Cmd.OrbGoHome
            if (has("sleep") || (has("so") && has("jao"))) return Cmd.OrbSleep
            if (has("jaago", "wake", "uth")) return Cmd.OrbWake
        }
        // timer / reminder
        if (has("timer") || (has("yaad") && has("dila", "dilao", "dilana")) || has("reminder")) {
            if (has("cancel", "hata", "delete", "band") && has("timer")) return Cmd.TimerCancel
            if (has("pause", "roko") && has("timer")) return Cmd.TimerPause
            if (has("resume", "continue") && has("timer")) return Cmd.TimerResume
            val secs = parseDurationSeconds(tokens)
            if (secs > 0) {
                val label = if (has("reminder", "yaad")) tokens.joinToString(" ") else "Timer"
                return Cmd.TimerSet(secs, label)
            }
            return Cmd.Unknown(raw, "Timer ka time nahi mila. Jaise: '10 minute ka timer lagao'")
        }
        // time
        if ((has("time") && has("batao", "kya", "current", "what", "tell")) || (has("kitne") && has("baje")) || joined == "time" || has("samay")) {
            return Cmd.Time
        }
        // short control commands
        if (tokens.size <= 3) {
            if (has("stop", "ruko", "roko") && !has("timer")) return Cmd.Stop
            if (has("cancel") ) return Cmd.Cancel
            if (has("pause")) return Cmd.Pause
            if (has("resume", "continue", "jari", "aage")) return Cmd.Resume
        }
        // youtube par chalao
        if (has("youtube") && has("chalao", "play", "dikhao")) {
            val stopY = setOf("youtube", "chalao", "play", "dikhao", "par", "pe", "me", "mein", "ka", "ki", "ke", "karo", "kar", "do", "video")
            val q = tokens.filter { it !in stopY }.joinToString(" ")
            return if (q.isBlank()) Cmd.OpenApp("youtube") else Cmd.Compound(listOf(Cmd.Search(q, "youtube"), Cmd.OpenResult(1)))
        }
        // search
        if (has("search", "khojo", "dhundo", "dhoondo", "google")) {
            val stop = setOf("search", "khojo", "dhundo", "dhoondo", "google", "karo", "kar", "do", "par", "pe", "me", "mein", "ke", "baare", "bare", "about", "for", "internet", "web")
            val site = if (has("youtube")) "youtube" else "google"
            val q = tokens.filter { it !in stop && !(site == "youtube" && it == "youtube") }.joinToString(" ")
            return if (q.isBlank()) Cmd.Unknown(raw, "Kya search karun? Jaise: 'JEE Physics search karo'") else Cmd.Search(q, site)
        }
        // result open
        if (has("result") && has("kholo", "open", "khol")) {
            val n = when {
                has("pehla", "first", "1") -> 1
                has("doosra", "second", "2") -> 2
                has("teesra", "third", "3") -> 3
                else -> 1
            }
            return Cmd.OpenResult(n)
        }
        // navigation
        if (has("swipe")) {
            val dir = when {
                has("left", "baayen", "bayen") -> "left"
                has("right", "daayen", "dayen") -> "right"
                has("up", "upar") -> "up"
                has("down", "neeche", "niche") -> "down"
                else -> null
            }
            return if (dir == null) Cmd.Unknown(raw, "Kis taraf swipe? left / right / up / down bolo.") else Cmd.Swipe(dir)
        }
        if (has("screenshot")) return Cmd.Screenshot
        if (has("notification", "notifications")) return Cmd.Notifications
        if (has("lock") && has("screen", "phone")) return Cmd.LockScreen
        if (has("back") || (has("peeche", "wapas") && has("jao"))) return Cmd.Back
        if (has("recents", "recent")) return Cmd.Recents
        if (has("home") || has("ghar")) return Cmd.Home
        if (has("scroll") || ((has("neeche", "niche", "upar", "down", "up")) && has("jao", "karo"))) {
            return if (has("up", "upar")) Cmd.ScrollUp else Cmd.ScrollDown
        }
        // settings
        if (has("settings", "setting")) {
            val page = when {
                has("wifi", "wi") -> "wifi"
                has("bluetooth") -> "bluetooth"
                has("display", "brightness") -> "display"
                has("sound", "volume") -> "sound"
                has("battery") -> "battery"
                has("accessibility") -> "accessibility"
                has("location") -> "location"
                has("apps") -> "apps"
                has("security") -> "security"
                has("storage") -> "storage"
                has("date") -> "date"
                else -> "main"
            }
            return Cmd.OpenSettings(page)
        }
        // screen / text
        if (has("copy")) return Cmd.Copy
        if (has("paste")) return Cmd.Paste
        if (has("cut")) return Cmd.Cut
        if (has("select") && has("all", "sab")) return Cmd.SelectAll
        if (has("bolo", "speak") && tokens.size >= 2) {
            val body = tokens.filter { it !in setOf("bolo", "speak", "karo", "kar", "ki") }.joinToString(" ")
            if (body.isNotBlank()) return Cmd.Speak(body)
        }
        if (has("error") && has("matlab", "meaning", "kya", "explain", "samjhao")) return Cmd.ExplainError
        if (has("summary", "summarize", "saransh")) return Cmd.Summarize
        if (has("padho", "padhkar", "read", "sunao")) return Cmd.ReadAloud
        if (has("samjhao", "explain") || (has("screen") && has("likha", "kya"))) return Cmd.ExplainScreen
        // type text
        if (has("type") || (has("likho") && !has("message", "msg"))) {
            val body = tokens.filter { it !in setOf("type", "likho", "karo", "kar") }.joinToString(" ")
            return if (body.isBlank()) Cmd.Unknown(raw, "Kya likhna hai?") else Cmd.TypeText(body)
        }
        // click
        if (has("click", "tap", "dabao", "dabana")) {
            val body = tokens.filter { it !in setOf("click", "tap", "dabao", "dabana", "karo", "kar", "par", "pe", "ko") }.joinToString(" ")
            return if (body.isBlank()) Cmd.Unknown(raw, "Kispe click karun?") else Cmd.ClickText(body)
        }
        // open app
        if (tokens.any { it in openWords }) {
            val q = tokens.filter { it !in fillers }.joinToString(" ")
            return if (q.isBlank()) Cmd.Unknown(raw, "Kaunsa app kholun?") else Cmd.OpenApp(q)
        }
        return Cmd.Unknown(
            raw,
            "Ye command supported nahi hai. Try: 'YouTube kholo', 'back jao', 'scroll down', '10 minute ka timer lagao', 'current time batao', 'is page ko padho'",
        )
    }

    /** "10 minute", "ek ghanta", "aadha ghanta", "1 hour 30 minute" -> seconds. */
    fun parseDurationSeconds(tokens: List<String>): Long {
        var total = 0.0
        var i = 0
        while (i < tokens.size) {
            val t = tokens[i]
            var n: Double? = t.toDoubleOrNull() ?: numWords[t]
            if (t == "aadha" || t == "adha" || t == "half") n = 0.5
            if (t == "dedh") n = 1.5
            if (t == "dhai") n = 2.5
            if (n != null && i + 1 < tokens.size) {
                val unit = tokens[i + 1]
                val mult = when (unit) {
                    "second", "seconds", "sec", "secs", "sekand" -> 1.0
                    "minute", "minutes", "min", "mins" -> 60.0
                    "hour", "hours", "ghanta", "ghante", "ghanta", "hr", "hrs" -> 3600.0
                    else -> 0.0
                }
                if (mult > 0.0) {
                    total += n * mult
                    i += 2
                    continue
                }
            }
            i++
        }
        return total.toLong()
    }
}
