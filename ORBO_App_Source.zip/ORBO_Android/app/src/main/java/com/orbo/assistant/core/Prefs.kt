package com.orbo.assistant.core

import android.content.Context
import android.content.SharedPreferences

/** Simple settings (SharedPreferences). PIN verifier Keystore se encrypt hoke yahin blob ke roop mein rehta hai. */
class Prefs(ctx: Context) {
    private val sp: SharedPreferences = ctx.getSharedPreferences("orbo_prefs", Context.MODE_PRIVATE)

    var orbSizeDp: Int
        get() = sp.getInt("orbSizeDp", 68)
        set(v) { sp.edit().putInt("orbSizeDp", v.coerceIn(48, 100)).apply() }

    var orbX: Int
        get() = sp.getInt("orbX", Int.MIN_VALUE)
        set(v) { sp.edit().putInt("orbX", v).apply() }

    var orbY: Int
        get() = sp.getInt("orbY", Int.MIN_VALUE)
        set(v) { sp.edit().putInt("orbY", v).apply() }

    var longPressMs: Long
        get() = sp.getLong("longPressMs", 500L)
        set(v) { sp.edit().putLong("longPressMs", v.coerceIn(250L, 1500L)).apply() }

    var silenceSec: Int
        get() = sp.getInt("silenceSec", 10)
        set(v) { sp.edit().putInt("silenceSec", v).apply() }

    var lang: String
        get() = sp.getString("lang", "hi-IN") ?: "hi-IN"
        set(v) { sp.edit().putString("lang", v).apply() }

    var reducedMotion: Boolean
        get() = sp.getBoolean("reducedMotion", false)
        set(v) { sp.edit().putBoolean("reducedMotion", v).apply() }

    var sleepyEnabled: Boolean
        get() = sp.getBoolean("sleepyEnabled", false)
        set(v) { sp.edit().putBoolean("sleepyEnabled", v).apply() }

    var overlayEnabled: Boolean
        get() = sp.getBoolean("overlayEnabled", false)
        set(v) { sp.edit().putBoolean("overlayEnabled", v).apply() }

    var speakReplies: Boolean
        get() = sp.getBoolean("speakReplies", true)
        set(v) { sp.edit().putBoolean("speakReplies", v).apply() }

    var securityEnabled: Boolean
        get() = sp.getBoolean("securityEnabled", false)
        set(v) { sp.edit().putBoolean("securityEnabled", v).apply() }

    var verifyOnUnlock: Boolean
        get() = sp.getBoolean("verifyOnUnlock", false)
        set(v) { sp.edit().putBoolean("verifyOnUnlock", v).apply() }

    var failThreshold: Int
        get() = sp.getInt("failThreshold", 5)
        set(v) { sp.edit().putInt("failThreshold", v.coerceIn(3, 10)).apply() }

    var graceMinutes: Int
        get() = sp.getInt("graceMinutes", 2)
        set(v) { sp.edit().putInt("graceMinutes", v.coerceIn(0, 30)).apply() }

    var verifiedUntil: Long
        get() = sp.getLong("verifiedUntil", 0L)
        set(v) { sp.edit().putLong("verifiedUntil", v).apply() }

    var selectedApps: Set<String>
        get() = sp.getStringSet("selectedApps", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("selectedApps", HashSet(v)).apply() }

    var pinFailCount: Int
        get() = sp.getInt("pinFailCount", 0)
        set(v) { sp.edit().putInt("pinFailCount", v).apply() }

    var pinLockedUntil: Long
        get() = sp.getLong("pinLockedUntil", 0L)
        set(v) { sp.edit().putLong("pinLockedUntil", v).apply() }

    var pinBlob: String?
        get() = sp.getString("pinBlob", null)
        set(v) { sp.edit().putString("pinBlob", v).apply() }

    var stopwatchStart: Long
        get() = sp.getLong("stopwatchStart", 0L)
        set(v) { sp.edit().putLong("stopwatchStart", v).apply() }

    // ---- face / lock ----
    var faceEnabled: Boolean
        get() = sp.getBoolean("faceEnabled", true)
        set(v) { sp.edit().putBoolean("faceEnabled", v).apply() }

    var faceThreshold: Float
        get() = sp.getFloat("faceThreshold", 0.65f)
        set(v) { sp.edit().putFloat("faceThreshold", v.coerceIn(0.30f, 0.95f)).apply() }

    /** 0 = (x-127.5)/127.5, 1 = x/255, 2 = ImageNet mean/std */
    var facePreproc: Int
        get() = sp.getInt("facePreproc", 0)
        set(v) { sp.edit().putInt("facePreproc", v).apply() }

    var escapeEnabled: Boolean
        get() = sp.getBoolean("escapeEnabled", false)
        set(v) { sp.edit().putBoolean("escapeEnabled", v).apply() }

    var escapeCount: Int
        get() = sp.getInt("escapeCount", 5)
        set(v) { sp.edit().putInt("escapeCount", v.coerceIn(3, 10)).apply() }

    var comeOutOnUnlock: Boolean
        get() = sp.getBoolean("comeOutOnUnlock", true)
        set(v) { sp.edit().putBoolean("comeOutOnUnlock", v).apply() }

    // ---- orb home / dock ----
    var homeHidden: Boolean
        get() = sp.getBoolean("homeHidden", false)
        set(v) { sp.edit().putBoolean("homeHidden", v).apply() }

    /** 0 none, 1 left, 2 right, 3 top, 4 bottom */
    var dockEdge: Int
        get() = sp.getInt("dockEdge", 0)
        set(v) { sp.edit().putInt("dockEdge", v).apply() }

    // ---- commands / messaging ----
    var disabledCommands: Set<String>
        get() = sp.getStringSet("disabledCommands", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("disabledCommands", HashSet(v)).apply() }

    var countryCode: String
        get() = sp.getString("countryCode", "91") ?: "91"
        set(v) { sp.edit().putString("countryCode", v.filter { it.isDigit() }.take(4)).apply() }

    // ---- optional AI ----
    var aiEnabled: Boolean
        get() = sp.getBoolean("aiEnabled", false)
        set(v) { sp.edit().putBoolean("aiEnabled", v).apply() }

    var aiProvider: String
        get() = sp.getString("aiProvider", "OPENAI") ?: "OPENAI"
        set(v) { sp.edit().putString("aiProvider", v).apply() }

    var aiBaseUrl: String
        get() = sp.getString("aiBaseUrl", "") ?: ""
        set(v) { sp.edit().putString("aiBaseUrl", v.trim()).apply() }

    var aiModel: String
        get() = sp.getString("aiModel", "") ?: ""
        set(v) { sp.edit().putString("aiModel", v.trim()).apply() }

    var aiKeyBlob: String?
        get() = sp.getString("aiKeyBlob", null)
        set(v) { sp.edit().putString("aiKeyBlob", v).apply() }
}
