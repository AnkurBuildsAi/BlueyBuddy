Face model yahan `face_model.tflite` naam se rakhi jaati hai (112x112 input, 128/192/512-d embedding, jaise MobileFaceNet).
Ye file repo ke root mein upload karo to GitHub workflow ise yahan copy kar deta hai.
Ya app ke Security tab > "Model import" se phone se chuno.
