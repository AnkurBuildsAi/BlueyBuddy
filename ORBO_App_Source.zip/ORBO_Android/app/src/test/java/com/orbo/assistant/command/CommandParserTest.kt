package com.orbo.assistant.command

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandParserTest {

    @Test
    fun openApp() {
        assertEquals(Cmd.OpenApp("youtube"), CommandParser.parse("YouTube kholo"))
    }

    @Test
    fun timer() {
        assertEquals(Cmd.TimerSet(600, "Timer"), CommandParser.parse("10 minute ka timer lagao"))
    }

    @Test
    fun navigation() {
        assertEquals(Cmd.Back, CommandParser.parse("back jao"))
        assertEquals(Cmd.Home, CommandParser.parse("home screen par jao"))
        assertEquals(Cmd.ScrollDown, CommandParser.parse("scroll down"))
        assertEquals(Cmd.ScrollUp, CommandParser.parse("scroll up"))
    }

    @Test
    fun timeAndScreen() {
        assertEquals(Cmd.Time, CommandParser.parse("current time batao"))
        assertEquals(Cmd.ReadAloud, CommandParser.parse("is page ko padho"))
        assertEquals(Cmd.Copy, CommandParser.parse("is text ko copy karo"))
        assertEquals(Cmd.ExplainScreen, CommandParser.parse("screen par kya likha hai"))
    }

    @Test
    fun compoundSearchTask() {
        val c = CommandParser.parse("Physics lecture search karo, useful result kholo aur samjhao")
        assertEquals(
            Cmd.Compound(listOf(Cmd.Search("physics lecture", "google"), Cmd.OpenResult(1), Cmd.ExplainScreen)),
            c,
        )
    }

    @Test
    fun durations() {
        assertEquals(5400L, CommandParser.parseDurationSeconds(CommandParser.normalize("ek ghanta tees minute")))
        assertEquals(1800L, CommandParser.parseDurationSeconds(CommandParser.normalize("aadha ghanta")))
    }

    @Test
    fun unknownIsHonest() {
        assertTrue(CommandParser.parse("xyz qwerty") is Cmd.Unknown)
    }

    @Test
    fun sendMessage() {
        assertEquals(
            Cmd.SendMessage("rahul", "main late aunga", "whatsapp"),
            CommandParser.parse("Rahul ko whatsapp par message bhejo ki main late aunga"),
        )
    }

    @Test
    fun orbCommands() {
        assertEquals(Cmd.OrbGoHome, CommandParser.parse("orbo andar jao"))
        assertEquals(Cmd.OrbComeOut, CommandParser.parse("bahar aao"))
        assertEquals(Cmd.OrbSleep, CommandParser.parse("get sleep"))
    }

    @Test
    fun swipeAndYoutube() {
        assertEquals(Cmd.Swipe("left"), CommandParser.parse("swipe left"))
        assertEquals(
            Cmd.Compound(listOf(Cmd.Search("arijit", "youtube"), Cmd.OpenResult(1))),
            CommandParser.parse("youtube par arijit chalao"),
        )
    }

    @Test
    fun customAndDisabled() {
        try {
            CommandParser.customPhrases = { listOf("padhai shuru" to "25 minute ka timer lagao") }
            assertEquals(Cmd.TimerSet(1500, "Timer"), CommandParser.parse("Padhai shuru"))
            CommandParser.disabledKeys = { setOf("back") }
            assertTrue(CommandParser.parse("back jao") is Cmd.Unknown)
        } finally {
            CommandParser.customPhrases = { emptyList() }
            CommandParser.disabledKeys = { emptySet() }
        }
    }
}
