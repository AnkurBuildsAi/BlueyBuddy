package com.orbo.assistant.orb

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OrbStateMachineTest {

    @Test
    fun startsIdle() {
        assertEquals(OrbState.IDLE, OrbStateMachine().state.value)
    }

    @Test
    fun happyPath_listeningToCompleted() {
        val m = OrbStateMachine()
        assertTrue(m.transitionTo(OrbState.LISTENING))
        assertTrue(m.transitionTo(OrbState.THINKING))
        assertTrue(m.transitionTo(OrbState.EXECUTING))
        assertTrue(m.transitionTo(OrbState.COMPLETED))
        assertEquals(OrbState.COMPLETED, m.state.value)
    }

    @Test
    fun failurePath_listeningThinkingError() {
        val m = OrbStateMachine()
        assertTrue(m.transitionTo(OrbState.LISTENING))
        assertTrue(m.transitionTo(OrbState.THINKING))
        assertTrue(m.transitionTo(OrbState.ERROR))
        assertEquals(OrbState.ERROR, m.state.value)
    }

    @Test
    fun verificationPath() {
        val m = OrbStateMachine()
        assertTrue(m.transitionTo(OrbState.VERIFICATION_PENDING))
        assertTrue(m.transitionTo(OrbState.FACE_FAILED))
        assertTrue(m.transitionTo(OrbState.SECURITY_REQUIRED))
        assertTrue(m.transitionTo(OrbState.VERIFIED))
    }

    @Test
    fun invalidTransitionIsRejectedAndStateUnchanged() {
        val m = OrbStateMachine()
        assertFalse(m.transitionTo(OrbState.COMPLETED))
        assertFalse(m.transitionTo(OrbState.VERIFIED))
        assertEquals(OrbState.IDLE, m.state.value)
    }

    @Test
    fun sameStateIsRejected() {
        val m = OrbStateMachine()
        assertFalse(m.transitionTo(OrbState.IDLE))
    }

    @Test
    fun resetAlwaysGoesIdle() {
        val m = OrbStateMachine()
        m.transitionTo(OrbState.LISTENING)
        m.reset()
        assertEquals(OrbState.IDLE, m.state.value)
    }

    @Test
    fun everyStateHasAFace() {
        OrbState.entries.forEach { it.toFace() }
    }
}
