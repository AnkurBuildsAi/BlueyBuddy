# Bluey Buddy — Android starter

A small original Android floating mascot prototype inspired by the idea of a movable animated companion. It is **not** a port of the original Bluey project and does not include its proprietary artwork.

## Included
- Floating mascot overlay (Android's “display over other apps” permission required)
- Original Canvas-drawn character with blinking eyes, gaze movement, breathing/bobbing, expressions, and drag movement
- Single tap cycles expressions; double tap or long press opens the chat screen
- Optional Gemini text chat; a reply can trigger a simple mood expression
- GitHub Actions workflow to build a debug APK and upload it as an artifact

## Limits / important
- This is a prototype, not a guarantee that every feature works on every Android skin. Test on the target phone.
- No screen-reading, auto-clicking, voice input, persistent conversation memory, or original Bluey assets are included.
- Gemini requires a valid API key and internet. This starter stores the key in app preferences, which is convenient for testing but **not secure enough for a public release**. Never commit a real key to GitHub or share it in chat. A production app should call Gemini through a backend.
- Google may change model availability, quotas, or API requirements. If the selected model returns an API error, check the current Gemini API model list and update the model name.

## Build APK on a phone with GitHub Actions
1. Upload the contents of this folder to a new GitHub repository (not the ZIP file itself; extract it first).
2. Open the repository's **Actions** tab and enable workflows if asked.
3. Run **Build Bluey Buddy APK** with **Run workflow**, or push a commit to `main`.
4. Open the successful workflow run and download the `BlueyBuddy-debug-apk` artifact. Extract it and install `app-debug.apk` on your phone.
5. Android may ask permission to install apps from the browser/file manager. Only install APKs you built and trust.

## Phone compatibility
Minimum Android API is 27 (Android 8.1). Android 8.1 and OEM battery-management settings can still affect overlay/background behaviour. Grant “Display over other apps” permission and allow the ongoing notification. If the mascot disappears, open the app and start it again.
