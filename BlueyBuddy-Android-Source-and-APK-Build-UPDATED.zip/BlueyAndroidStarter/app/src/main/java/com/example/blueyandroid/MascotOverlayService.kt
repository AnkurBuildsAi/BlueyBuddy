package com.example.blueyandroid

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.Toast
import kotlin.math.*
import kotlin.random.Random

class MascotOverlayService : Service() {
    companion object {
        const val ACTION_START = "com.example.blueyandroid.START"
        const val ACTION_MOOD = "com.example.blueyandroid.MOOD"
        const val EXTRA_MOOD = "mood"
        private const val CHANNEL = "bluey_mascot"
        private const val NOTIFICATION_ID = 7421
    }
    private lateinit var wm: WindowManager
    private var bubble: MascotView? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        val stop = PendingIntent.getService(this, 1, Intent(this, MascotOverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag())
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        startForeground(NOTIFICATION_ID, notification.setContentTitle("Bluey Buddy is active").setContentText("Tap mascot for expressions; double-tap for Gemini chat").setSmallIcon(android.R.drawable.ic_dialog_info).addAction(android.R.drawable.ic_media_pause, "Stop", stop).setOngoing(true).build())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { removeBubble(); stopSelf(); return START_NOT_STICKY }
        if (intent?.action == ACTION_MOOD) { intent.getStringExtra(EXTRA_MOOD)?.let { bubble?.setMood(it) }; return START_STICKY }
        if (bubble == null && android.provider.Settings.canDrawOverlays(this)) showBubble()
        return START_STICKY
    }

    private fun showBubble() {
        val size = (116 * resources.displayMetrics.density).toInt()
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(size, size, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = (resources.displayMetrics.widthPixels - size).coerceAtLeast(0) / 2
        p.y = (resources.displayMetrics.heightPixels * 0.28f).toInt()
        val view = MascotView(this)
        view.onOpenChat = {
            val i = Intent(this, MainActivity::class.java).setAction(MainActivity.ACTION_LISTEN).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(i)
        }
        view.onToast = { message -> Toast.makeText(this, message, Toast.LENGTH_SHORT).show() }
        try { wm.addView(view, p); bubble = view; params = p }
        catch (_: Exception) { Toast.makeText(this, "Overlay permission required", Toast.LENGTH_LONG).show(); stopSelf() }
    }

    private fun removeBubble() { bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble = null; params = null }
    override fun onDestroy() { removeBubble(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
    private fun immutableFlag() = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
    private fun createNotificationChannel() { if (Build.VERSION.SDK_INT >= 26) { val channel = NotificationChannel(CHANNEL, "Floating mascot", NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager::class.java).createNotificationChannel(channel) } }

    private class MascotView(context: Context) : View(context) {
        var onOpenChat: (() -> Unit)? = null
        var onToast: ((String) -> Unit)? = null
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val bounds = RectF()
        private val moods = arrayOf("listening", "happy", "thinking", "sleepy", "surprised", "resting")
        private var moodIndex = 0
        private var gazeX = 0f; private var gazeY = 0f
        private var targetX = 0f; private var targetY = 0f
        private var blink = 0f; private var blinkAt = System.currentTimeMillis() + 1800
        private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0
        private var dragged = false; private var lastTap = 0L; private var pressStart = 0L
        private var bounce = 0f; private var targetBounce = 0f
        private val density = resources.displayMetrics.density
        private val blueTop = Color.rgb(79, 139, 255); private val blueBottom = Color.rgb(40, 65, 206)
        private val loop = object : Runnable { override fun run() {
            val now = System.currentTimeMillis()
            if (now >= blinkAt) { blink = 1f; blinkAt = now + Random.nextLong(2200, 5200) }
            else if (blink > 0f) blink = max(0f, blink - 0.20f)
            if (Random.nextFloat() < 0.018f) { targetX = Random.nextFloat() * 1.1f - 0.55f; targetY = Random.nextFloat() * 0.65f - 0.4f }
            gazeX += (targetX - gazeX) * 0.12f; gazeY += (targetY - gazeY) * 0.12f
            bounce += (targetBounce - bounce) * 0.22f; targetBounce *= 0.72f
            invalidate(); postDelayed(this, 33)
        } }
        init { setLayerType(LAYER_TYPE_HARDWARE, null); post(loop); contentDescription = "Bluey floating animated mascot" }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val s = min(width, height).toFloat(); val cx = width / 2f; val cy = height * 0.57f
            val bob = sin(System.currentTimeMillis() / 430.0).toFloat() * 1.8f * density - bounce * 4f * density
            val squash = 1f + bounce * .035f
            canvas.save(); canvas.translate(0f, bob); canvas.scale(1f / squash, squash, cx, cy)
            bounds.set(width * .06f, height * .08f, width * .94f, height * .98f)
            paint.shader = LinearGradient(bounds.left, bounds.top, bounds.right, bounds.bottom, blueTop, blueBottom, Shader.TileMode.CLAMP)
            canvas.drawOval(bounds, paint); paint.shader = null
            // glossy shine
            paint.color = Color.argb(45, 255, 255, 255); canvas.drawOval(width*.19f, height*.14f, width*.61f, height*.49f, paint)
            // eye positions and expressions
            val eyeY = cy - s*.06f
            val eyeGap = s*.19f
            val eyeW = s*.29f; val eyeH = s*.34f
            val sleepy = moods[moodIndex] == "sleepy" || moods[moodIndex] == "resting"
            for (side in -1..1 step 2) {
                val ex = cx + side * eyeGap
                paint.color = Color.WHITE
                val eh = eyeH * (1f - if (sleepy) .42f else blink * .92f)
                canvas.drawOval(ex-eyeW/2, eyeY-eh/2, ex+eyeW/2, eyeY+eh/2, paint)
                if (eh > eyeH*.25f) {
                    val px = ex + gazeX * eyeW*.22f; val py = eyeY + gazeY * eyeH*.20f
                    paint.color = Color.rgb(30, 38, 82); canvas.drawCircle(px, py, s*.072f, paint)
                    paint.color = Color.WHITE; canvas.drawCircle(px-s*.025f, py-s*.027f, s*.022f, paint)
                }
                // expressive eyebrow
                paint.color = Color.rgb(27, 42, 124); paint.strokeWidth = s*.035f; paint.strokeCap = Paint.Cap.ROUND; paint.style = Paint.Style.STROKE
                val browY = eyeY-eyeH*.61f + if (moods[moodIndex] == "surprised") -s*.035f else 0f
                canvas.drawLine(ex-eyeW*.32f, browY, ex+eyeW*.28f, browY + if (moods[moodIndex] == "thinking") s*.035f else -s*.015f, paint)
                paint.style = Paint.Style.FILL
            }
            // small mouth changes with mood
            paint.color = Color.rgb(26, 39, 128)
            when (moods[moodIndex]) {
                "happy" -> { paint.style = Paint.Style.STROKE; paint.strokeWidth = s*.035f; canvas.drawArc(cx-s*.12f, cy+s*.11f, cx+s*.12f, cy+s*.27f, 10f, 160f, false, paint); paint.style = Paint.Style.FILL }
                "surprised" -> canvas.drawCircle(cx, cy+s*.19f, s*.035f, paint)
                "sleepy" -> canvas.drawLine(cx-s*.06f, cy+s*.18f, cx+s*.06f, cy+s*.18f, paint)
                else -> canvas.drawOval(cx-s*.065f, cy+s*.14f, cx+s*.065f, cy+s*.20f, paint)
            }
            // blush cheeks
            paint.color = Color.argb(65, 255, 120, 165); canvas.drawCircle(cx-s*.29f, cy+s*.12f, s*.055f, paint); canvas.drawCircle(cx+s*.29f, cy+s*.12f, s*.055f, paint)
            // tiny crown
            paint.color = Color.rgb(30, 51, 159)
            val crown = Path().apply { moveTo(cx-s*.15f, height*.12f); lineTo(cx-s*.10f, height*.03f); lineTo(cx, height*.10f); lineTo(cx+s*.08f, height*.025f); lineTo(cx+s*.15f, height*.13f); close() }
            canvas.drawPath(crown, paint)
            canvas.restore()
        }

        fun setMood(name: String) { val idx = moods.indexOf(name.lowercase()); if (idx >= 0) { moodIndex = idx; targetBounce = 1f; invalidate() } }

        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            val p = paramsForWindow() ?: return true
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = p.x; startY = p.y; dragged = false; pressStart = System.currentTimeMillis(); return true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX-downX).toInt(); val dy = (event.rawY-downY).toInt()
                    if (abs(dx) > 5 || abs(dy) > 5) dragged = true
                    if (dragged) { p.x = (startX+dx).coerceIn(0, resources.displayMetrics.widthPixels-width); p.y = (startY+dy).coerceIn(0, resources.displayMetrics.heightPixels-height); try { (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).updateViewLayout(this, p) } catch (_: Exception) {} }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) {
                        val now = System.currentTimeMillis()
                        if (now - pressStart > 650L) { onOpenChat?.invoke() }
                        else if (now-lastTap < 350L) { lastTap = 0L; onOpenChat?.invoke() }
                        else { lastTap = now; postDelayed({ if (lastTap == now) { moodIndex = (moodIndex+1)%moods.size; targetBounce = 1f; onToast?.invoke("Mood: ${moods[moodIndex]}"); invalidate() } }, 360L) }
                    }
                    performClick(); return true
                }
            }
            return true
        }
        override fun performClick(): Boolean { super.performClick(); return true }
        private fun paramsForWindow(): WindowManager.LayoutParams? = layoutParams as? WindowManager.LayoutParams
    }
}
