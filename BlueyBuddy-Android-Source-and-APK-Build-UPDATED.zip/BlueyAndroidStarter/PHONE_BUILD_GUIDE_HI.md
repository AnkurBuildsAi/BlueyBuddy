# Phone se APK banane ka guide (Hindi)

**Sachchi baat:** is source ZIP mein Android prototype hai, final tested APK nahi. Main yahan aapke Oppo phone par install karke test nahi kar sakta. Pehle GitHub Actions se APK build karein, phir apne phone par test karein.

## 1) ZIP taiyar karein
- ZIP ko phone ke File Manager mein extract karein.
- Extract hue `BlueyAndroidStarter` folder ke andar `app`, `.github`, `build.gradle`, `settings.gradle` waali files honi chahiye.

## 2) GitHub par upload
- GitHub app ya browser mein sign in karke **New repository** banayein, naam `bluey-buddy-android` rakh sakte hain.
- Folder ke andar ki files repository ke root mein upload karein. ZIP ko bas upload karna kaafi nahi hai; usko extract karke files upload karni hain.
- Repository ke **Actions** tab mein jaayein. Agar prompt aaye to workflows enable karein.
- **Build Bluey Buddy APK** workflow kholkar **Run workflow** dabayein. Ya files push karne par workflow apne aap chal sakta hai.

## 3) APK download
- Workflow run kholein aur green tick ka intezar karein.
- Neeche **Artifacts** mein `BlueyBuddy-debug-apk` download karein.
- Artifact ZIP extract karein; andar `app-debug.apk` milega.
- APK install karein. Android ke prompt par browser/File Manager ko install permission deni pad sakti hai.

## 4) App chalana
- App kholein → **Enable floating mascot**.
- Settings khule to **Display over other apps / Appear on top** allow karein, phir app mein lautkar button dobara dabayein.
- Mascot ko finger se drag kar sakte hain. Tap se expression badlega; double-tap ya long-press chat kholega.
- Gemini chat optional hai. API key sirf apne phone par app mein daalein; mujhe ya kisi public repository mein mat bhejein. API usage par limits/charges lag sakte hain.

## Agar build fail ho
Actions run mein red ❌ kholein, sabse pehla error dekhein aur uska screenshot/share karein. Build green hone se bhi overlay ko aapke phone par manually test karna zaroori hai.

## Abhi kya shamil nahi hai
Voice chat, screen dekhna, doosre apps par automatic tap/click, original Bluey character/artwork, aur production-secure API key storage is prototype mein nahi hain. Inhe kaam karta hua kehna sahi nahi hoga.
