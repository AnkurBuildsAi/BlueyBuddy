# Bluey Buddy — local-first Android prototype

This is an original Android implementation targeting Android 8.1 (API 27) and newer. It is not a copy of Google's proprietary Voice Access source or models.

## Included in this source

- Floating vector-drawn puppy overlay with blinking eyes, gaze-follow, idle motion, tail/limb animation, drag-to-move and edge docking (a paw/side remains visible).
- Double-tap the floating puppy to enter full-screen Virtual Pet Mode.
- Virtual Pet Mode with head/nose/belly/paw touch reactions, touch-and-hold speech input, simple playful squash/bounce/dizzy animations, and spoken responses.
- No Gemini/OpenAI/third-party AI API key, cloud LLM endpoint, or app-level Internet permission is used by this build.
- Local command routing for date/time, basic arithmetic, timer/alarm intents, opening installed apps, launching browser/Google searches, YouTube/WhatsApp, Settings, Camera, Home/Back/Recents/notifications/Quick Settings (where supported), type into focused accessible text fields, click accessible labels, scroll/swipe, volume, and clipboard.
- Simple multi-step chaining when steps are separated by commas, “then”, “phir”, or “uske baad”.
- User-enabled AccessibilityService for reading exposed text and clicking accessible controls.
- GitHub Actions workflow to build a debug APK.

## Important, honest limitations

- **No separate AI API key is needed, but this does not embed an offline large language model.** Unknown/general questions open a Google search in the browser instead of pretending that an AI answered them.
- Voice transcription uses Android's installed `SpeechRecognizer` service with `EXTRA_PREFER_OFFLINE` as a preference. On Android 8.1 this is best-effort; the installed speech provider and language pack decide whether recognition works offline or needs internet. The newer guaranteed on-device SpeechRecognizer API is only available from Android 12 / API 31, not Android 8.1.
- **The always-listening “Hello Bluey” wake-word detector is not included.** A real wake-word feature needs a bundled wake-word model/engine and careful background-microphone/battery handling. The included reliable interaction is press-and-hold to talk.
- This is a usable prototype, not a 1:1 replacement for Voice Access. Android apps can hide text, draw custom UI, block accessibility clicks, or require authentication. The first-result click is only a best-effort accessibility action. Every multi-step task should be checked on the phone.
- Visual screenshot understanding by a multimodal model is not included because this build intentionally uses no online AI API and no bundled OCR/vision model. “What is on screen?” can read text exposed through Android Accessibility only.
- Sending messages, placing orders, purchases, deleting data, or payments are not performed silently; review sensitive steps yourself.
- Character art is original Canvas vector art and intentionally lightweight rather than a high-detail 3D rig. It is animated and touch-reactive, but deep per-body-part physics and a high-end 3D model would need a separate art/animation asset pipeline.

## Build with GitHub Actions

1. Extract this ZIP so `settings.gradle`, `build.gradle`, `app/`, and `.github/` are at the repository root. Alternatively, commit this ZIP as `BlueyBuddy-Android-Source.zip` in the repository root.
2. Ensure `.github/workflows/android-apk.yml` is committed in the repository. The workflow is also supplied separately as `android-apk.yml`.
3. On GitHub, open **Actions → Build Bluey Buddy APK → Run workflow** (or push to `main` / `master`).
4. When the run succeeds, open the completed run and download the artifact named **BlueyBuddy-Android-8.1-debug-APK**.
5. Extract the artifact ZIP and install `app-debug.apk` on the phone. Allow “Install unknown apps” for the app you use to open it.

The debug APK is unsigned for Play Store release but is installable for testing.

## First-run setup

1. Open Bluey Buddy and allow microphone permission.
2. Tap **Overlay permission** and allow display-over-other-apps.
3. Return to Bluey Buddy and tap **Start floating Bluey**.
4. For phone actions, tap **Enable screen reading** and enable Bluey Buddy in Android Accessibility settings.
5. Tap the floating puppy once for a reaction, hold it to speak, drag it to reposition, or double-tap it for Virtual Pet Mode.
6. Test first with “time batao”, “aaj ki date”, “YouTube kholo”, “WhatsApp kholo”, “scroll down”, “back jao”, and “type hello” after focusing a text field.

## Build facts

- Application ID: `com.blueybuddy.agent` (debug build adds `.debug`)
- Minimum SDK: 26 (Android 8.0+; tested target includes Android 8.1 API 27)
- Target SDK: 28 to retain compatibility with the older target phone and legacy overlay/foreground-service behaviours.
- Compile SDK: 35
- Java: 17 in CI; project source and bytecode target Java/Kotlin 8.
