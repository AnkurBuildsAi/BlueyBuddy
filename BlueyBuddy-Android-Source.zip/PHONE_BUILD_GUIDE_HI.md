# Bluey Buddy APK banane ka guide (Hindi/Hinglish)

## ZIP kaise use karna hai

1. `BlueyBuddy-Android-Source.zip` ko download karke extract karo.
2. Extracted files ka root folder GitHub repository ke root mein upload karo. Root mein `settings.gradle`, `build.gradle`, `app/` aur `.github/workflows/android-apk.yml` hona chahiye.
3. Agar existing repository mein source ZIP rakhna hai, to ZIP ka naam `BlueyBuddy-Android-Source.zip` rakhkar root mein upload karo. Workflow direct source ya supported ZIP dono build kar sakta hai.
4. Workflow file `.github/workflows/android-apk.yml` ke andar hi honi chahiye. Sirf root par `android-apk.yml` rakhne se GitHub Actions use nahi karega.

## GitHub se APK nikaalna

1. GitHub repository kholo.
2. `Actions` tab kholo.
3. `Build Bluey Buddy APK` workflow choose karo.
4. `Run workflow` dabao.
5. Run successful hone par run page ke neeche `Artifacts` mein `BlueyBuddy-Android-8.1-debug-APK` download karo.
6. Downloaded artifact ZIP extract karke `app-debug.apk` install karo.

## Phone par first setup

1. App open karke microphone permission allow karo.
2. `Overlay permission` dabao aur “Display over other apps” allow karo.
3. Wapas app mein aakar `Start floating Bluey` dabao.
4. Phone ko voice se control karne ke liye `Enable screen reading` dabao aur Accessibility settings mein Bluey Buddy ON karo.
5. Floating puppy ko tap karke reaction dekho, hold karke command bolo, drag karke move karo, double-tap karke Virtual Pet Mode kholo.

## Is build mein kya hai

- API key ke bina built-in commands: date/time, calculations, app launch, Settings, Back/Home, notifications, Quick Settings, volume, timer/alarm screen, clipboard, accessible text field mein typing/paste, buttons click/long-press, coordinate tap, scroll/swipe.
- Unknown questions ke liye Google search browser mein khulti hai. AI API key ki zaroorat nahi, magar internet search ke liye internet chahiye.
- Speech-to-text Android ke installed speech service se hota hai. Offline preference bheji jaati hai, lekin Android 8.1 par Hindi recognition offline chalegi ya nahi, yeh device ke speech engine/language pack par depend karta hai.
- “Hello Bluey” always-listening wake word abhi included nahi hai. Iske liye local wake-word model aur background listening ka alag, device-tested component chahiye. Abhi hold-to-talk use karo.
- Ye Google Voice Access ka clone ya exact replacement nahi hai. Accessibility ki wajah se bahut se controls operate ho sakte hain; protected/custom screens aur har app par 100% control guaranteed nahi hai.
- Screenshot/visual image ko AI se samajhne wala feature included nahi, kyunki is build mein online AI API ya offline vision/OCR model nahi hai. Screen reading wahi text padh sakti hai jo Android Accessibility expose karti hai.

## APK build na ho to

GitHub Actions mein failed run kholkar `Build debug APK` ke logs dekho. APK sirf successful workflow run ke baad `Artifacts` se milega. Is environment mein Android SDK maujood nahi tha, isliye source ko yahan se compile karke installable APK verify karna possible nahi hua.
