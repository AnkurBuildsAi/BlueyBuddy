package com.blueybuddy.agent

import android.app.AlarmManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Handler
import android.os.Looper
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

/** Local-first command result. No private AI API key or cloud LLM is required. */
data class AgentOutcome(
    val status: String,
    val answer: String,
    val mood: String = "happy",
    val shouldSpeak: Boolean = true
)

/**
 * Bluey's local command/agent layer.
 * Voice transcription is supplied by Android's installed SpeechRecognizer service.
 * Device actions use public Android intents and the user-enabled AccessibilityService.
 */
object AgentEngine {
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var lastUrl: String = ""
    @Volatile private var lastSearchProvider: String = "google"
    @Volatile private var pendingClickLabel: String? = null
    @Volatile var preferVirtualPetOutput: Boolean = false

    fun execute(context: Context, spokenOrTyped: String, callback: (AgentOutcome) -> Unit) {
        val app = context.applicationContext
        val raw = spokenOrTyped.trim()
        main.post { MascotOverlayService.instance?.setThinking() }
        if (raw.isBlank()) {
            deliver(callback, AgentOutcome("कुछ सुनाई नहीं दिया", "Bluey को दबाकर रखो, बोलो और उंगली हटा दो।", "curious"))
            return
        }
        val steps = splitSteps(raw)
        if (steps.size > 1) {
            main.post { runSequence(app, steps, 0, ArrayList(), callback) }
            return
        }
        worker.execute { executeOne(app, raw, callback) }
    }

    private fun runSequence(context: Context, steps: List<String>, index: Int, outcomes: MutableList<String>, finalCallback: (AgentOutcome) -> Unit) {
        if (index >= steps.size) {
            deliver(finalCallback, AgentOutcome("Agent task complete", "Kaam ke steps chala diye: ${outcomes.joinToString("; ").take(700)}", "happy"))
            return
        }
        execute(context, steps[index]) { outcome ->
            outcomes.add(outcome.status)
            if (outcome.mood == "confused" || outcome.mood == "careful") {
                deliver(finalCallback, AgentOutcome("Agent ko madad chahiye", "Step ${index + 1}/${steps.size}: ${outcome.answer}", outcome.mood))
            } else {
                main.postDelayed({ runSequence(context, steps, index + 1, outcomes, finalCallback) }, 1100L)
            }
        }
    }

    private fun splitSteps(raw: String): List<String> {
        // Explicit separators only; do not split on the everyday Hindi word "aur".
        val parts = raw.split(Regex("(?i),\\s*|\\s+(?:and then|then|phir|uske baad)\\s+"))
            .map { it.trim().trim('.', '।', ';') }.filter { it.isNotBlank() }
        return if (parts.size in 2..5 && parts.all { it.length >= 2 }) parts else listOf(raw)
    }

    private fun executeOne(context: Context, raw: String, callback: (AgentOutcome) -> Unit) {
        val s = raw.lowercase(Locale.ROOT).replace(Regex("\\s+"), " ").trim()

        if ((isConfirm(s)) && pendingClickLabel != null) {
            val target = pendingClickLabel!!
            pendingClickLabel = null
            BlueyAccessibilityService.clickLabel(target) { ok ->
                deliver(callback, if (ok) AgentOutcome("काम हो गया", "स्क्रीन पर ‘$target’ चुना।", "happy")
                else AgentOutcome("बटन नहीं मिला", "स्क्रीन पर ‘$target’ क्लिक नहीं हो पाया।", "confused"))
            }
            return
        }
        if (isCancel(s) && pendingClickLabel != null) {
            pendingClickLabel = null
            deliver(callback, AgentOutcome("रद्द कर दिया", "ठीक है, मैंने वह कार्रवाई नहीं की।", "relieved"))
            return
        }

        // Local answers first: no network and no API key.
        if (isTimeQuestion(s)) {
            val time = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            deliver(callback, AgentOutcome("Abhi ka samay", "Abhi $time baj rahe hain.", "happy")); return
        }
        if (isDateQuestion(s)) {
            val date = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("hi", "IN")).format(Date())
            deliver(callback, AgentOutcome("Aaj ki tareekh", "Aaj $date hai.", "happy")); return
        }
        if (isTimerCommand(s)) {
            val match = Regex("(\\d{1,3})\\s*(seconds?|secs?|सेकंड|सेकेंड|minutes?|mins?|मिनट|hours?|घंटे?|घंटा)").find(s)
            if (match != null) {
                val amount = match.groupValues[1].toIntOrNull() ?: 1
                val unit = match.groupValues[2]
                val seconds = when {
                    unit.startsWith("h") || unit.startsWith("घंट") -> amount * 3600
                    unit.startsWith("s") || unit.startsWith("सेक") -> amount
                    else -> amount * 60
                }
                val intent = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, seconds.coerceIn(1, 86400))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Bluey Buddy timer")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                deliver(callback, if (openIntent(context, intent)) AgentOutcome("Timer khol diya", "$amount ${unit} ka timer set karne ke liye Clock khol di.", "happy")
                else AgentOutcome("Timer nahi khula", "Is phone par timer app available nahi mili.", "confused")); return
            }
        }
        if (isAlarmCommand(s)) {
            val m = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?", RegexOption.IGNORE_CASE).find(s)
            if (m != null) {
                var hour = (m.groupValues[1].toIntOrNull() ?: 7).coerceIn(0, 23)
                val minute = (m.groupValues[2].toIntOrNull() ?: 0).coerceIn(0, 59)
                when (m.groupValues[3].lowercase(Locale.ROOT)) {
                    "pm" -> if (hour in 1..11) hour += 12
                    "am" -> if (hour == 12) hour = 0
                }
                val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hour)
                    .putExtra(AlarmClock.EXTRA_MINUTES, minute).putExtra(AlarmClock.EXTRA_MESSAGE, "Bluey Buddy")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                deliver(callback, if (openIntent(context, i)) AgentOutcome("Alarm khol diya", "Clock mein ${String.format(Locale.ROOT, "%02d:%02d", hour, minute)} ka alarm tayyar hai; save kar do.", "happy")
                else AgentOutcome("Alarm nahi khula", "Clock app nahi mil rahi.", "confused")); return
            }
            deliver(callback, AgentOutcome("Alarm ka time batao", "Aise bolo: ‘7:30 AM ka alarm lagao’. Main Clock app khol dunga.", "curious")); return
        }
        if (isMathQuestion(s)) {
            val expr = Regex("(-?\\d+(?:[.,]\\d+)?)\\s*([+\\-x×*/÷])\\s*(-?\\d+(?:[.,]\\d+)?)").find(raw)
            if (expr != null) {
                val a = expr.groupValues[1].replace(',', '.').toDoubleOrNull()
                val b = expr.groupValues[3].replace(',', '.').toDoubleOrNull()
                if (a != null && b != null) {
                    val result: Double? = when (expr.groupValues[2]) {
                        "+" -> a + b; "-" -> a - b; "x", "×", "*" -> a * b; "/", "÷" -> if (b != 0.0) a / b else null; else -> null
                    }
                    if (result != null) {
                        val nice = if (result.isFinite() && result % 1.0 == 0.0) result.roundToInt().toString() else result.toString()
                        deliver(callback, AgentOutcome("Hisab ho gaya", "$nice jawab hai.", "happy")); return
                    }
                    deliver(callback, AgentOutcome("Hisab nahi ho saka", "Zero se divide nahi kar sakte.", "confused")); return
                }
            }
            if (s.contains("calculator") || s.contains("कैलकुलेटर")) {
                if (openAppByQuery(context, "calculator")) deliver(callback, AgentOutcome("Calculator khol diya", "Ab calculation kar sakte ho.", "happy"))
                else deliver(callback, AgentOutcome("Calculator nahi mila", "Is phone par calculator app nahi mili.", "confused"))
                return
            }
        }

        if (s in listOf("hi", "hello", "hey bluey", "hello bluey", "नमस्ते", "हेलो", "हाय", "bluey")) {
            deliver(callback, AgentOutcome("Hello!", "Hello! Main sun raha hoon. Bolo kaunsa kaam karna hai?", "happy")); return
        }
        if (listOf("who are you", "tum kaun", "apna naam", "तुम कौन", "तुम्हारा नाम").any { s.contains(it) }) {
            deliver(callback, AgentOutcome("Main Bluey Buddy hoon", "Main tumhara voice assistant aur virtual puppy hoon. Main available Android controls se phone par kaam kar sakta hoon.", "happy")); return
        }

        // Explicit searches.
        if (isYoutubeDownload(s)) {
            val url = "https://www.google.com/search?q=" + enc("YouTube official help download videos to watch offline")
            val ok = openUrl(context, url)
            deliver(callback, AgentOutcome(if (ok) "Official options khole" else "Browser nahi khula", "YouTube ke official download options search kiye. Main protected videos ko bypass karke download nahi karunga.", if (ok) "careful" else "confused")); return
        }
        if (isYoutubeSearch(s) || (lastSearchProvider == "youtube" && isGenericSearch(s))) {
            val query = extractSearchQuery(raw, true).ifBlank { "trending songs" }
            lastSearchProvider = "youtube"
            val url = "https://www.youtube.com/results?search_query=" + enc(query)
            val ok = openUrl(context, url)
            deliver(callback, AgentOutcome(if (ok) "YouTube results khole" else "YouTube nahi khula", if (ok) "YouTube par ‘$query’ ke results khol diye. Agar app results ko expose kare to ‘pehla result click karo’ bol sakte ho." else "Browser ya YouTube app nahi mili.", if (ok) "busy" else "confused")); return
        }
        if (isGoogleSearch(s) || isGenericSearch(s) || s.contains("weather") || s.contains("mausam") || s.contains("मौसम")) {
            val query = if (isGenericSearch(s)) extractSearchQuery(raw, false).ifBlank { raw } else extractSearchQuery(raw, false).ifBlank { raw }
            lastSearchProvider = "google"
            val ok = openUrl(context, "https://www.google.com/search?q=" + enc(query))
            deliver(callback, AgentOutcome(if (ok) "Google search khol di" else "Browser nahi mila", if (ok) "Google par ‘$query’ ke results khol diye. Is build mein AI API key nahi hai; jawab ke liye web results dekho." else "Is phone par browser available nahi mila.", if (ok) "busy" else "confused")); return
        }

        if (isBackCommand(s)) {
            BlueyAccessibilityService.navigateBack { ok -> deliver(callback, if (ok) AgentOutcome("Back", "Pichhli screen par gaya.", "busy") else AgentOutcome("Accessibility chahiye", "Phone control ke liye Bluey ki Accessibility Service enable karo.", "confused")) }; return
        }
        if (isHomeCommand(s)) {
            BlueyAccessibilityService.navigateHome { ok -> deliver(callback, if (ok) AgentOutcome("Home", "Home screen khol di.", "busy") else AgentOutcome("Accessibility chahiye", "Phone control ke liye Bluey ki Accessibility Service enable karo.", "confused")) }; return
        }
        if (s.contains("recent apps") || s.contains("recents kholo") || s.contains("हाल के ऐप")) {
            val ok = BlueyAccessibilityService.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS)
            deliver(callback, if (ok) AgentOutcome("Recent apps", "Recent apps khol diye.", "busy") else AgentOutcome("Accessibility chahiye", "Accessibility Service enable karo.", "confused")); return
        }
        if (s.contains("notification") || s.contains("नोटिफिकेशन")) {
            val ok = BlueyAccessibilityService.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            deliver(callback, if (ok) AgentOutcome("Notifications", "Notification shade kholne ki koshish ki.", "busy") else AgentOutcome("Accessibility chahiye", "Accessibility Service enable karo.", "confused")); return
        }
        if (s.contains("quick settings") || s.contains("quick panel") || s.contains("quick setting")) {
            val ok = BlueyAccessibilityService.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            deliver(callback, if (ok) AgentOutcome("Quick Settings", "Quick Settings khol di.", "busy") else AgentOutcome("Accessibility chahiye", "Accessibility Service enable karo.", "confused")); return
        }

        if (isCopyLink(s)) {
            val url = findUrl(raw) ?: findUrl(BlueyAccessibilityService.latestText) ?: lastUrl
            if (url.isBlank()) deliver(callback, AgentOutcome("Link nahi mila", "Pehle website ya search kholo, phir ‘link copy karo’ bolo.", "confused"))
            else copyToClipboard(context, url, callback, "Link clipboard mein copy ho gaya.")
            return
        }
        if (s.startsWith("copy ") || s.startsWith("कॉपी ")) {
            val value = raw.replace(Regex("(?i)^(copy|कॉपी)\\s+"), "").trim()
            if (value.isNotBlank()) copyToClipboard(context, value, callback, "Text clipboard mein copy ho gaya.")
            else deliver(callback, AgentOutcome("Kya copy karun?", "Bolo: ‘copy hello world’. ", "curious"))
            return
        }

        if (isOpenSettings(s)) {
            val intent = when {
                s.contains("wifi") || s.contains("wi-fi") || s.contains("वाईफाई") -> Intent(Settings.ACTION_WIFI_SETTINGS)
                s.contains("bluetooth") -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                s.contains("display") || s.contains("screen") -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
                s.contains("sound") || s.contains("volume") -> Intent(Settings.ACTION_SOUND_SETTINGS)
                else -> Intent(Settings.ACTION_SETTINGS)
            }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val ok = openIntent(context, intent)
            deliver(callback, if (ok) AgentOutcome("Settings khol di", "Android Settings khol di. Kuch system options device par alag ho sakte hain.", "busy") else AgentOutcome("Settings nahi khuli", "System Settings nahi khol paya.", "confused")); return
        }
        if (s.contains("volume") || s.contains("awaaz tez") || s.contains("आवाज़ तेज") || s.contains("volume badha") || s.contains("volume kam")) {
            val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val direction = if (s.contains("down") || s.contains("kam") || s.contains("कम") || s.contains("lower")) AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
            deliver(callback, AgentOutcome("Volume badla", if (direction == AudioManager.ADJUST_RAISE) "Media volume badhaya." else "Media volume kam kiya.", "happy")); return
        }

        if (isScreenQuestion(s)) {
            val screenText = BlueyAccessibilityService.latestText.trim()
            if (screenText.isBlank()) deliver(callback, AgentOutcome("Screen text available nahi", "Screen text ke liye Settings mein Bluey ki Accessibility Service enable karo. Protected ya custom-drawn screens ka text padhna mumkin nahi ho sakta.", "confused"))
            else deliver(callback, AgentOutcome("Screen par accessible text", screenText.take(700), "curious"))
            return
        }
        val coordinateTap = Regex("(?i)^(?:tap|click)\\s+(?:at|on coordinates?)\\s*(\\d{1,4})[ ,]+(\\d{1,4})$").find(raw)
        if (coordinateTap != null) {
            val x = coordinateTap.groupValues[1].toIntOrNull() ?: 0
            val y = coordinateTap.groupValues[2].toIntOrNull() ?: 0
            BlueyAccessibilityService.tapCoordinates(x, y) { ok -> deliver(callback, if (ok) AgentOutcome("Tap kiya", "Screen coordinate par tap gesture bheja.", "busy") else AgentOutcome("Tap nahi hua", "Pehle Accessibility Service enable karo.", "confused")) }
            return
        }
        if (s.startsWith("long press ") || s.startsWith("long click ") || s.startsWith("long press on ") || s.startsWith("लंबा दबाओ ")) {
            val target = raw.replace(Regex("(?i)^(long press|long click|long press on|लंबा दबाओ)\\s+(?:on\\s+)?"), "").trim()
            if (target.isBlank()) deliver(callback, AgentOutcome("Kya hold karun?", "Button ka label bolo, jaise ‘long press image’.", "curious"))
            else BlueyAccessibilityService.longClickLabel(target) { ok -> deliver(callback, if (ok) AgentOutcome("Long press kiya", "‘$target’ par long-press kiya.", "busy") else AgentOutcome("Long press nahi hua", "‘$target’ ka accessible long-press control nahi mila.", "confused")) }
            return
        }
        if (s == "paste" || s == "paste clipboard" || s == "clipboard paste" || s == "पेस्ट" || s == "पेस्ट करो") {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val value = try { cm.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty() } catch (_: Exception) { "" }
            if (value.isBlank()) deliver(callback, AgentOutcome("Clipboard khaali hai", "Pehle text copy karo.", "confused"))
            else BlueyAccessibilityService.setFocusedText(value) { ok -> deliver(callback, if (ok) AgentOutcome("Paste ho gaya", "Clipboard ka text focused field mein bhar diya.", "happy") else AgentOutcome("Paste nahi hua", "Pehle text field par tap karo.", "confused")) }
            return
        }

        if (isClickCommand(s)) {
            val target = raw.replace(Regex("(?i)^(click|tap|press|क्लिक|दबाओ|टैप)\\s+(?:on\\s+)?"), "").trim()
            if (target.isBlank()) deliver(callback, AgentOutcome("Kaunsa button?", "Bolo: ‘Search button click karo’. ", "curious"))
            else if (isSensitiveTarget(target)) {
                pendingClickLabel = target
                deliver(callback, AgentOutcome("Confirmation chahiye", "Main ‘$target’ click karne wala hoon. Karna ho to ‘confirm’, warna ‘cancel’ bolo.", "careful"))
            } else BlueyAccessibilityService.clickLabel(target) { ok ->
                deliver(callback, if (ok) AgentOutcome("Click ho gaya", "Screen par ‘$target’ click kiya.", "happy") else AgentOutcome("Clickable control nahi mila", "‘$target’ nahi mila. Accessibility enable karo aur sahi app saamne lao.", "confused"))
            }
            return
        }
        if (s.contains("scroll down") || s.contains("neeche scroll") || s.contains("neeche skrol") || s.contains("नीचे स्क्रोल") || s.contains("नीचे scroll")) {
            val ok = BlueyAccessibilityService.performScroll(true)
            deliver(callback, if (ok) AgentOutcome("Scroll down", "Screen ko neeche scroll kiya.", "busy") else AgentOutcome("Accessibility chahiye", "Screen gestures ke liye Accessibility Service enable karo.", "confused")); return
        }
        if (s.contains("scroll up") || s.contains("upar scroll") || s.contains("ऊपर स्क्रोल") || s.contains("ऊपर scroll")) {
            val ok = BlueyAccessibilityService.performScroll(false)
            deliver(callback, if (ok) AgentOutcome("Scroll up", "Screen ko upar scroll kiya.", "busy") else AgentOutcome("Accessibility chahiye", "Screen gestures ke liye Accessibility Service enable karo.", "confused")); return
        }
        if (s.contains("swipe left") || s.contains("left swipe") || s.contains("बाएं स्वाइप") || s.contains("बायें स्वाइप")) {
            val ok = BlueyAccessibilityService.performSwipe("left")
            deliver(callback, if (ok) AgentOutcome("Swipe left", "Left swipe kiya.", "busy") else AgentOutcome("Swipe nahi hua", "Accessibility Service enable karo.", "confused")); return
        }
        if (s.contains("swipe right") || s.contains("right swipe") || s.contains("दाएं स्वाइप") || s.contains("दायें स्वाइप")) {
            val ok = BlueyAccessibilityService.performSwipe("right")
            deliver(callback, if (ok) AgentOutcome("Swipe right", "Right swipe kiya.", "busy") else AgentOutcome("Swipe nahi hua", "Accessibility Service enable karo.", "confused")); return
        }
        if (s.startsWith("type ") || s.startsWith("likho ") || s.startsWith("लिखो ") || s.startsWith("टाइप करो ")) {
            val value = raw.replace(Regex("(?i)^(type|likho|लिखो|टाइप करो)\\s+"), "").trim()
            BlueyAccessibilityService.setFocusedText(value) { ok -> deliver(callback, if (ok) AgentOutcome("Text bhar diya", "Focused text field mein likh diya. Send ya submit karne se pehle check kar lena.", "busy") else AgentOutcome("Text field nahi mila", "Pehle text box par tap karo, phir ‘type ...’ bolo.", "confused")) }
            return
        }

        if (isOpenYoutube(s)) {
            val ok = openAppOrWeb(context, "com.google.android.youtube", "https://www.youtube.com")
            lastSearchProvider = "youtube"
            deliver(callback, if (ok) AgentOutcome("YouTube khol diya", "YouTube khol diya. Search ke liye bolo: ‘YouTube par cricket search karo’. ", "happy") else AgentOutcome("YouTube nahi khula", "YouTube app ya browser nahi mila.", "confused")); return
        }
        if (isOpenWhatsApp(s)) {
            val ok = openAppOrWeb(context, "com.whatsapp", "https://wa.me/")
            deliver(callback, if (ok) AgentOutcome("WhatsApp khol diya", "WhatsApp open kiya. Message bhejne se pehle recipient aur text khud verify karna.", "happy") else AgentOutcome("WhatsApp nahi khula", "WhatsApp ya browser nahi mila.", "confused")); return
        }
        if (isOpenCamera(s)) {
            val ok = openIntent(context, Intent("android.media.action.IMAGE_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            deliver(callback, if (ok) AgentOutcome("Camera khol diya", "Camera app start karne ki request bheji.", "happy") else AgentOutcome("Camera nahi khula", "Camera app available nahi hai.", "confused")); return
        }
        if ((s.startsWith("open http") || s.startsWith("open www.") || s.startsWith("website kholo") || s.startsWith("website khol do") || s.startsWith("website खोलो")) && findUrl(raw) != null) {
            val url = findUrl(raw)!!
            val ok = openUrl(context, if (url.startsWith("www.")) "https://$url" else url)
            deliver(callback, if (ok) AgentOutcome("Website khol di", "$url open kar diya.", "busy") else AgentOutcome("Website nahi khuli", "Browser available nahi mila.", "confused")); return
        }
        if (isOpenBrowser(s)) {
            val ok = openUrl(context, "https://www.google.com")
            deliver(callback, if (ok) AgentOutcome("Browser khol diya", "Google khol diya. Internet search ke liye taiyar hai.", "happy") else AgentOutcome("Browser nahi mila", "Browser app available nahi mili.", "confused")); return
        }
        if (isDialCommand(s)) {
            val number = Regex("[+]?[- 0-9]{6,}").find(raw)?.value?.trim()
            val intent = Intent(Intent.ACTION_DIAL).apply {
                if (!number.isNullOrBlank()) data = Uri.parse("tel:" + number.replace(Regex("[^+0-9]"), ""))
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val ok = openIntent(context, intent)
            deliver(callback, if (ok) AgentOutcome("Dialer khol diya", if (number == null) "Phone dialer khol diya." else "$number ka number dialer mein set kiya; call karne se pehle khud check karo.", "careful") else AgentOutcome("Dialer nahi khula", "Phone app available nahi mili.", "confused")); return
        }

        // Generic app launch: match the installed app label/package name without an AI service.
        if (isOpenAppCommand(s)) {
            val query = extractAppName(raw)
            val ok = openAppByQuery(context, query)
            if (ok) {
                deliver(callback, AgentOutcome("App khol di", "$query app kholne ki request successful hui.", "happy")); return
            }
        }

        // A multi-step action such as "open YouTube, search cricket" can be chained. A request
        // to play the first result is attempted only if the app exposes a matching clickable label.
        if (s.contains("first video") || s.contains("first result") || s.contains("pehla video") || s.contains("पहला वीडियो") || s.contains("pehla result")) {
            BlueyAccessibilityService.clickFirstContentElement { ok ->
                deliver(callback, if (ok) AgentOutcome("Pehla result click kiya", "Visible content mein pehla suitable clickable result select kiya.", "busy") else AgentOutcome("Pehla result nahi mila", "Current screen par accessible result nahi mila. Screen manually check karo.", "confused"))
            }
            return
        }

        // No cloud AI fallback: hand unknown knowledge questions to the user's browser/search engine.
        val searchUrl = "https://www.google.com/search?q=" + enc(raw)
        val opened = openUrl(context, searchUrl)
        deliver(callback, if (opened) AgentOutcome("Web search khol di", "Is build mein AI API key nahi lagti. Is sawaal ke liye Google results khole hain: ‘$raw’. Web results padhne ke liye internet chahiye.", "curious")
        else AgentOutcome("Command samajh nahi aayi", "Mujhe local command samajh nahi aayi aur browser bhi nahi khula. App ka naam, ‘time batao’, ‘date batao’, ‘back’, ‘scroll down’ ya ‘type ...’ try karo.", "confused"))
    }

    private fun copyToClipboard(context: Context, value: String, callback: (AgentOutcome) -> Unit, message: String) {
        try {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Bluey Buddy", value))
            deliver(callback, AgentOutcome("Copied", message, "happy"))
        } catch (_: Exception) {
            deliver(callback, AgentOutcome("Copy nahi hua", "Clipboard available nahi hai.", "confused"))
        }
    }

    private fun deliver(callback: (AgentOutcome) -> Unit, outcome: AgentOutcome) {
        main.post {
            if (!preferVirtualPetOutput) MascotOverlayService.instance?.showAgentOutcome(outcome)
            callback(outcome)
        }
    }

    private fun openUrl(context: Context, url: String): Boolean {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return openIntent(context, intent).also { if (it) lastUrl = url }
    }

    private fun openAppOrWeb(context: Context, packageName: String, fallback: String): Boolean {
        return try {
            val launch = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) { launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(launch); true }
            else openUrl(context, fallback)
        } catch (_: Exception) { openUrl(context, fallback) }
    }

    private fun openAppByQuery(context: Context, query: String): Boolean {
        val q = normalize(query)
        if (q.isBlank()) return false
        return try {
            val pm = context.packageManager
            val apps = pm.getInstalledApplications(0)
                .filter { it.packageName != context.packageName }
                .map { app -> Triple(app, pm.getApplicationLabel(app).toString(), normalize(app.packageName.replace('.', ' '))) }
            val match = apps.firstOrNull { normalize(it.second) == q }
                ?: apps.firstOrNull { normalize(it.second).contains(q) }
                ?: apps.firstOrNull { q.contains(normalize(it.second)) && normalize(it.second).length >= 4 }
                ?: apps.firstOrNull { it.third.contains(q) && q.length >= 4 }
                ?: return false
            val launch = pm.getLaunchIntentForPackage(match.first.packageName) ?: return false
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launch)
            true
        } catch (_: Exception) { false }
    }

    private fun openIntent(context: Context, intent: Intent): Boolean = try { context.startActivity(intent); true } catch (_: Exception) { false }
    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")
    private fun normalize(value: String) = value.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]"), "").trim()
    private fun findUrl(raw: String): String? = Regex("(?:https?://|www\\.)[^\\s]+", RegexOption.IGNORE_CASE).find(raw)?.value?.trimEnd('.', ',', '!', '?')

    private fun isTimeQuestion(s: String) = listOf("time bata", "what time", "current time", "abhi kitne baje", "kitne baje", "समय बताओ", "टाइम बताओ", "अभी कितने बजे", "समय क्या").any { s.contains(it) } && !isTimerCommand(s) && !isAlarmCommand(s)
    private fun isDateQuestion(s: String) = listOf("date bata", "aaj ki date", "today's date", "today date", "what date", "aaj ka din", "आज की तारीख", "तारीख बताओ", "आज कौन सा दिन", "आज की डेट").any { s.contains(it) }
    private fun isTimerCommand(s: String) = listOf("timer", "countdown", "ka timer", "का टाइमर", "टाइमर लगाओ", "timer lagao").any { s.contains(it) }
    private fun isAlarmCommand(s: String) = listOf("alarm", "अलार्म").any { s.contains(it) }
    private fun isMathQuestion(s: String) = Regex("-?\\d+(?:[.,]\\d+)?\\s*[+\\-x×*/÷]\\s*-?\\d+(?:[.,]\\d+)?").containsMatchIn(s) || s.contains("calculate") || s.contains("calculator") || s.contains("गणना") || s.contains("जोड़")
    private fun isYoutubeDownload(s: String) = (s.contains("youtube") || s.contains("यूट्यूब")) && listOf("download", "डाउनलोड").any { s.contains(it) }
    private fun isYoutubeSearch(s: String) = (s.contains("youtube") || s.contains("यूट्यूब") || s.contains("गाना") || s.contains("gana") || s.contains("song") || s.contains("songs")) && isGenericSearch(s)
    private fun isGoogleSearch(s: String) = (s.contains("google") || s.contains("गूगल")) && isGenericSearch(s)
    private fun isGenericSearch(s: String) = listOf("search", "search karo", "find", "google it", "खोज", "ढूंढ", "ढूँढ", "सर्च", "सर्च करो", "search kar").any { s.contains(it) }
    private fun isCopyLink(s: String) = (s.contains("copy") || s.contains("कॉपी")) && (s.contains("link") || s.contains("लिंक"))
    private fun isBackCommand(s: String) = listOf("go back", "back jao", "back karo", "back कर", "पीछे जाओ", "वापस जाओ", "back button", "back ja", "back दबाओ").any { s.contains(it) }
    private fun isHomeCommand(s: String) = listOf("go home", "home jao", "home screen", "होम स्क्रीन", "होम पर जाओ", "home par jao").any { s.contains(it) }
    private fun isOpenYoutube(s: String) = (s.contains("youtube") || s.contains("यूट्यूब")) && listOf("open", "kholo", "खोलो", "खोल", "chalao", "चलाओ", "start").any { s.contains(it) } && !isYoutubeSearch(s)
    private fun isOpenWhatsApp(s: String) = s.contains("whatsapp") && listOf("open", "kholo", "खोलो", "खोल", "start").any { s.contains(it) }
    private fun isOpenSettings(s: String) = (s.contains("settings") || s.contains("setting") || s.contains("सेटिंग")) && listOf("open", "kholo", "खोलो", "खोल", "karo", "करो").any { s.contains(it) }
    private fun isOpenCamera(s: String) = (s.contains("camera") || s.contains("कैमरा")) && listOf("open", "kholo", "खोलो", "खोल").any { s.contains(it) }
    private fun isOpenBrowser(s: String) = (s.contains("browser") || s.contains("chrome")) && listOf("open", "kholo", "खोलो", "खोल").any { s.contains(it) }
    private fun isScreenQuestion(s: String) = listOf("screen par kya", "screen kya", "स्क्रीन", "what am i looking", "यहाँ क्या", "ye kya dikh", "kya dikh raha", "is page par", "इस पेज", "read screen").any { s.contains(it) }
    private fun isClickCommand(s: String) = listOf("click ", "tap ", "press ", "क्लिक ", "दबाओ ", "टैप ", "click on ").any { s.startsWith(it) }
    private fun isSensitiveTarget(s: String) = listOf("send", "भेज", "delete", "डिलीट", "pay", "payment", "पेमेंट", "खरीद", "buy", "purchase", "install", "uninstall", "download", "डाउनलोड", "submit", "order", "ऑर्डर", "confirm", "post", "share").any { s.contains(it, true) }
    private fun isConfirm(s: String) = listOf("confirm", "हाँ", "haan", "yes", "कर दो", "kar do", "proceed", "पक्का").any { s == it || s.startsWith("$it ") }
    private fun isCancel(s: String) = listOf("cancel", "नहीं", "nahi", "रद्द", "stop").any { s == it || s.startsWith("$it ") }
    private fun isDialCommand(s: String) = listOf("call ", "phone karo", "dial ", "number milao", "फोन लगाओ", "कॉल करो", "डायल").any { s.contains(it) }
    private fun isOpenAppCommand(s: String) = listOf("open ", "open the ", "launch ", "start ", "kholo", "khol do", "खोलो", "खोल दो", "चालू करो", "chalao", "app kholo", "app खोलो").any { s.contains(it) }

    private fun extractSearchQuery(raw: String, youtube: Boolean): String {
        var q = raw.trim()
        q = q.replace(Regex("(?i)^(please\\s+)?(?:youtube|yt|यूट्यूब|google|गूगल)(?:\\s+(?:par|per|में|पर))?\\s*"), "")
        q = q.replace(Regex("(?i)^(?:gana|गाना|song|songs|video|वीडियो)(?:\\s+(?:ka|की))?\\s*"), "")
        q = q.replace(Regex("(?i)^(?:search|find|google it|सर्च|खोजो|खोज|ढूंढो|ढूँढो|dhundo|khojo)\\s*(?:for|karo|करो)?\\s*"), "")
        q = q.replace(Regex("(?i)\\b(?:search|find|सर्च|खोजो|खोज|ढूंढो|ढूँढो|dhundo|khojo)\\b(?:\\s+(?:for|karo|karna|karke|करो|करना|करके))?\\s*$"), "")
        q = q.replace(Regex("(?i)\\s+(?:karo|kar do|karke|करो|कर दो|करके)$"), "").trim().trim('?', '।', '.', ' ')
        return q.ifBlank { if (youtube) "trending songs" else raw }
    }

    private fun extractAppName(raw: String): String = raw
        .replace(Regex("(?i)^(please\\s+)?(?:open|launch|start)\\s+(?:the\\s+)?"), "")
        .replace(Regex("(?i)^(?:app\\s+)?(?:kholo|khol do|chalao|open karo|खोलो|खोल दो|चालू करो)\\s*"), "")
        .replace(Regex("(?i)\\s+(?:app\\s+)?(?:kholo|khol do|open karo|start karo|chalao|खोलो|खोल दो|चालू करो)$"), "")
        .trim()
}
