package com.blueybuddy.agent

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Full-screen touch-and-talk virtual pet. Character is drawn locally with Canvas (no asset downloads). */
class VirtualPetActivity : Activity() {
    private lateinit var scene: PetScene
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var listening = false
    private var holdStarted = false
    private var permissionAsked = false
    private val main = Handler(Looper.getMainLooper())

    private val holdRunnable = Runnable {
        if (!scene.dragging) {
            holdStarted = true
            startListening()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(14, 21, 48)
        window.navigationBarColor = Color.rgb(14, 21, 48)
        AgentEngine.preferVirtualPetOutput = true
        scene = PetScene()
        val root = FrameLayout(this)
        root.addView(scene, FrameLayout.LayoutParams(-1, -1))
        val close = TextView(this).apply {
            text = "✕  EXIT"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(Color.argb(110, 20, 32, 72))
            setOnClickListener { finish() }
        }
        val closeLp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
            topMargin = dp(16); rightMargin = dp(14)
        }
        root.addView(close, closeLp)
        setContentView(root)
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                val result = tts?.setLanguage(Locale("hi", "IN"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) tts?.language = Locale.US
            }
        }
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        AgentEngine.preferVirtualPetOutput = false
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) { }
        recognizer = null
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        tts = null
        super.onDestroy()
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            if (!permissionAsked) {
                permissionAsked = true
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 710)
            }
            scene.say("Microphone permission allow karo", "confused")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            scene.say("Phone ki speech service available nahi hai", "confused")
            return
        }
        try {
            try { recognizer?.destroy() } catch (_: Exception) { }
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { scene.say("Sun raha hoon… bolo", "listening") }
                override fun onBeginningOfSpeech() { scene.say("Haan, sun raha hoon", "listening") }
                override fun onRmsChanged(rmsdB: Float) { scene.audioLevel = rmsdB; scene.invalidate() }
                override fun onBufferReceived(buffer: ByteArray?) { }
                override fun onEndOfSpeech() { scene.say("Samajh raha hoon…", "thinking") }
                override fun onError(error: Int) {
                    listening = false
                    scene.audioLevel = 0f
                    scene.say("Awaaz clear nahi mili. Phir hold karke bolo.", "curious")
                }
                override fun onResults(results: Bundle?) {
                    listening = false
                    scene.audioLevel = 0f
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (spoken.isBlank()) { scene.say("Kuch sunai nahi diya. Dobara bolo.", "curious"); return }
                    scene.say("Command: ${spoken.take(60)}", "thinking")
                    AgentEngine.execute(this@VirtualPetActivity, spoken) { outcome ->
                        scene.say(outcome.answer, outcome.mood)
                        if (outcome.shouldSpeak && ttsReady && outcome.answer.isNotBlank()) {
                            try { tts?.speak(outcome.answer.take(1200), TextToSpeech.QUEUE_FLUSH, null, "bluey_virtual_${System.currentTimeMillis()}") } catch (_: Exception) { }
                        }
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (partial.isNotBlank()) scene.say("Sun raha hoon: ${partial.take(40)}", "listening")
                }
                override fun onEvent(eventType: Int, params: Bundle?) { }
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 4)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Bluey ko command bolo")
            }
            listening = true
            scene.say("Sun raha hoon… bolkar chhod do", "listening")
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            listening = false
            scene.say("Speech service start nahi hui", "confused")
        }
    }

    private fun stopListening() {
        if (!listening) return
        scene.say("Awaaz samajh raha hoon…", "thinking")
        try { recognizer?.stopListening() } catch (_: Exception) { listening = false }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 710 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            scene.say("Ab hold karke bolo", "happy")
        } else if (requestCode == 710) scene.say("Mic permission ke bina voice nahi chalegi", "confused")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private inner class PetScene : View(this@VirtualPetActivity) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private var mood = "calm"
        private var caption = "Double-tap se yahan aaye · Hold karke bolo"
        private var answer = "Sir, naak, pet, paws aur tail ko touch karke dekho."
        private var eyeX = 0f
        private var eyeY = 0f
        private var blinkUntil = System.currentTimeMillis() + 500L
        private var nextBlink = System.currentTimeMillis() + Random.nextLong(1700, 4300)
        private var actionUntil = 0L
        private var dizzyUntil = 0L
        private var impactUntil = 0L
        private var tapWindow = 0L
        private var tapCount = 0
        private var bounce = 0f
        private var wobble = 0f
        var audioLevel = 0f
        var dragging = false
            private set
        private var moved = false
        private var downX = 0f
        private var downY = 0f
        private var lastX = 0f
        private var lastY = 0f
        private var petOffsetX = 0f
        private var petOffsetY = 0f
        private var holdTriggeredLocal = false

        private var backgroundShader: Shader? = null

        init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            backgroundShader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(),
                intArrayOf(Color.rgb(12, 20, 52), Color.rgb(31, 41, 88), Color.rgb(20, 67, 94)), null, Shader.TileMode.CLAMP)
        }

        fun say(text: String, newMood: String) {
            caption = text.take(140)
            answer = text.take(900)
            mood = newMood
            actionUntil = System.currentTimeMillis() + if (newMood == "listening") 0 else 3200L
            invalidate()
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            val now = System.currentTimeMillis()
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.x; downY = event.y; lastX = downX; lastY = downY
                    moved = false; dragging = false; holdTriggeredLocal = false
                    eyeX = ((event.x - width / 2f) / max(1f, width * 0.25f)).coerceIn(-1f, 1f)
                    eyeY = ((event.y - height * 0.43f) / max(1f, height * 0.1f)).coerceIn(-1f, 1f)
                    if (event.y > dp(55)) main.postDelayed(holdRunnable, 520L)
                    invalidate(); return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - downX; val dy = event.y - downY
                    if (abs(dx) + abs(dy) > dp(18)) {
                        moved = true
                        main.removeCallbacks(holdRunnable)
                        if (abs(dx) + abs(dy) > dp(45)) dragging = true
                    }
                    if (dragging && !listening) {
                        petOffsetX = (petOffsetX + event.x - lastX).coerceIn(-width * 0.32f, width * 0.32f)
                        petOffsetY = (petOffsetY + event.y - lastY).coerceIn(-height * 0.12f, height * 0.18f)
                        caption = "Main tumhari ungli follow kar raha hoon!"
                        mood = "curious"
                    } else {
                        eyeX = ((event.x - width / 2f) / max(1f, width * 0.25f)).coerceIn(-1f, 1f)
                        eyeY = ((event.y - height * 0.43f) / max(1f, height * 0.1f)).coerceIn(-1f, 1f)
                    }
                    lastX = event.x; lastY = event.y
                    invalidate(); return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    main.removeCallbacks(holdRunnable)
                    if (listening) { stopListening(); return true }
                    if (holdTriggeredLocal) return true
                    if (dragging) {
                        dragging = false
                        mood = "playful"; caption = "Wheee! Pakad liya tumne!"; actionUntil = now + 1500L
                        invalidate(); return true
                    }
                    if (moved) return true
                    if (event.y < dp(70) && event.x > width - dp(90)) { finish(); return true }
                    handleTap(event.x, event.y, now)
                    invalidate(); return true
                }
            }
            return true
        }

        private fun handleTap(tx: Float, ty: Float, now: Long) {
            if (now - tapWindow > 2200L) { tapWindow = now; tapCount = 0 }
            tapCount++
            if (tapCount >= 5) {
                tapCount = 0; dizzyUntil = now + 1800L; impactUntil = now + 260L
                mood = "dizzy"; caption = "Arre! Chakkar aa gaye! Dheere se khelo."
                actionUntil = now + 1800L; return
            }
            val cx = width / 2f + petOffsetX
            val headY = height * 0.43f + petOffsetY
            val distanceX = abs(tx - cx)
            val bodyY = ty - headY
            when {
                bodyY < -dp(25) && distanceX > width * 0.10f -> { mood = "playful"; caption = "Kaan gudgudi mat karo!"; bounce = 0.65f }
                bodyY in -dp(44).toFloat()..dp(22).toFloat() && distanceX < dp(18) -> { mood = "surprised"; caption = "Boop! Naak par tap!"; impactUntil = now + 200L; wobble = 1f }
                bodyY < dp(35) -> { mood = "happy"; caption = "Aww, sir sehla rahe ho!"; bounce = 0.45f }
                bodyY in dp(35).toFloat()..dp(145).toFloat() -> { mood = "tickle"; caption = "Hahaha! Gudgudi ho rahi hai!"; bounce = 1f }
                distanceX > width * 0.12f -> { mood = "shy"; caption = "Paw pakda? Chalo high-five!"; bounce = 0.35f }
                else -> { mood = "happy"; caption = "Achha lag raha hai!"; bounce = 0.4f }
            }
            actionUntil = now + 2000L
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat(); val now = System.currentTimeMillis()
            p.shader = backgroundShader
            canvas.drawRect(0f, 0f, w, h, p); p.shader = null
            // Quiet background sparkles, kept lightweight for older phones.
            p.color = Color.argb(110, 165, 229, 255)
            for (i in 0..15) {
                val sx = ((i * 71 + 27) % max(1, width)).toFloat()
                val sy = ((i * 127 + 41) % max(1, height)).toFloat()
                canvas.drawCircle(sx, sy, if (i % 4 == 0) dp(2).toFloat() else dp(1).toFloat(), p)
            }
            p.color = Color.argb(95, 37, 214, 220)
            canvas.drawRoundRect(RectF(dp(14).toFloat(), dp(15).toFloat(), w - dp(14), dp(68).toFloat()), dp(20).toFloat(), dp(20).toFloat(), p)
            p.color = Color.WHITE; p.textSize = dp(16).toFloat(); p.typeface = Paint().typeface
            canvas.drawText("BLUEY BUDDY", dp(28).toFloat(), dp(39).toFloat(), p)
            p.textSize = dp(10).toFloat(); p.color = Color.rgb(201, 232, 249)
            canvas.drawText("VIRTUAL PET  ·  HOLD ANYWHERE TO TALK", dp(28).toFloat(), dp(56).toFloat(), p)

            if (now >= nextBlink) {
                blinkUntil = now + Random.nextLong(100, 170)
                nextBlink = now + Random.nextLong(1900, 5000)
            }
            if (actionUntil > 0 && now > actionUntil && mood !in listOf("listening", "thinking")) {
                mood = "calm"; caption = "Touch karke khelo · hold karke command bolo"; actionUntil = 0L
            }
            val bob = if (mood in listOf("happy", "playful", "tickle", "surprised")) sin(now / 150.0).toFloat() * dp(8) * max(bounce, 0.35f) else sin(now / 850.0).toFloat() * dp(2)
            val centerX = w / 2f + petOffsetX
            val headY = h * 0.43f + petOffsetY - bob
            val unit = min(w / 360f, h / 690f).coerceIn(0.72f, 1.25f)
            canvas.save()
            canvas.translate(centerX, headY)
            if (now < dizzyUntil) canvas.rotate(sin(now / 60.0).toFloat() * 18f)
            val squash = if (now < impactUntil) 0.67f else 1f
            canvas.scale(1f, squash)
            drawPuppy(canvas, centerX, headY, now, unit, h)
            canvas.restore()

            // Speech/status card beneath the puppy.
            p.color = Color.argb(220, 18, 29, 69)
            val cardTop = h * 0.78f
            canvas.drawRoundRect(RectF(dp(16).toFloat(), cardTop, w - dp(16), h - dp(30).toFloat()), dp(18).toFloat(), dp(18).toFloat(), p)
            p.color = if (mood == "listening") Color.rgb(123, 255, 241) else Color.rgb(255, 221, 131)
            p.textSize = dp(13).toFloat(); p.typeface = android.graphics.Typeface.DEFAULT_BOLD
            canvas.drawText(caption.take(42), dp(30).toFloat(), cardTop + dp(28), p)
            p.color = Color.rgb(226, 239, 255); p.textSize = dp(11).toFloat(); p.typeface = android.graphics.Typeface.DEFAULT
            val clean = answer.replace('\n', ' ')
            val start = cardTop + dp(49)
            canvas.drawText(clean.take(48), dp(30).toFloat(), start, p)
            if (clean.length > 48) canvas.drawText(clean.drop(48).take(48), dp(30).toFloat(), start + dp(16), p)
            if (mood == "listening") {
                p.color = Color.argb(80, 100, 255, 241)
                canvas.drawCircle(w / 2f, h * 0.68f, dp(82).toFloat() + audioLevel.coerceIn(0f, 12f), p)
            }
            postInvalidateDelayed(48L)
        }

        private fun drawPuppy(c: Canvas, originX: Float, originY: Float, now: Long, unit: Float, heightPx: Float) {
            // Coordinates are local to the puppy's head at (0,0).
            val s = dp(1).toFloat() * 1.0f
            val wag = sin(now / 120.0).toFloat() * dp(11)
            p.color = Color.argb(70, 0, 0, 0)
            c.drawOval(RectF(-dp(65).toFloat(), dp(224).toFloat(), dp(65).toFloat(), dp(239).toFloat()), p)
            // Tail behind body
            p.color = Color.rgb(43, 126, 215); p.style = Paint.Style.STROKE; p.strokeWidth = dp(14).toFloat(); p.strokeCap = Paint.Cap.ROUND
            val tail = Path().apply { moveTo(dp(25).toFloat(), dp(142).toFloat()); cubicTo(dp(79).toFloat(), dp(119).toFloat() + wag, dp(77).toFloat(), dp(178).toFloat() + wag, dp(54).toFloat(), dp(183).toFloat() + wag) }
            c.drawPath(tail, p); p.style = Paint.Style.FILL; p.strokeCap = Paint.Cap.BUTT
            // Body and belly
            p.color = Color.rgb(71, 175, 236)
            c.drawOval(RectF(-dp(47).toFloat(), dp(72).toFloat(), dp(47).toFloat(), dp(218).toFloat()), p)
            p.color = Color.rgb(216, 243, 252)
            c.drawOval(RectF(-dp(30).toFloat(), dp(100).toFloat(), dp(30).toFloat(), dp(177).toFloat()), p)
            // Legs and feet
            p.color = Color.rgb(55, 147, 222); p.strokeWidth = dp(17).toFloat(); p.strokeCap = Paint.Cap.ROUND
            c.drawLine(-dp(24).toFloat(), dp(185).toFloat(), -dp(30).toFloat(), dp(218).toFloat(), p)
            c.drawLine(dp(24).toFloat(), dp(185).toFloat(), dp(30).toFloat(), dp(218).toFloat(), p)
            p.strokeCap = Paint.Cap.BUTT
            p.color = Color.rgb(38, 108, 184)
            c.drawOval(RectF(-dp(51).toFloat(), dp(210).toFloat(), -dp(7).toFloat(), dp(232).toFloat()), p)
            c.drawOval(RectF(dp(7).toFloat(), dp(210).toFloat(), dp(51).toFloat(), dp(232).toFloat()), p)
            // Arms / paws
            p.color = Color.rgb(60, 157, 227); p.strokeWidth = dp(15).toFloat(); p.strokeCap = Paint.Cap.ROUND
            c.drawLine(-dp(39).toFloat(), dp(100).toFloat(), -dp(58).toFloat(), dp(136).toFloat() + wag * 0.13f, p)
            c.drawLine(dp(39).toFloat(), dp(100).toFloat(), dp(58).toFloat(), dp(136).toFloat() - wag * 0.13f, p)
            p.strokeCap = Paint.Cap.BUTT
            p.color = Color.rgb(35, 106, 177)
            c.drawCircle(-dp(60).toFloat(), dp(139).toFloat() + wag * 0.13f, dp(10).toFloat(), p)
            c.drawCircle(dp(60).toFloat(), dp(139).toFloat() - wag * 0.13f, dp(10).toFloat(), p)
            // Collar
            p.color = Color.rgb(255, 207, 81)
            c.drawRoundRect(RectF(-dp(39).toFloat(), dp(73).toFloat(), dp(39).toFloat(), dp(86).toFloat()), dp(6).toFloat(), dp(6).toFloat(), p)
            p.color = Color.rgb(244, 95, 119); c.drawCircle(0f, dp(87).toFloat(), dp(7).toFloat(), p)
            // Head squash is a playful virtual effect only.
            c.save(); c.scale(1f, if (now < impactUntil) 0.70f else 1f, 0f, 0f)
            p.color = Color.rgb(40, 119, 208)
            val leftEar = Path().apply { moveTo(-dp(42).toFloat(), -dp(32).toFloat()); cubicTo(-dp(94).toFloat(), -dp(85).toFloat(), -dp(76).toFloat(), dp(10).toFloat(), -dp(40).toFloat(), dp(12).toFloat()); close() }
            val rightEar = Path().apply { moveTo(dp(40).toFloat(), -dp(34).toFloat()); cubicTo(dp(92).toFloat(), -dp(90).toFloat(), dp(73).toFloat(), dp(5).toFloat(), dp(40).toFloat(), dp(10).toFloat()); close() }
            c.drawPath(leftEar, p); c.drawPath(rightEar, p)
            p.color = Color.rgb(80, 188, 244)
            c.drawOval(RectF(-dp(72).toFloat(), -dp(72).toFloat(), dp(72).toFloat(), dp(72).toFloat()), p)
            p.color = Color.argb(80, 255, 255, 255)
            c.drawOval(RectF(-dp(49).toFloat(), -dp(55).toFloat(), -dp(6).toFloat(), -dp(33).toFloat()), p)
            // Muzzle / cheeks
            p.color = Color.rgb(218, 244, 253)
            c.drawOval(RectF(-dp(39).toFloat(), dp(10).toFloat(), dp(39).toFloat(), dp(47).toFloat()), p)
            p.color = Color.argb(120, 255, 129, 163)
            c.drawCircle(-dp(48).toFloat(), dp(24).toFloat(), dp(9).toFloat(), p)
            c.drawCircle(dp(48).toFloat(), dp(24).toFloat(), dp(9).toFloat(), p)
            val blinking = now < blinkUntil || mood == "sleepy"
            p.color = Color.WHITE
            val eyeHeight = if (blinking) dp(3).toFloat() else if (mood == "surprised" || mood == "dizzy") dp(29).toFloat() else dp(23).toFloat()
            c.drawOval(RectF(-dp(44).toFloat(), -dp(24).toFloat(), -dp(13).toFloat(), -dp(24).toFloat() + eyeHeight), p)
            c.drawOval(RectF(dp(13).toFloat(), -dp(24).toFloat(), dp(44).toFloat(), -dp(24).toFloat() + eyeHeight), p)
            if (!blinking) {
                p.color = Color.rgb(19, 37, 65)
                val px = eyeX * dp(5); val py = eyeY * dp(3)
                c.drawCircle(-dp(28).toFloat() + px, -dp(12).toFloat() + py, dp(7).toFloat(), p)
                c.drawCircle(dp(28).toFloat() + px, -dp(12).toFloat() + py, dp(7).toFloat(), p)
                p.color = Color.WHITE
                c.drawCircle(-dp(30).toFloat() + px, -dp(15).toFloat() + py, dp(3).toFloat(), p)
                c.drawCircle(dp(26).toFloat() + px, -dp(15).toFloat() + py, dp(3).toFloat(), p)
            }
            p.color = Color.rgb(29, 70, 130); p.strokeWidth = dp(3).toFloat(); p.strokeCap = Paint.Cap.ROUND
            if (mood == "angry" || mood == "annoyed") {
                c.drawLine(-dp(44).toFloat(), -dp(34).toFloat(), -dp(18).toFloat(), -dp(27).toFloat(), p)
                c.drawLine(dp(18).toFloat(), -dp(27).toFloat(), dp(44).toFloat(), -dp(34).toFloat(), p)
            } else {
                c.drawLine(-dp(43).toFloat(), -dp(34).toFloat(), -dp(18).toFloat(), -dp(38).toFloat(), p)
                c.drawLine(dp(18).toFloat(), -dp(38).toFloat(), dp(43).toFloat(), -dp(34).toFloat(), p)
            }
            p.strokeCap = Paint.Cap.BUTT
            p.color = Color.rgb(26, 54, 86)
            c.drawOval(RectF(-dp(7).toFloat(), dp(2).toFloat(), dp(7).toFloat(), dp(12).toFloat()), p)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(2).toFloat(); p.strokeCap = Paint.Cap.ROUND
            if (mood == "surprised" || mood == "dizzy") c.drawOval(RectF(-dp(7).toFloat(), dp(18).toFloat(), dp(7).toFloat(), dp(33).toFloat()), p)
            else if (mood == "thinking") c.drawLine(-dp(9).toFloat(), dp(29).toFloat(), dp(9).toFloat(), dp(29).toFloat(), p)
            else c.drawArc(RectF(-dp(14).toFloat(), dp(17).toFloat(), dp(14).toFloat(), dp(38).toFloat()), 10f, 160f, false, p)
            p.style = Paint.Style.FILL
            c.restore()
            if (mood == "dizzy" || now < dizzyUntil) {
                p.color = Color.rgb(255, 221, 100); p.textSize = dp(22).toFloat(); p.typeface = android.graphics.Typeface.DEFAULT_BOLD
                c.drawText("✦", -dp(90).toFloat(), -dp(68).toFloat(), p)
                c.drawText("✦", dp(74).toFloat(), -dp(55).toFloat(), p)
            }
        }
    }
}
