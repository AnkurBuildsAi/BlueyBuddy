package com.blueybuddy.agent

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.graphics.Path
import android.accessibilityservice.GestureDescription
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/** User-enabled screen helper. It only sees accessibility text exposed by the active app. */
class BlueyAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: BlueyAccessibilityService? = null
        @Volatile var latestText: String = ""
        @Volatile var latestPackage: String = ""
        private val mainHandler = Handler(Looper.getMainLooper())

        fun isEnabled(): Boolean = instance != null

        fun clickLabel(label: String, result: (Boolean) -> Unit) {
            val service = instance
            if (service == null) { result(false); return }
            mainHandler.post { result(service.performVisibleLabelAction(label, AccessibilityNodeInfo.ACTION_CLICK)) }
        }

        fun longClickLabel(label: String, result: (Boolean) -> Unit) {
            val service = instance
            if (service == null) { result(false); return }
            mainHandler.post { result(service.performVisibleLabelAction(label, AccessibilityNodeInfo.ACTION_LONG_CLICK)) }
        }

        fun tapCoordinates(x: Int, y: Int, result: (Boolean) -> Unit) {
            val service = instance
            if (service == null) { result(false); return }
            mainHandler.post { result(service.tapAt(x, y)) }
        }

        fun performScroll(down: Boolean): Boolean {
            val service = instance ?: return false
            mainHandler.post { service.scrollScreen(down) }
            return true
        }

        fun setFocusedText(value: String, result: (Boolean) -> Unit) {
            val service = instance
            if (service == null) { result(false); return }
            mainHandler.post { result(service.setFocusedNodeText(value)) }
        }

        fun navigateBack(result: (Boolean) -> Unit) {
            val service = instance
            if (service == null) { result(false); return }
            mainHandler.post { result(service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)) }
        }

        fun navigateHome(result: (Boolean) -> Unit) {
            val service = instance
            if (service == null) { result(false); return }
            mainHandler.post { result(service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)) }
        }

        fun performGlobalAction(action: Int): Boolean {
            val service = instance ?: return false
            mainHandler.post { service.performGlobalAction(action) }
            return true
        }

        fun performSwipe(direction: String): Boolean {
            val service = instance ?: return false
            mainHandler.post { service.dispatchSwipe(direction) }
            return true
        }

        fun clickFirstContentElement(result: (Boolean) -> Unit) {
            val service = instance
            if (service == null) { result(false); return }
            mainHandler.post { result(service.clickFirstContentElementNow()) }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        refreshScreenText()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        latestPackage = event.packageName?.toString().orEmpty()
        refreshScreenText()
    }

    override fun onInterrupt() { }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun refreshScreenText() {
        val root = try { rootInActiveWindow } catch (_: Exception) { null }
        if (root == null) {
            latestText = ""
            latestPackage = ""
            return
        }
        val pieces = ArrayList<String>(80)
        try {
            collectText(root, pieces, 0)
        } finally {
            try { root.recycle() } catch (_: Exception) { }
        }
        val unique = LinkedHashSet<String>()
        for (piece in pieces) {
            val clean = piece.trim().replace(Regex("\\s+"), " ")
            if (clean.length > 1) unique.add(clean)
            if (unique.size >= 160) break
        }
        latestText = unique.joinToString(" | ").take(9000)
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 22 || out.size >= 220) return
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) out.add(text)
        if (desc.isNotEmpty() && desc != text) out.add(desc)
        val count = try { node.childCount } catch (_: Exception) { 0 }
        for (i in 0 until minOf(count, 40)) {
            val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
            try { collectText(child, out, depth + 1) } finally {
                try { child.recycle() } catch (_: Exception) { }
            }
            if (out.size >= 220) break
        }
    }


    private fun scrollScreen(down: Boolean): Boolean {
        val dm = resources.displayMetrics
        val x = dm.widthPixels * 0.52f
        val startY = if (down) dm.heightPixels * 0.78f else dm.heightPixels * 0.30f
        val endY = if (down) dm.heightPixels * 0.28f else dm.heightPixels * 0.78f
        val path = Path().apply { moveTo(x, startY); lineTo(x, endY) }
        return try {
            dispatchGesture(GestureDescription.Builder().addStroke(
                GestureDescription.StrokeDescription(path, 0, 420)
            ).build(), null, null)
        } catch (_: Exception) { false }
    }

    private fun dispatchSwipe(direction: String): Boolean {
        val dm = resources.displayMetrics
        val x1: Float
        val y1: Float
        val x2: Float
        val y2: Float
        when (direction.lowercase(Locale.ROOT)) {
            "left" -> { x1 = dm.widthPixels * 0.82f; x2 = dm.widthPixels * 0.18f; y1 = dm.heightPixels * 0.50f; y2 = y1 }
            "right" -> { x1 = dm.widthPixels * 0.18f; x2 = dm.widthPixels * 0.82f; y1 = dm.heightPixels * 0.50f; y2 = y1 }
            "up" -> { x1 = dm.widthPixels * 0.50f; x2 = x1; y1 = dm.heightPixels * 0.78f; y2 = dm.heightPixels * 0.25f }
            else -> { x1 = dm.widthPixels * 0.50f; x2 = x1; y1 = dm.heightPixels * 0.25f; y2 = dm.heightPixels * 0.78f }
        }
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        return try {
            dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 360)).build(), null, null)
        } catch (_: Exception) { false }
    }

    private fun clickFirstContentElementNow(): Boolean {
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return false
        return try { findFirstContentClick(root, 0) } finally { try { root.recycle() } catch (_: Exception) { } }
    }

    private fun findFirstContentClick(node: AccessibilityNodeInfo?, depth: Int): Boolean {
        if (node == null || depth > 24) return false
        val rect = android.graphics.Rect()
        try { node.getBoundsInScreen(rect) } catch (_: Exception) { }
        val label = (node.text?.toString() ?: node.contentDescription?.toString() ?: "").trim()
        val screenH = resources.displayMetrics.heightPixels
        if (node.isVisibleToUser && node.isClickable && node.isEnabled && label.length >= 3 && rect.top > screenH * 0.14f && rect.bottom < screenH * 0.94f) {
            val target = AccessibilityNodeInfo.obtain(node)
            var current: AccessibilityNodeInfo? = target
            var hops = 0
            while (current != null && hops < 6) {
                if (current.isClickable && current.isEnabled) {
                    val did = try { current.performAction(AccessibilityNodeInfo.ACTION_CLICK) } catch (_: Exception) { false }
                    try { current.recycle() } catch (_: Exception) { }
                    return did
                }
                val parent = try { current.parent } catch (_: Exception) { null }
                try { current.recycle() } catch (_: Exception) { }
                current = parent
                hops++
            }
            try { current?.recycle() } catch (_: Exception) { }
        }
        val count = try { node.childCount } catch (_: Exception) { 0 }
        for (i in 0 until minOf(count, 40)) {
            val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
            val clicked = try { findFirstContentClick(child, depth + 1) } finally { try { child.recycle() } catch (_: Exception) { } }
            if (clicked) return true
        }
        return false
    }

    private fun setFocusedNodeText(value: String): Boolean {
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return false
        return try {
            val focused = try { root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) } catch (_: Exception) { null }
            val node = focused ?: root
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
            }
            val ok = try { node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args) } catch (_: Exception) { false }
            if (focused != null && focused !== root) try { focused.recycle() } catch (_: Exception) { }
            ok
        } finally { try { root.recycle() } catch (_: Exception) { } }
    }

    private fun tapAt(x: Int, y: Int): Boolean {
        val dm = resources.displayMetrics
        val px = x.coerceIn(1, dm.widthPixels - 2).toFloat()
        val py = y.coerceIn(1, dm.heightPixels - 2).toFloat()
        val path = Path().apply { moveTo(px, py); lineTo(px + 1f, py + 1f) }
        return try { dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build(), null, null) }
        catch (_: Exception) { false }
    }

    private fun performVisibleLabelAction(label: String, action: Int): Boolean {
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return false
        val needle = label.trim().lowercase(Locale.ROOT)
        if (needle.isBlank()) { root.recycle(); return false }
        return try { findAndPerform(root, needle, 0, action) } finally { try { root.recycle() } catch (_: Exception) { } }
    }

    private fun findAndPerform(node: AccessibilityNodeInfo?, needle: String, depth: Int, action: Int): Boolean {
        if (node == null || depth > 24) return false
        val text = node.text?.toString().orEmpty().lowercase(Locale.ROOT)
        val desc = node.contentDescription?.toString().orEmpty().lowercase(Locale.ROOT)
        val matches = text == needle || desc == needle || (needle.length >= 4 && (text.contains(needle) || desc.contains(needle)))
        if (matches) {
            var target: AccessibilityNodeInfo? = AccessibilityNodeInfo.obtain(node)
            var hops = 0
            while (target != null && hops < 6) {
                if (target.isEnabled && (target.isClickable || action == AccessibilityNodeInfo.ACTION_LONG_CLICK)) {
                    val did = try { target.performAction(action) } catch (_: Exception) { false }
                    try { target.recycle() } catch (_: Exception) { }
                    if (did) return true
                    // If this node rejected a long-click, do not click it as a fallback.
                }
                val parent = try { target.parent } catch (_: Exception) { null }
                try { target.recycle() } catch (_: Exception) { }
                target = parent
                hops++
            }
            try { target?.recycle() } catch (_: Exception) { }
        }
        val count = try { node.childCount } catch (_: Exception) { 0 }
        for (i in 0 until minOf(count, 40)) {
            val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
            val done = try { findAndPerform(child, needle, depth + 1, action) } finally { try { child.recycle() } catch (_: Exception) { } }
            if (done) return true
        }
        return false
    }
}
