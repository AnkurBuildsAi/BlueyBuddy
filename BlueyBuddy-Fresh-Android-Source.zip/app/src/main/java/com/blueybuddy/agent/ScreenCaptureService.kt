package com.blueybuddy.agent

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

/** Optional, explicitly consented screen sharing. The most recent JPEG lives in memory only. */
class ScreenCaptureService : Service() {
    companion object {
        @Volatile var isCapturing: Boolean = false
        @Volatile var latestJpeg: ByteArray? = null
        @Volatile var capturedAtMs: Long = 0L
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var workerHandler: Handler? = null
    private var projectionCallback: MediaProjection.Callback? = null
    @Volatile private var lastStoredFrameMs: Long = 0L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(452, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (isCapturing) return START_STICKY
        val data = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        if (data == null || resultCode == 0) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            startCapture()
            isCapturing = true
        } catch (_: Exception) {
            ScreenCaptureService.latestJpeg = null
            isCapturing = false
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCapture() {
        val mediaProjection = projection ?: return
        val metrics = DisplayMetrics()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi.coerceAtLeast(120)

        workerThread = HandlerThread("BlueyScreenCapture").also { it.start() }
        workerHandler = Handler(workerThread!!.looper)
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader!!.setOnImageAvailableListener({ reader ->
            var image: Image? = null
            try {
                image = reader.acquireLatestImage()
                if (image != null) {
                    val now = System.currentTimeMillis()
                    // Keep only one reasonably fresh frame; avoid high CPU/battery usage.
                    if (now - lastStoredFrameMs >= 1100L) {
                        val jpeg = imageToJpeg(image!!)
                        if (jpeg != null) {
                            latestJpeg = jpeg
                            capturedAtMs = now
                            lastStoredFrameMs = now
                        }
                    }
                }
            } catch (_: Exception) {
                // A dropped frame is harmless; the next frame can replace it.
            } finally {
                try { image?.close() } catch (_: Exception) { }
            }
        }, workerHandler)

        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                isCapturing = false
                latestJpeg = null
                stopSelf()
            }
        }
        mediaProjection.registerCallback(projectionCallback!!, workerHandler)
        virtualDisplay = mediaProjection.createVirtualDisplay(
            "BlueyBuddyScreen", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, workerHandler
        )
        if (virtualDisplay == null) throw IllegalStateException("Screen virtual display could not start")
    }

    private fun imageToJpeg(image: Image): ByteArray? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer: ByteBuffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        if (pixelStride <= 0 || rowStride <= 0) return null
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + (rowPadding / pixelStride).coerceAtLeast(0)
        var padded: Bitmap? = null
        var cropped: Bitmap? = null
        try {
            padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
            buffer.rewind()
            padded.copyPixelsFromBuffer(buffer)
            cropped = if (paddedWidth == image.width) padded else Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
            val out = ByteArrayOutputStream()
            cropped.compress(Bitmap.CompressFormat.JPEG, 62, out)
            return out.toByteArray()
        } catch (_: Exception) {
            return null
        } finally {
            if (cropped != null && cropped !== padded) try { cropped.recycle() } catch (_: Exception) { }
            try { padded?.recycle() } catch (_: Exception) { }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopCaptureResources()
        isCapturing = false
        latestJpeg = null
        capturedAtMs = 0L
        lastStoredFrameMs = 0L
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        super.onDestroy()
    }

    private fun stopCaptureResources() {
        try { virtualDisplay?.release() } catch (_: Exception) { }
        virtualDisplay = null
        try { imageReader?.setOnImageAvailableListener(null, null) } catch (_: Exception) { }
        try { imageReader?.close() } catch (_: Exception) { }
        imageReader = null
        try { projectionCallback?.let { projection?.unregisterCallback(it) } } catch (_: Exception) { }
        projectionCallback = null
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        try { workerThread?.quitSafely() } catch (_: Exception) { }
        workerThread = null
        workerHandler = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel("bluey_screen", "Bluey screen understanding", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shows when you have explicitly enabled screen sharing for Bluey"
            })
        }
    }

    private fun buildNotification(): Notification {
        val launch = PendingIntent.getActivity(this, 5, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "bluey_screen")
            .setContentTitle("Bluey screen understanding is ON")
            .setContentText("Latest screen image stays in memory. Stop it from Bluey Buddy settings.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(launch).setOngoing(true).build()
    }
}
