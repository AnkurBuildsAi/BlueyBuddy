package com.blueybuddy.agent

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.media.projection.MediaProjectionManager
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var answerText: TextView
    private lateinit var apiKeyInput: EditText
    private lateinit var commandInput: EditText
    private lateinit var modelInput: EditText
    private var startWhenPermissionReturns = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        consumeAnswerIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) consumeAnswerIntent(intent)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(17, 20, 47), Color.rgb(31, 32, 76), Color.rgb(20, 46, 76)))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        scroll.addView(root)
        setContentView(scroll)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(18), dp(18), dp(20))
            background = roundBg(Color.rgb(31, 42, 83), 28)
        }
        root.addView(top, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        val avatar = TextView(this).apply {
            text = "🐾  BLUEY"
            textSize = 28f
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(Color.rgb(151, 248, 245))
            gravity = Gravity.CENTER
        }
        top.addView(avatar, lp(-1, -2))
        top.addView(text("YOUR LITTLE AI AGENT", 12f, Color.rgb(190, 202, 245), true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.13f
            setPadding(0, dp(4), 0, dp(8))
        }, lp(-1, -2))
        top.addView(text("Hold • Talk • Release • Bluey acts", 17f, Color.WHITE, true).apply { gravity = Gravity.CENTER }, lp(-1, -2))
        top.addView(text("Hindi / Hinglish voice • Smart answers • Floating pet", 12f, Color.rgb(198, 211, 239), false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }, lp(-1, -2))

        val actionCard = card(root, "01  ·  FLOATING PET", "Start Bluey over other apps. Press-and-hold the pet to talk; release to send your command.")
        val startButton = button("Start floating Bluey", Color.rgb(30, 197, 205))
        startButton.setOnClickListener { startPetFlow() }
        actionCard.addView(startButton, lp(-1, dp(48)).apply { topMargin = dp(10) })
        val stopButton = button("Stop Bluey", Color.rgb(73, 83, 125))
        stopButton.setOnClickListener {
            stopService(Intent(this, MascotOverlayService::class.java))
            setStatus("Bluey stopped")
        }
        actionCard.addView(stopButton, lp(-1, dp(44)).apply { topMargin = dp(8) })

        val permissionCard = card(root, "02  ·  PERMISSIONS", "Screen reading is optional. Android will show a system settings page; only enable it if you want Bluey to read visible text or click labelled controls when asked.")
        permissionCard.addView(button("Enable screen reading", Color.rgb(99, 105, 234)).apply {
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, lp(-1, dp(44)).apply { topMargin = dp(10) })
        permissionCard.addView(button("Overlay permission", Color.rgb(69, 80, 125)).apply {
            setOnClickListener { openOverlaySettings() }
        }, lp(-1, dp(44)).apply { topMargin = dp(8) })
        permissionCard.addView(button("Enable visual screen understanding", Color.rgb(41, 157, 173)).apply {
            setOnClickListener { requestVisualScreenSharing() }
        }, lp(-1, dp(44)).apply { topMargin = dp(8) })
        permissionCard.addView(button("Stop visual screen sharing", Color.rgb(83, 75, 120)).apply {
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
                ScreenCaptureService.isCapturing = false
                ScreenCaptureService.latestJpeg = null
                setStatus("Visual screen sharing stopped")
            }
        }, lp(-1, dp(44)).apply { topMargin = dp(8) })

        val keyCard = card(root, "03  ·  AI BRAIN", "Gemini API key stays in this app's local preferences. Do not upload it to GitHub or share it. AI answers need internet and a working key; basic commands do not.")
        apiKeyInput = EditText(this).apply {
            hint = "Paste Gemini API key"
            setHintTextColor(Color.rgb(157, 169, 201))
            setTextColor(Color.WHITE)
            textSize = 15f
            singleLine = true
            inputType = 0x00000081 // text + password
            setPadding(dp(14), dp(4), dp(14), dp(4))
            background = roundBg(Color.rgb(18, 24, 51), 12)
            setText(getSharedPreferences("bluey_agent", MODE_PRIVATE).getString("gemini_api_key", ""))
        }
        keyCard.addView(apiKeyInput, lp(-1, dp(48)).apply { topMargin = dp(10) })
        modelInput = EditText(this).apply {
            hint = "Gemini model (gemini-3.8-flash)"
            setHintTextColor(Color.rgb(157, 169, 201)); setTextColor(Color.WHITE); textSize = 14f
            singleLine = true; setPadding(dp(14), dp(4), dp(14), dp(4)); background = roundBg(Color.rgb(18, 24, 51), 12)
            setText(getSharedPreferences("bluey_agent", MODE_PRIVATE).getString("gemini_model", "gemini-3.8-flash"))
        }
        keyCard.addView(modelInput, lp(-1, dp(46)).apply { topMargin = dp(8) })
        keyCard.addView(button("Save AI settings", Color.rgb(50, 206, 170)).apply {
            setOnClickListener {
                getSharedPreferences("bluey_agent", MODE_PRIVATE).edit()
                    .putString("gemini_api_key", apiKeyInput.text.toString().trim())
                    .putString("gemini_model", modelInput.text.toString().trim().ifBlank { "gemini-3.8-flash" })
                    .apply()
                hideKeyboard(apiKeyInput)
                setStatus("AI settings saved on this phone")
            }
        }, lp(-1, dp(44)).apply { topMargin = dp(8) })
        keyCard.addView(text("Current model: Gemini 3.8 Flash (change only if your key supports another model).", 11f, Color.rgb(180, 193, 226), false).apply {
            setPadding(0, dp(8), 0, 0)
        }, lp(-1, -2))

        val commandCard = card(root, "04  ·  TEST A COMMAND", "Try: ‘YouTube kholo’, ‘YouTube par Arijit Singh search karo’, ‘Google par weather search karo’, ‘link copy karo’, ‘screen par kya hai’, or ‘click Search’.")
        commandInput = EditText(this).apply {
            hint = "Type a command or question…"
            setHintTextColor(Color.rgb(157, 169, 201)); setTextColor(Color.WHITE); textSize = 15f
            minLines = 2; maxLines = 4; gravity = Gravity.TOP
            setPadding(dp(14), dp(10), dp(14), dp(10)); background = roundBg(Color.rgb(18, 24, 51), 12)
        }
        commandCard.addView(commandInput, lp(-1, -2).apply { topMargin = dp(10) })
        commandCard.addView(button("Run command", Color.rgb(99, 105, 234)).apply {
            setOnClickListener {
                val command = commandInput.text.toString()
                if (command.isBlank()) Toast.makeText(this@MainActivity, "Command likho", Toast.LENGTH_SHORT).show()
                else runAgentCommand(command)
                hideKeyboard(commandInput)
            }
        }, lp(-1, dp(46)).apply { topMargin = dp(8) })

        val resultCard = card(root, "05  ·  BLUEY STATUS", "Tap the glowing thought bubble above Bluey's head to reopen the latest answer.")
        statusText = text("Ready • Start Bluey to use the floating pet", 13f, Color.rgb(141, 244, 221), true)
        resultCard.addView(statusText, lp(-1, -2).apply { topMargin = dp(8) })
        answerText = text("Your answer will appear here.", 15f, Color.WHITE, false)
        answerText.setPadding(0, dp(8), 0, dp(2))
        resultCard.addView(answerText, lp(-1, -2))

        root.addView(text("Built for Android 8.1+ • This is a fresh Android implementation, not a binary port of the original Mac/iOS app. Some apps hide their screen content and may block accessibility actions.",
            11f, Color.rgb(159, 171, 210), false).apply { setPadding(dp(4), dp(14), dp(4), 0) }, lp(-1, -2))
    }

    private fun card(parent: LinearLayout, title: String, description: String): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = roundBg(Color.rgb(36, 42, 79), 20)
        }
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(13) })
        card.addView(text(title, 14f, Color.rgb(122, 235, 237), true), lp(-1, -2))
        card.addView(text(description, 12f, Color.rgb(204, 213, 239), false).apply { setPadding(0, dp(6), 0, 0) }, lp(-1, -2))
        return card
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        setLineSpacing(dp(2).toFloat(), 1.0f)
    }

    private fun button(label: String, color: Int): Button = Button(this).apply {
        text = label; textSize = 14f; setTextColor(Color.WHITE); isAllCaps = false
        background = roundBg(color, 14)
        stateListAnimator = null
    }

    private fun roundBg(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun lp(width: Int, height: Int) = LinearLayout.LayoutParams(width, height)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun startPetFlow() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            startWhenPermissionReturns = true
            openOverlaySettings()
            Toast.makeText(this, "Allow display over other apps, then come back and tap Start again", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            startWhenPermissionReturns = true
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            return
        }
        startService(Intent(this, MascotOverlayService::class.java))
        setStatus("Bluey is floating • hold the pet to talk")
    }

    private fun requestVisualScreenSharing() {
        if (ScreenCaptureService.isCapturing) {
            setStatus("Visual screen sharing is already on; use Stop visual screen sharing to stop it first")
            return
        }
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), 42)
        } catch (_: Exception) {
            setStatus("This Android version could not start screen sharing")
        }
    }

    @Deprecated("Uses the system's screen-capture consent dialog")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42) {
            if (resultCode == RESULT_OK && data != null) {
                val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                }
                try {
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
                    setStatus("Visual screen sharing requested • look for its ongoing notification")
                } catch (_: Exception) {
                    setStatus("Screen sharing could not start")
                }
            } else setStatus("Screen sharing cancelled; text-only screen reading is still available")
        }
    }

    private fun openOverlaySettings() {
        if (Build.VERSION.SDK_INT >= 23) {
            try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (Settings.canDrawOverlays(this)) startService(Intent(this, MascotOverlayService::class.java))
                else Toast.makeText(this, "Overlay permission bhi allow karo", Toast.LENGTH_LONG).show()
                setStatus("Microphone permission granted")
            } else setStatus("Microphone permission denied • voice won't work")
        }
    }

    private fun runAgentCommand(command: String) {
        setStatus("Bluey is thinking…")
        AgentEngine.execute(this, command) { outcome ->
            setStatus(outcome.status)
            answerText.text = outcome.answer
        }
    }

    private fun setStatus(value: String) {
        if (::statusText.isInitialized) statusText.text = value
    }

    private fun consumeAnswerIntent(intent: Intent) {
        val answer = intent.getStringExtra("bluey_answer")
        val status = intent.getStringExtra("bluey_status")
        if (!answer.isNullOrBlank()) {
            if (::answerText.isInitialized) answerText.text = answer
            if (!status.isNullOrBlank()) setStatus(status)
        }
    }

    private fun hideKeyboard(view: View) {
        try { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(view.windowToken, 0) } catch (_: Exception) { }
    }
}
