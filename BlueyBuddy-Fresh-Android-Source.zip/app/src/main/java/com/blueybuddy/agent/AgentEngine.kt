package com.blueybuddy.agent

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.concurrent.Executors

data class AgentOutcome(
    val status: String,
    val answer: String,
    val mood: String = "happy",
    val shouldSpeak: Boolean = true
)

/** A small Android action router plus Gemini Q&A. Every device action has a bounded implementation. */
object AgentEngine {
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var lastUrl: String = ""
    @Volatile private var pendingClickLabel: String? = null

    fun execute(context: Context, spokenOrTyped: String, callback: (AgentOutcome) -> Unit) {
        val app = context.applicationContext
        main.post { MascotOverlayService.instance?.setThinking() }
        worker.execute {
            val raw = spokenOrTyped.trim()
            if (raw.isBlank()) {
                deliver(callback, AgentOutcome("कुछ सुनाई नहीं दिया", "Bluey को दबाकर रखो, बोलो और उंगली हटा दो।", "curious"))
                return@execute
            }
            val s = raw.lowercase(Locale.ROOT)

            if (isConfirm(s) && pendingClickLabel != null) {
                val target = pendingClickLabel!!
                pendingClickLabel = null
                BlueyAccessibilityService.clickLabel(target) { ok ->
                    deliver(callback, if (ok) AgentOutcome("काम हो गया", "मैंने स्क्रीन पर ‘$target’ चुना।", "happy")
                    else AgentOutcome("बटन नहीं मिला", "स्क्रीन पर ‘$target’ क्लिक नहीं हो पाया।", "confused"))
                }
                return@execute
            }
            if (isCancel(s) && pendingClickLabel != null) {
                pendingClickLabel = null
                deliver(callback, AgentOutcome("रद्द कर दिया", "ठीक है, मैंने वह कार्रवाई नहीं की।", "relieved"))
                return@execute
            }

            // Explicit Google searches are checked before YouTube searches.
            if (isGoogleSearch(s)) {
                val query = extractSearchQuery(raw, false).ifBlank { raw }
                val url = "https://www.google.com/search?q=" + enc(query)
                if (openUrl(app, url)) {
                    lastUrl = url
                    deliver(callback, AgentOutcome("Google पर खोज रहा हूँ", "Google पर ‘$query’ के नतीजे खोल दिए।", "busy"))
                } else deliver(callback, AgentOutcome("Browser नहीं खुला", "इस फोन में browser उपलब्ध नहीं मिला।", "confused"))
                return@execute
            }
            if (isYoutubeDownload(s)) {
                val url = "https://www.google.com/search?q=" + enc("YouTube official help download videos to watch offline")
                openUrl(app, url); lastUrl = url
                deliver(callback, AgentOutcome("आधिकारिक विकल्प खोजे", "YouTube के official offline-download विकल्प खोजे हैं। मैं किसी third-party downloader से वीडियो अपने-आप download नहीं करूँगा। YouTube का अपना Download विकल्प या ऐसा वीडियो इस्तेमाल करो जिसे डाउनलोड करने की अनुमति हो।", "careful"))
                return@execute
            }
            if (isYoutubeSearch(s)) {
                val query = extractSearchQuery(raw, true).ifBlank { "trending songs" }
                val url = "https://www.youtube.com/results?search_query=" + enc(query)
                openUrl(app, url); lastUrl = url
                deliver(callback, AgentOutcome("YouTube पर खोज रहा हूँ", "YouTube पर ‘$query’ के नतीजे खोल दिए।", "busy"))
                return@execute
            }
            if (isOpenYoutube(s)) {
                val url = "https://www.youtube.com"
                openUrl(app, url); lastUrl = url
                deliver(callback, AgentOutcome("YouTube खोल रहा हूँ", "YouTube खोल दिया है। कोई गाना या video खोजवाना हो तो बोलो: ‘YouTube पर [नाम] search करो’।", "happy"))
                return@execute
            }
            if ((s.startsWith("open http") || s.startsWith("open www.") || s.startsWith("website kholo") || s.startsWith("website खोलो")) && findUrl(raw) != null) {
                val url = findUrl(raw)!!
                if (openUrl(app, url)) {
                    lastUrl = url
                    deliver(callback, AgentOutcome("Website खोल रहा हूँ", "$url खोल दिया।", "busy"))
                } else deliver(callback, AgentOutcome("Website नहीं खुली", "इस लिंक को खोलने के लिए browser नहीं मिला।", "confused"))
                return@execute
            }
            if (isBackCommand(s)) {
                BlueyAccessibilityService.navigateBack { ok ->
                    deliver(callback, AgentOutcome("Back", if (ok) "पिछली स्क्रीन पर गया।" else "Back के लिए screen reading permission enable करो।", if (ok) "busy" else "confused"))
                }
                return@execute
            }
            if (isHomeCommand(s)) {
                BlueyAccessibilityService.navigateHome { ok ->
                    deliver(callback, AgentOutcome("Home", if (ok) "Home screen खोल दी।" else "Home action के लिए screen reading permission enable करो।", if (ok) "busy" else "confused"))
                }
                return@execute
            }
            if (isCopyLink(s)) {
                val url = findUrl(raw) ?: findUrl(BlueyAccessibilityService.latestText) ?: lastUrl
                if (url.isBlank()) deliver(callback, AgentOutcome("लिंक नहीं मिला", "पहले कोई वेबसाइट या search खोलो, फिर ‘इसका link copy करो’ बोलो।", "confused"))
                else {
                    val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Bluey link", url))
                    deliver(callback, AgentOutcome("लिंक कॉपी हो गया", "लिंक clipboard में कॉपी कर दिया: $url", "happy"))
                }
                return@execute
            }
            if (isOpenWhatsApp(s)) {
                openAppOrWeb(app, "com.whatsapp", "https://wa.me/")
                deliver(callback, AgentOutcome("WhatsApp खोल रहा हूँ", "WhatsApp खोलने की कोशिश की।", "happy")); return@execute
            }
            if (isOpenSettings(s)) {
                openIntent(app, Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                deliver(callback, AgentOutcome("Settings खोल रहा हूँ", "Android Settings खोल दिए।", "busy")); return@execute
            }
            if (isOpenCamera(s)) {
                openIntent(app, Intent("android.media.action.IMAGE_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                deliver(callback, AgentOutcome("Camera खोल रहा हूँ", "Camera खोलने की कोशिश की।", "happy")); return@execute
            }
            if (isOpenBrowser(s)) {
                val url = "https://www.google.com"
                openUrl(app, url); lastUrl = url
                deliver(callback, AgentOutcome("Browser खोल रहा हूँ", "Browser में Google खोल दिया।", "happy")); return@execute
            }

            if (isScreenQuestion(s)) {
                val screenText = BlueyAccessibilityService.latestText
                val recentScreenshot = ScreenCaptureService.latestJpeg
                val screenshot = recentScreenshot?.takeIf { System.currentTimeMillis() - ScreenCaptureService.capturedAtMs < 7000L }
                if (screenText.isBlank() && screenshot == null) {
                    val message = if (ScreenCaptureService.isCapturing) {
                        "Screen sharing चालू है, लेकिन नया screenshot अभी तैयार नहीं हुआ। एक पल बाद दोबारा पूछो।"
                    } else {
                        "Text पढ़ने के लिए ‘Enable screen reading’ चालू करो, या visuals/photos समझने के लिए ‘Enable visual screen understanding’ दबाकर Android का screen-share prompt स्वीकार करो। फिर दोबारा पूछो।"
                    }
                    deliver(callback, AgentOutcome("स्क्रीन पढ़ने की अनुमति चाहिए", message, "curious"))
                } else {
                    val prompt = "The user asks about their current Android phone screen. If a screenshot is attached, inspect only what is visible in that image; combine it with accessibility text if supplied. Do not guess hidden content. App package: ${BlueyAccessibilityService.latestPackage}. Accessibility text: ${screenText.ifBlank { "(not available)" }}. User question: $raw"
                    answerWithGemini(app, prompt, callback, screenshot)
                }
                return@execute
            }

            if (isClickCommand(s)) {
                val target = raw.replace(Regex("(?i)^(click|tap|press|क्लिक|दबाओ|टैप)\\s+"), "").trim()
                if (target.isBlank()) {
                    deliver(callback, AgentOutcome("कौन-सा बटन?", "कहो: ‘Search बटन क्लिक करो’।", "curious"))
                } else if (isSensitiveTarget(target)) {
                    pendingClickLabel = target
                    deliver(callback, AgentOutcome("एक बार पुष्टि करो", "मैं ‘$target’ दबाने वाला हूँ। सच में करना हो तो Bluey को hold करके ‘confirm’ कहो; नहीं तो ‘cancel’ कहो।", "careful"))
                } else {
                    BlueyAccessibilityService.clickLabel(target) { ok ->
                        deliver(callback, if (ok) AgentOutcome("स्क्रीन पर क्लिक किया", "मैंने ‘$target’ क्लिक किया।", "happy")
                        else AgentOutcome("क्लिक नहीं हुआ", "‘$target’ नाम का clickable text नहीं मिला। Screen reading चालू है और सही app सामने है, जाँचो।", "confused"))
                    }
                }
                return@execute
            }
            if (s.contains("scroll down") || s.contains("नीचे scroll") || s.contains("नीचे स्क्रोल")) {
                val ok = BlueyAccessibilityService.performScroll(true)
                deliver(callback, AgentOutcome("स्क्रीन नीचे", if (ok) "स्क्रीन नीचे scroll की।" else "पहले screen reading permission चालू करो।", if (ok) "busy" else "confused")); return@execute
            }
            if (s.contains("scroll up") || s.contains("ऊपर scroll") || s.contains("ऊपर स्क्रोल")) {
                val ok = BlueyAccessibilityService.performScroll(false)
                deliver(callback, AgentOutcome("स्क्रीन ऊपर", if (ok) "स्क्रीन ऊपर scroll की।" else "पहले screen reading permission चालू करो।", if (ok) "busy" else "confused")); return@execute
            }
            if (s.startsWith("type ") || s.startsWith("likho ") || s.startsWith("लिखो ")) {
                val value = raw.replace(Regex("(?i)^(type|likho|लिखो)\\s+"), "").trim()
                BlueyAccessibilityService.setFocusedText(value) { ok ->
                    deliver(callback, if (ok) AgentOutcome("टेक्स्ट भर दिया", "फोकस वाले text field में लिखा है। Send/submit करने से पहले खुद जाँच लेना।", "busy")
                    else AgentOutcome("Text field नहीं मिला", "जिस input में लिखना है, पहले उस पर tap करो और फिर ‘type ...’ बोलो।", "confused"))
                }
                return@execute
            }

            answerWithGemini(app, raw, callback)
        }
    }

    private fun answerWithGemini(context: Context, prompt: String, callback: (AgentOutcome) -> Unit, image: ByteArray? = null) {
        val prefs = context.getSharedPreferences("bluey_agent", Context.MODE_PRIVATE)
        val key = prefs.getString("gemini_api_key", "").orEmpty().trim()
        val model = prefs.getString("gemini_model", "gemini-3.8-flash").orEmpty().trim().ifBlank { "gemini-3.8-flash" }
        if (key.isBlank()) {
            deliver(callback, AgentOutcome("Gemini API key डालो", "AI जवाबों के लिए ऐप में अपनी Gemini API key सेव करो। Built-in app खोलना, search और copy-link commands key के बिना भी चल सकते हैं।", "confused"))
            return
        }
        try {
            val answer = callGemini(key, model, prompt, image)
            deliver(callback, AgentOutcome("Bluey का जवाब", answer, "happy"))
        } catch (e: Exception) {
            val message = when {
                e.message?.contains("HTTP 400") == true -> "Gemini request स्वीकार नहीं हुई। Model name/API key जाँचो।"
                e.message?.contains("HTTP 401") == true || e.message?.contains("HTTP 403") == true -> "Gemini API key या permissions में दिक्कत है। AI Studio में key जाँचो।"
                e.message?.contains("HTTP 429") == true -> "Gemini quota/rate limit पूरी हुई है। थोड़ी देर बाद कोशिश करो।"
                else -> "AI से जवाब नहीं मिला। Internet, API key और model ($model) जाँचो।"
            }
            deliver(callback, AgentOutcome("AI कनेक्शन में समस्या", message, "confused"))
        }
    }

    private fun callGemini(key: String, model: String, prompt: String, image: ByteArray?): String {
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/${enc(model)}:generateContent?key=${enc(key)}"
        val connection = URL(endpoint).openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.connectTimeout = 15000
        connection.readTimeout = 45000
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        connection.setRequestProperty("Accept", "application/json")
        try {
            val instruction = "You are Bluey Buddy, a friendly, playful Android pet-agent. Reply in the user's language (Hindi/Hinglish if used), briefly and clearly. You can help plan actions, but never claim you clicked, downloaded, sent, or changed something unless the app confirms it. For tasks requiring permission, explain that. Do not help bypass copyright protections. For screen questions, use the supplied screenshot if present and accessibility text as supplementary context; do not guess at hidden content. Give one practical next step for complex tasks."
            val userParts = JSONArray().put(JSONObject().put("text", prompt))
            if (image != null && image.isNotEmpty()) {
                userParts.put(JSONObject().put("inlineData", JSONObject()
                    .put("mimeType", "image/jpeg")
                    .put("data", Base64.encodeToString(image, Base64.NO_WRAP))))
            }
            val body = JSONObject()
                .put("store", false)
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", instruction))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", userParts)))
                .put("generationConfig", JSONObject().put("temperature", 0.4).put("maxOutputTokens", 900))
            connection.outputStream.use { it.write(body.toString().toByteArray(StandardCharsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader(StandardCharsets.UTF_8).use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code: ${response.take(180)}")
            val candidates = JSONObject(response).optJSONArray("candidates") ?: throw IllegalStateException("No candidates")
            val parts = candidates.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: throw IllegalStateException("No parts")
            val answer = (0 until parts.length()).mapNotNull { parts.optJSONObject(it)?.optString("text")?.takeIf { t -> t.isNotBlank() } }.joinToString("\n").trim()
            if (answer.isBlank()) throw IllegalStateException("Empty answer")
            return answer
        } finally { connection.disconnect() }
    }

    private fun deliver(callback: (AgentOutcome) -> Unit, outcome: AgentOutcome) {
        main.post {
            MascotOverlayService.instance?.showAgentOutcome(outcome)
            callback(outcome)
        }
    }

    private fun openUrl(context: Context, url: String): Boolean {
        val opened = openIntent(context, Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        if (opened) lastUrl = url
        return opened
    }

    private fun openAppOrWeb(context: Context, packageName: String, fallback: String) {
        try {
            val launch = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) { launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(launch) }
            else openUrl(context, fallback)
        } catch (_: Exception) { openUrl(context, fallback) }
    }

    private fun openIntent(context: Context, intent: Intent): Boolean = try {
        context.startActivity(intent); true
    } catch (_: Exception) { false }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")
    private fun findUrl(raw: String): String? = Regex("https?://[^\\s]+", RegexOption.IGNORE_CASE).find(raw)?.value?.trimEnd('.', ',', '!', '?')
    private fun isOpenYoutube(s: String) = (s.contains("youtube") || s.contains("यूट्यूब")) && listOf("open", "kholo", "खोलो", "खोल", "chalao", "चलाओ").any { s.contains(it) } && !isYoutubeSearch(s)
    private fun isYoutubeSearch(s: String) = (s.contains("youtube") || s.contains("यूट्यूब") || s.contains("गाना") || s.contains("gana") || s.contains("song")) && listOf("search", "खोज", "ढूंढ", "ढूँढ", "dhund", "khoj", "सर्च").any { s.contains(it) }
    private fun isGoogleSearch(s: String) = (s.contains("google") || s.contains("गूगल")) && listOf("search", "सर्च", "खोज", "ढूंढ", "ढूँढ", "par", "पर").any { s.contains(it) }
    private fun isYoutubeDownload(s: String) = (s.contains("youtube") || s.contains("यूट्यूब")) && listOf("download", "डाउनलोड").any { s.contains(it) }
    private fun isCopyLink(s: String) = (s.contains("copy") || s.contains("कॉपी")) && (s.contains("link") || s.contains("लिंक"))
    private fun isBackCommand(s: String) = listOf("go back", "back jao", "back करो", "पीछे जाओ", "वापस जाओ", "back button").any { s.contains(it) }
    private fun isHomeCommand(s: String) = listOf("go home", "home jao", "home screen", "होम स्क्रीन", "होम पर जाओ").any { s.contains(it) }
    private fun isOpenWhatsApp(s: String) = s.contains("whatsapp") && listOf("open", "kholo", "खोलो", "खोल", "start").any { s.contains(it) }
    private fun isOpenSettings(s: String) = (s.contains("settings") || s.contains("setting") || s.contains("सेटिंग")) && listOf("open", "kholo", "खोलो", "खोल").any { s.contains(it) }
    private fun isOpenCamera(s: String) = (s.contains("camera") || s.contains("कैमरा")) && listOf("open", "kholo", "खोलो", "खोल").any { s.contains(it) }
    private fun isOpenBrowser(s: String) = (s.contains("browser") || s.contains("chrome")) && listOf("open", "kholo", "खोलो", "खोल").any { s.contains(it) }
    private fun isScreenQuestion(s: String) = listOf("screen", "स्क्रीन", "what am i looking", "यहाँ क्या", "ye kya dikh", "kya dikh raha", "is page", "इस पेज").any { s.contains(it) }
    private fun isClickCommand(s: String) = listOf("click ", "tap ", "press ", "क्लिक ", "दबाओ ", "टैप ").any { s.startsWith(it) }
    private fun isSensitiveTarget(s: String) = listOf("send", "भेज", "delete", "डिलीट", "pay", "payment", "पेमेंट", "खरीद", "buy", "purchase", "install", "uninstall", "download", "डाउनलोड", "submit", "order", "ऑर्डर", "confirm", "post", "share").any { s.contains(it, true) }
    private fun isConfirm(s: String) = listOf("confirm", "हाँ", "haan", "yes", "कर दो", "kar do", "proceed", "पक्का").any { s == it || s.startsWith("$it ") }
    private fun isCancel(s: String) = listOf("cancel", "नहीं", "nahi", "रद्द", "stop").any { s == it || s.startsWith("$it ") }

    private fun extractSearchQuery(raw: String, youtube: Boolean): String {
        var q = raw.trim()
        // Drop the service name, leaving the topic the user asked to search for.
        q = q.replace(Regex("(?i)^(please\\s+)?(?:youtube|yt|यूट्यूब|google|गूगल)(?:\\s+(?:par|per|में|पर))?\\s*"), "")
        q = q.replace(Regex("(?i)^(?:gana|गाना|song|songs|video|वीडियो)(?:\\s+ka|\\s+की)?\\s*"), "")
        // Remove search verbs, including common Hindi/Hinglish forms, from either edge.
        q = q.replace(Regex("(?i)\\b(?:please|plz)\\b"), " ")
        q = q.replace(Regex("(?i)\\b(?:search|सर्च|खोजो|खोज|ढूंढो|ढूँढो|dhundo|khojo)\\b(?:\\s+(?:for|karo|karna|karke|करो|करना|करके))?\\s*$"), "")
        q = q.replace(Regex("(?i)^\\s*(?:search|सर्च|खोजो|खोज|ढूंढो|ढूँढो|dhundo|khojo)\\s*(?:for|karo|करो)?\\s*"), "")
            .replace(Regex("(?i)\\s+(?:karo|kar do|karke|करो|कर दो|करके)$"), "")
            .trim().trim('?', '।', '.', ' ')
        if (q.isBlank() && youtube) return "trending songs"
        if (q.isBlank()) return "Google Search"
        return q
    }
}
