package com.blueybuddy.agent

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.graphics.Path
import android.accessibilityservice.GestureDescription
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/** User-enabled screen helper. It only sees accessibility text exposed by the active app. */
class BlueyAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: BlueyAccessibilityService? = null
        @Volatile var latestText: String = ""
        @Volatile var latestPackage: String = ""
        private val mainHandler = Handler(Looper.getMainLooper())

        fun isEnabled(): Boolean = instance != null

        fun clickLabel(label: String, result: (Boolean) -> Unit) {
            val service = instance
            if (service == null) {
                result(false)
                return
            }
            mainHandler.post { result(service.clickVisibleLabel(label)) }
        }

        fun performScroll(down: Boolean): Boolean {
            val service = instance ?: return false
            mainHandler.post { service.scrollScreen(down) }
            return true
        }

        fun setFocusedText(value: String, result: (Boolean) -> Unit) {
            val service = instance
            if (service == null) { result(false); return }
            mainHandler.post { result(service.setFocusedNodeText(value)) }
        }

        fun navigateBack(result: (Boolean) -> Unit) {
            val service = instance
            if (service == null) { result(false); return }
            mainHandler.post { result(service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)) }
        }

        fun navigateHome(result: (Boolean) -> Unit) {
            val service = instance
            if (service == null) { result(false); return }
            mainHandler.post { result(service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)) }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        refreshScreenText()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        latestPackage = event.packageName?.toString().orEmpty()
        refreshScreenText()
    }

    override fun onInterrupt() { }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun refreshScreenText() {
        val root = try { rootInActiveWindow } catch (_: Exception) { null }
        if (root == null) {
            latestText = ""
            latestPackage = ""
            return
        }
        val pieces = ArrayList<String>(80)
        try {
            collectText(root, pieces, 0)
        } finally {
            try { root.recycle() } catch (_: Exception) { }
        }
        val unique = LinkedHashSet<String>()
        for (piece in pieces) {
            val clean = piece.trim().replace(Regex("\\s+"), " ")
            if (clean.length > 1) unique.add(clean)
            if (unique.size >= 160) break
        }
        latestText = unique.joinToString(" | ").take(9000)
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 22 || out.size >= 220) return
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) out.add(text)
        if (desc.isNotEmpty() && desc != text) out.add(desc)
        val count = try { node.childCount } catch (_: Exception) { 0 }
        for (i in 0 until minOf(count, 40)) {
            val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
            try { collectText(child, out, depth + 1) } finally {
                try { child.recycle() } catch (_: Exception) { }
            }
            if (out.size >= 220) break
        }
    }


    private fun scrollScreen(down: Boolean): Boolean {
        val dm = resources.displayMetrics
        val x = dm.widthPixels * 0.52f
        val startY = if (down) dm.heightPixels * 0.78f else dm.heightPixels * 0.30f
        val endY = if (down) dm.heightPixels * 0.28f else dm.heightPixels * 0.78f
        val path = Path().apply { moveTo(x, startY); lineTo(x, endY) }
        return try {
            dispatchGesture(GestureDescription.Builder().addStroke(
                GestureDescription.StrokeDescription(path, 0, 420)
            ).build(), null, null)
        } catch (_: Exception) { false }
    }

    private fun setFocusedNodeText(value: String): Boolean {
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return false
        return try {
            val focused = try { root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) } catch (_: Exception) { null }
            val node = focused ?: root
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
            }
            val ok = try { node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args) } catch (_: Exception) { false }
            if (focused != null && focused !== root) try { focused.recycle() } catch (_: Exception) { }
            ok
        } finally { try { root.recycle() } catch (_: Exception) { } }
    }

    private fun clickVisibleLabel(label: String): Boolean {
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return false
        val needle = label.trim().lowercase(Locale.ROOT)
        if (needle.isBlank()) {
            root.recycle()
            return false
        }
        return try {
            findAndClick(root, needle, 0)
        } finally {
            try { root.recycle() } catch (_: Exception) { }
        }
    }

    private fun findAndClick(node: AccessibilityNodeInfo?, needle: String, depth: Int): Boolean {
        if (node == null || depth > 24) return false
        val text = node.text?.toString().orEmpty().lowercase(Locale.ROOT)
        val desc = node.contentDescription?.toString().orEmpty().lowercase(Locale.ROOT)
        val matches = text == needle || desc == needle ||
                (needle.length >= 4 && (text.contains(needle) || desc.contains(needle)))
        if (matches) {
            var target: AccessibilityNodeInfo? = AccessibilityNodeInfo.obtain(node)
            var hops = 0
            while (target != null && hops < 6) {
                if (target.isClickable && target.isEnabled) {
                    val did = try { target.performAction(AccessibilityNodeInfo.ACTION_CLICK) } catch (_: Exception) { false }
                    try { target.recycle() } catch (_: Exception) { }
                    return did
                }
                val parent = try { target.parent } catch (_: Exception) { null }
                try { target.recycle() } catch (_: Exception) { }
                target = parent
                hops++
            }
            try { target?.recycle() } catch (_: Exception) { }
        }
        val count = try { node.childCount } catch (_: Exception) { 0 }
        for (i in 0 until minOf(count, 40)) {
            val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
            val clicked = try { findAndClick(child, needle, depth + 1) } finally {
                try { child.recycle() } catch (_: Exception) { }
            }
            if (clicked) return true
        }
        return false
    }
}
