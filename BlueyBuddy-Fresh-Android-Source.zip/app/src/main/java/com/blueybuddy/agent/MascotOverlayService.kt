package com.blueybuddy.agent

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class MascotOverlayService : Service() {
    companion object { @Volatile var instance: MascotOverlayService? = null }

    private lateinit var windowManager: WindowManager
    private lateinit var petView: PetOverlayView
    private lateinit var params: WindowManager.LayoutParams
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var isListening = false
    private var holdTriggered = false
    private var isDragging = false
    private var draggingWasRevealed = false
    private var downLocalX = 0f
    private var downLocalY = 0f
    private var downRawX = 0f
    private var downRawY = 0f
    private var downTime = 0L
    private var initialWindowX = 0
    private var initialWindowY = 0
    private var fingerOffsetX = 0f
    private var lastMoveX = 0f
    private var lastMoveY = 0f
    private var lastMoveTime = 0L
    private var lastUrl = ""
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var isAttached = false

    private val holdRunnable = Runnable {
        if (!isDragging && !draggingWasRevealed) {
            holdTriggered = true
            startListening()
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(451, buildNotification())
        tts = TextToSpeech(this) { result ->
            ttsReady = result == TextToSpeech.SUCCESS
            if (ttsReady) {
                val languageResult = tts?.setLanguage(Locale("hi", "IN"))
                if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.language = Locale.US
                }
            }
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Bluey needs display-over-other-apps permission", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        petView = PetOverlayView(this)
        val width = dp(232)
        val height = dp(218)
        params = WindowManager.LayoutParams(
            width, height,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(100)
        }
        try {
            windowManager.addView(petView, params)
            isAttached = true
        } catch (e: Exception) {
            Toast.makeText(this, "Bluey overlay could not start. Check overlay permission.", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        if (isAttached) try { windowManager.removeView(petView) } catch (_: Exception) { }
        isAttached = false
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) { }
        recognizer = null
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        tts = null
        if (instance === this) instance = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        super.onDestroy()
    }

    fun setThinking() {
        if (!isAttached) return
        petView.setMood("serious")
        petView.setCaption("Soch raha hoon…")
    }

    fun showAgentOutcome(outcome: AgentOutcome) {
        if (!isAttached) return
        petView.setMood(outcome.mood)
        petView.setCaption(outcome.status)
        petView.setAnswer(outcome.answer)
        isListening = false
        if (outcome.shouldSpeak && ttsReady && outcome.answer.isNotBlank()) {
            try {
                tts?.speak(outcome.answer.take(1800), TextToSpeech.QUEUE_FLUSH, null, "bluey_${System.currentTimeMillis()}")
            } catch (_: Exception) { }
        }
    }

    private fun startListening() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            petView.setMood("confused")
            petView.setCaption("Microphone permission chahiye")
            petView.setAnswer("Bluey Buddy app kholo aur microphone permission Allow karo.")
            vibrate(100)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            petView.setMood("confused")
            petView.setCaption("Speech service nahi mili")
            petView.setAnswer("Phone par Google app/Speech Recognition service install ya enable karke dobara try karo.")
            return
        }
        try {
            try { recognizer?.destroy() } catch (_: Exception) { }
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { petView.setCaption("Sun raha hoon… bolो"); petView.invalidate() }
                override fun onBeginningOfSpeech() { petView.setMood("listening") }
                override fun onRmsChanged(rmsdB: Float) { petView.setAudioLevel(rmsdB) }
                override fun onBufferReceived(buffer: ByteArray?) { }
                override fun onEndOfSpeech() { petView.setMood("thinking"); petView.setCaption("Samajh raha hoon…") }
                override fun onError(error: Int) {
                    isListening = false
                    petView.setAudioLevel(0f)
                    if (petView.captionText().startsWith("Sun raha hoon") || petView.captionText().startsWith("Samajh")) {
                        petView.setMood("curious")
                        petView.setCaption("Dobara hold karke bolo")
                        petView.setAnswer("Awaaz clear nahi mili. Bluey ko hold karke ek baar phir bolo.")
                    }
                }
                override fun onResults(results: Bundle?) {
                    isListening = false
                    petView.setAudioLevel(0f)
                    val said = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (said.isBlank()) {
                        petView.setMood("curious"); petView.setCaption("Kuch sunai nahi diya")
                        petView.setAnswer("Bluey ko press-and-hold karke phir bolo.")
                    } else {
                        petView.setMood("serious"); petView.setCaption("Soch raha hoon…")
                        petView.setAnswer("Heard: $said")
                        vibrate(35)
                        AgentEngine.execute(this@MascotOverlayService, said) { /* AgentEngine updates the floating pet; callback kept for UI symmetry. */ }
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val said = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (said.isNotBlank()) petView.setCaption("Sun raha hoon: ${said.take(28)}")
                }
                override fun onEvent(eventType: Int, params: Bundle?) { }
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 4)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Bluey ko command bolo")
            }
            isListening = true
            petView.setMood("listening")
            petView.setCaption("Sun raha hoon… bolो")
            petView.setAnswer("")
            vibrate(50)
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            isListening = false
            petView.setMood("confused")
            petView.setCaption("Mic start nahi hua")
            petView.setAnswer("Speech recognition start nahi hui. Microphone permission aur internet check karo.")
        }
    }

    private fun stopListening() {
        if (!isListening) return
        petView.setMood("thinking")
        petView.setCaption("Awaaz samajh raha hoon…")
        try { recognizer?.stopListening() } catch (_: Exception) {
            isListening = false
            petView.setCaption("Dobara hold karke bolo")
        }
    }

    private fun onPetTouch(view: View, event: MotionEvent): Boolean {
        val density = resources.displayMetrics.density
        val x = event.x / density
        val y = event.y / density
        val screenW = resources.displayMetrics.widthPixels
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downLocalX = x; downLocalY = y
                downRawX = event.rawX; downRawY = event.rawY
                downTime = System.currentTimeMillis()
                initialWindowX = params.x; initialWindowY = params.y
                fingerOffsetX = event.rawX - params.x
                lastMoveX = event.rawX; lastMoveY = event.rawY; lastMoveTime = downTime
                isDragging = false; holdTriggered = false; draggingWasRevealed = false
                val viewMaxX = screenW - petView.width
                if (params.x < 0 || params.x > viewMaxX) {
                    params.x = if (params.x < 0) 0 else max(0, viewMaxX)
                    try { windowManager.updateViewLayout(petView, params) } catch (_: Exception) { }
                    draggingWasRevealed = true
                    petView.setMood("curious"); petView.setCaption("Hello! Hold to talk")
                } else if (petView.hasAnswer() && y < 78f) {
                    // Answer bubble tap is handled on release; don't start listening here.
                } else {
                    main.postDelayed(holdRunnable, 460)
                }
                petView.lookAt(x, y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                petView.lookAt(x, y)
                if (isListening || holdTriggered || draggingWasRevealed) return true
                val totalDx = event.rawX - downRawX
                val totalDy = event.rawY - downRawY
                if (!isDragging && hypot(totalDx, totalDy) > dp(10)) {
                    isDragging = true
                    main.removeCallbacks(holdRunnable)
                    petView.setMood("startled"); petView.setCaption("Wheee!")
                    fingerOffsetX = downRawX - initialWindowX
                }
                if (isDragging) {
                    params.x = (event.rawX - fingerOffsetX).toInt()
                    params.y = (initialWindowY + totalDy).toInt().coerceIn(dp(12), max(dp(12), resources.displayMetrics.heightPixels - dp(120)))
                    try { windowManager.updateViewLayout(petView, params) } catch (_: Exception) { }
                    lastMoveX = event.rawX; lastMoveY = event.rawY; lastMoveTime = System.currentTimeMillis()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                main.removeCallbacks(holdRunnable)
                if (isListening) {
                    stopListening()
                    return true
                }
                if (isDragging) {
                    val elapsed = max(1L, System.currentTimeMillis() - downTime)
                    val speed = hypot(event.rawX - downRawX, event.rawY - downRawY) / elapsed.toFloat()
                    snapToEdge(screenW)
                    if (speed > 1.15f) {
                        petView.recoil()
                        petView.setMood("scared"); petView.setCaption("Eep! Gentle paws!")
                        vibrate(22)
                    } else if (params.x < 0 || params.x > screenW - petView.width) {
                        petView.setMood("shy"); petView.setCaption("Peekaboo!")
                    } else {
                        petView.setMood("curious"); petView.setCaption("Here I am!")
                    }
                    return true
                }
                if (draggingWasRevealed) return true
                if (petView.hasAnswer() && y < 78f) {
                    openAnswer()
                    return true
                }
                if (!holdTriggered && event.actionMasked == MotionEvent.ACTION_UP) {
                    if (event.pressure > 1.15f) {
                        petView.recoil()
                        petView.setMood("scared")
                        petView.setCaption("Eep! Gentle paws!")
                    } else {
                        petView.tapReaction()
                    }
                    if (System.currentTimeMillis() - downTime < 220) vibrate(12)
                }
                return true
            }
        }
        return true
    }

    private fun snapToEdge(screenW: Int) {
        val width = petView.width
        val left = params.x < screenW / 2
        params.x = if (left) -width + dp(46) else screenW - dp(46)
        params.y = params.y.coerceIn(dp(10), max(dp(10), resources.displayMetrics.heightPixels - dp(120)))
        try { windowManager.updateViewLayout(petView, params) } catch (_: Exception) { }
    }

    private fun openAnswer() {
        val i = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("bluey_answer", petView.fullAnswer())
            putExtra("bluey_status", petView.captionText())
        }
        try { startActivity(i) } catch (_: Exception) { }
    }

    private fun vibrate(duration: Long) {
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) { }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel("bluey_pet", "Bluey Buddy", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps the floating Bluey pet available"
            })
        }
    }

    private fun buildNotification(): Notification {
        val launch = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "bluey_pet")
            .setContentTitle("Bluey Buddy is awake")
            .setContentText("Hold Bluey to speak. Tap its thought bubble for the answer.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(launch).setOngoing(true).build()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    inner class PetOverlayView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var mood = "calm"
        private var caption = "Hold me to talk"
        private var answer = ""
        private var eyeX = 0f
        private var eyeY = 0f
        private var audioLevel = 0f
        private var blinkUntil = 0L
        private var recoilUntil = 0L
        private var idleNextMood = System.currentTimeMillis() + 5500
        private var moodUntil = 0L
        private var bubblePulse = 0f
        init { setLayerType(View.LAYER_TYPE_SOFTWARE, null); setOnTouchListener { view, event -> this@MascotOverlayService.onPetTouch(view, event) } }

        fun setMood(value: String) {
            mood = value
            val now = System.currentTimeMillis()
            moodUntil = when (value) {
                "listening" -> 0L
                "serious", "thinking" -> now + 15000L
                "startled", "scared" -> now + 1600L
                "happy", "playful", "shy", "relieved", "confused", "careful", "busy" -> now + 5200L
                else -> 0L
            }
            idleNextMood = now + 6000L
            invalidate()
        }
        fun setCaption(value: String) { caption = value; invalidate() }
        fun setAnswer(value: String) { answer = value.take(5000); invalidate() }
        fun hasAnswer() = answer.isNotBlank()
        fun fullAnswer() = answer
        fun captionText() = caption
        fun setAudioLevel(v: Float) { audioLevel = v.coerceIn(0f, 12f); invalidate() }
        fun lookAt(x: Float, y: Float) { eyeX = ((x - 115f) / 30f).coerceIn(-1f, 1f); eyeY = ((y - 130f) / 38f).coerceIn(-1f, 1f); invalidate() }
        fun tapReaction() {
            // A touch is a gentle physical reaction; task state/mood is not randomly toggled by taps.
            if (mood in listOf("calm", "happy", "curious", "playful")) caption = "Boop!"
            recoilUntil = System.currentTimeMillis() + 130
            invalidate()
        }
        fun recoil() { recoilUntil = System.currentTimeMillis() + 450; invalidate() }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val d = resources.displayMetrics.density
            canvas.save(); canvas.scale(d, d)
            val w = width / d; val h = height / d
            val now = System.currentTimeMillis()
            if (now > blinkUntil && Random.nextInt(350) == 0) blinkUntil = now + 130
            if (now > idleNextMood && mood in listOf("calm", "happy", "curious", "sleepy")) {
                mood = listOf("calm", "curious", "happy", "sleepy").random()
                idleNextMood = now + Random.nextLong(5000, 11000)
            }
            if (moodUntil > 0L && now >= moodUntil) {
                mood = if (answer.isNotBlank()) "curious" else "calm"
                moodUntil = 0L
                idleNextMood = now + Random.nextLong(5000, 10000)
            }
            bubblePulse = ((kotlin.math.sin(now / 260.0) + 1.0) / 2.0).toFloat()

            val bubbleVisible = answer.isNotBlank() || mood in listOf("listening", "thinking", "serious", "confused", "careful")
            if (bubbleVisible) drawBubble(canvas, w, h, d, now)
            val cx = if (bubbleVisible) w * 0.57f else w * 0.5f
            var cy = if (bubbleVisible) h * 0.69f else h * 0.53f
            if (now < recoilUntil) cy += (kotlin.math.sin((recoilUntil - now) / 25.0) * 5.0).toFloat()
            drawPet(canvas, cx, cy, now)
            canvas.restore()
            postInvalidateDelayed(55)
        }

        private fun drawBubble(c: Canvas, w: Float, h: Float, d: Float, now: Long) {
            val rect = RectF(9f, 5f, w - 9f, 73f)
            paint.color = Color.argb(40 + (bubblePulse * 45).toInt(), 77, 245, 243)
            paint.setShadowLayer(15f, 0f, 0f, Color.rgb(59, 241, 242))
            c.drawRoundRect(RectF(rect.left - 1, rect.top - 1, rect.right + 1, rect.bottom + 1), 18f, 18f, paint)
            paint.clearShadowLayer()
            paint.shader = android.graphics.LinearGradient(rect.left, rect.top, rect.right, rect.bottom,
                intArrayOf(Color.rgb(39, 58, 122), Color.rgb(30, 110, 138), Color.rgb(65, 60, 140)), null, android.graphics.Shader.TileMode.CLAMP)
            c.drawRoundRect(rect, 16f, 16f, paint)
            paint.shader = null
            paint.color = Color.rgb(126, 255, 248); paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.2f
            c.drawRoundRect(rect, 16f, 16f, paint); paint.style = Paint.Style.FILL
            paint.color = Color.WHITE; paint.textSize = 10.5f; paint.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            c.drawText(caption.take(31), 18f, 22f, paint)
            paint.color = Color.rgb(228, 245, 255); paint.textSize = 10f; paint.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            val lines = wrap(answer.replace('\n', ' '), 31).take(2)
            if (lines.isEmpty()) c.drawText(if (mood == "listening") "Speak; release to send" else "Hold pet to ask me…", 18f, 43f, paint)
            else lines.forEachIndexed { index, line -> c.drawText(line, 18f, 39f + index * 12f, paint) }
            paint.color = Color.rgb(146, 255, 250); paint.textSize = 8f
            c.drawText("TAP TO OPEN  ↗", w - 87f, 66f, paint)
        }

        private fun drawPet(c: Canvas, cx: Float, cy: Float, now: Long) {
            val shift = if (now < recoilUntil) (kotlin.math.sin((recoilUntil - now) / 22.0) * 8.0).toFloat() else 0f
            val x = cx + shift
            // Shadow
            paint.color = Color.argb(70, 0, 0, 0)
            c.drawOval(RectF(x - 42, cy + 36, x + 43, cy + 49), paint)
            // ears
            paint.color = Color.rgb(40, 125, 213)
            val leftEar = Path().apply { moveTo(x - 35, cy - 27); cubicTo(x - 58, cy - 70, x - 28, cy - 70, x - 20, cy - 34); close() }
            val rightEar = Path().apply { moveTo(x + 25, cy - 33); cubicTo(x + 25, cy - 75, x + 57, cy - 62, x + 46, cy - 24); close() }
            c.drawPath(leftEar, paint); c.drawPath(rightEar, paint)
            paint.color = Color.rgb(82, 191, 247)
            c.drawOval(RectF(x - 43, cy - 40, x + 43, cy + 43), paint)
            // head highlight
            paint.color = Color.argb(80, 255, 255, 255)
            c.drawOval(RectF(x - 28, cy - 35, x + 9, cy - 17), paint)
            // muzzle
            paint.color = Color.rgb(217, 244, 253)
            c.drawOval(RectF(x - 22, cy + 5, x + 22, cy + 30), paint)
            // eyes whites / blink
            val blinking = now < blinkUntil || mood == "sleepy"
            val eyeH = if (blinking) 3f else if (mood == "scared") 20f else 16f
            paint.color = Color.WHITE
            c.drawOval(RectF(x - 27, cy - 18, x - 7, cy - 18 + eyeH), paint)
            c.drawOval(RectF(x + 7, cy - 18, x + 27, cy - 18 + eyeH), paint)
            if (!blinking) {
                paint.color = Color.rgb(22, 38, 67)
                val pupilDx = eyeX * 4f
                val pupilDy = eyeY * 3f + if (mood == "thinking") -3f else 0f
                c.drawCircle(x - 17 + pupilDx, cy - 10 + pupilDy, if (mood == "scared") 6f else 5f, paint)
                c.drawCircle(x + 17 + pupilDx, cy - 10 + pupilDy, if (mood == "scared") 6f else 5f, paint)
                paint.color = Color.WHITE
                c.drawCircle(x - 18 + pupilDx, cy - 12 + pupilDy, 1.8f, paint)
                c.drawCircle(x + 16 + pupilDx, cy - 12 + pupilDy, 1.8f, paint)
            }
            // eyebrows communicate the current internal state
            paint.color = Color.rgb(27, 70, 130); paint.strokeWidth = 3f; paint.strokeCap = Paint.Cap.ROUND
            when (mood) {
                "serious", "thinking", "busy" -> {
                    c.drawLine(x - 28, cy - 26, x - 9, cy - 22, paint)
                    c.drawLine(x + 9, cy - 22, x + 28, cy - 26, paint)
                }
                "angry" -> { c.drawLine(x - 28, cy - 25, x - 9, cy - 18, paint); c.drawLine(x + 9, cy - 18, x + 28, cy - 25, paint) }
                "scared", "startled" -> { c.drawLine(x - 28, cy - 28, x - 8, cy - 31, paint); c.drawLine(x + 8, cy - 31, x + 28, cy - 28, paint) }
                else -> { c.drawLine(x - 26, cy - 26, x - 11, cy - 28, paint); c.drawLine(x + 11, cy - 28, x + 26, cy - 26, paint) }
            }
            paint.strokeCap = Paint.Cap.BUTT
            // nose
            paint.color = Color.rgb(26, 58, 89)
            c.drawOval(RectF(x - 4, cy + 1, x + 4, cy + 7), paint)
            // mouth expression
            paint.color = Color.rgb(27, 62, 93); paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f; paint.strokeCap = Paint.Cap.ROUND
            when (mood) {
                "scared", "startled", "confused" -> c.drawOval(RectF(x - 5, cy + 11, x + 5, cy + 20), paint)
                "serious", "thinking", "busy" -> c.drawLine(x - 7, cy + 18, x + 7, cy + 18, paint)
                "angry", "careful" -> { val path = Path().apply { moveTo(x - 9, cy + 19); quadTo(x, cy + 12, x + 9, cy + 19) }; c.drawPath(path, paint) }
                "sleepy" -> c.drawArc(RectF(x - 7, cy + 11, x + 7, cy + 20), 10f, 160f, false, paint)
                else -> c.drawArc(RectF(x - 11, cy + 10, x + 11, cy + 25), 10f, 160f, false, paint)
            }
            paint.style = Paint.Style.FILL
            // blush and collar
            paint.color = Color.argb(130, 255, 133, 164)
            c.drawCircle(x - 29, cy + 8, 5f, paint); c.drawCircle(x + 29, cy + 8, 5f, paint)
            paint.color = Color.rgb(255, 206, 85)
            c.drawRoundRect(RectF(x - 30, cy + 33, x + 30, cy + 41), 4f, 4f, paint)
            paint.color = Color.rgb(245, 103, 115); c.drawCircle(x, cy + 39, 4f, paint)
            // little animated status sparkles
            if (mood == "thinking" || mood == "serious") {
                paint.color = Color.rgb(133, 255, 247); paint.textSize = 17f; paint.typeface = Typeface.DEFAULT_BOLD
                val bob = (kotlin.math.sin(now / 220.0) * 3.0).toFloat()
                c.drawText("⋯", x + 40, cy - 33 + bob, paint)
            } else if (mood == "happy" || mood == "playful") {
                paint.color = Color.rgb(255, 221, 105); paint.textSize = 17f
                c.drawText("✦", x + 39, cy - 30 + (kotlin.math.sin(now / 180.0) * 2).toFloat(), paint)
            }
            // listening ring/audio pulse
            if (mood == "listening") {
                paint.color = Color.argb(115, 73, 244, 230); paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f
                val pulse = 49f + audioLevel * 0.5f + (bubblePulse * 3f)
                c.drawCircle(x, cy + 1, pulse, paint); paint.style = Paint.Style.FILL
            }
        }

        private fun wrap(text: String, limit: Int): List<String> {
            if (text.isBlank()) return emptyList()
            val words = text.split(Regex("\\s+"))
            val result = ArrayList<String>()
            var line = ""
            for (word in words) {
                val candidate = if (line.isEmpty()) word else "$line $word"
                if (candidate.length > limit && line.isNotEmpty()) { result.add(line); line = word } else line = candidate
                if (result.size == 3) break
            }
            if (line.isNotBlank() && result.size < 3) result.add(line)
            if (text.length > result.joinToString(" ").length && result.isNotEmpty()) result[result.lastIndex] = result.last() + "…"
            return result
        }
    }
}
