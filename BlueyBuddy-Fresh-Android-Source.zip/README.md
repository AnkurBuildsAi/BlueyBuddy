# Bluey Buddy Agent — fresh Android implementation

This project is **built from scratch for Android** (Kotlin + Android framework, no Compose/third-party UI dependencies). It is a fresh native implementation inspired by the floating-pet idea. It is not a direct port of the original macOS/iOS source; original Mac-only features that depend on the Mac app, OpenAI APIs, pairing, session history, research cards, or Codex controller are not included automatically.

## Included in this first agent build

- Colourful dark/teal/purple dashboard with API-key settings and command tester.
- Floating custom blue pet, blinking eyes that follow touch, subtle idle emotions, serious/thinking/listening/happy/confused/careful/scared states.
- Press and hold the pet to start Android SpeechRecognizer; release to stop and process the recognized phrase.
- Hindi (hi-IN) speech recognition, with the actual results depending on the phone's installed speech service and network.
- Gemini 3.8 Flash REST text answers (the model field is configurable), Hindi/Hinglish system instruction, local API-key preferences, bounded request timeouts, and `store:false`.
- Glowing answer bubble attached to the pet; tapping the bubble opens the full answer in the dashboard. Text-to-speech reads responses when the phone supports Hindi TTS.
- Built-in direct actions for YouTube open/search, Google search, WhatsApp open/fallback, browser, camera, Android settings, copy-last-opened-link, official YouTube offline-download help search, screen-text questions, scroll up/down, type into focused field, and click by visible accessibility label.
- Optional user-enabled Accessibility Service to read visible accessibility text, scroll, type into a focused field, click a labelled element, and navigate back/home. Sensitive-looking click labels need a separate spoken confirmation.
- Optional Android MediaProjection screen sharing after a separate system consent dialog; keeps only a JPEG-compressed recent screenshot in memory (about one frame/second) so Gemini can answer questions about pictures and visual UI. The screenshot is sent to Gemini only when the user asks a screen question; stop sharing to clear the in-memory image.
- Dragging the pet follows the finger; the eyes look toward touch; a quick flick triggers a recoil/startled animation; dragging to a screen edge tucks the pet partly off-screen and tapping its visible strip brings it back.
- Foreground notification keeps the floating pet alive while enabled; Stop Bluey stops the service.
- GitHub Actions build workflow and Hindi phone instructions.

## Important boundaries

This is a practical prototype, not an unrestricted computer-use agent. It cannot guarantee that every arbitrary app exposes its controls to Android Accessibility. Apps may hide text, block automation, change UI labels, or require app-specific authentication. It does not automatically control all apps, send messages, make payments, bypass login/captchas, or run arbitrary commands.

For YouTube videos, the built-in action opens official offline-download help; it does not scrape or download copyrighted videos through third-party downloader sites. Use YouTube's own download feature where available or content you have permission to download.

Screen questions can use accessibility text and, when separately enabled, a current screenshot. Screenshot capture requires the Android system's screen-sharing confirmation and remains visible as an ongoing notification. The most recent screenshot is kept in RAM only (not written to disk) and is sent to Gemini only when you ask a screen question. Accessibility text is captured only after you enable that service. Content sent to Gemini is sent to Google's API; do not ask Bluey to inspect sensitive pages unless you are comfortable sharing their visible content with the service. Some secure or DRM-protected screens can be black or unavailable.

The Gemini API key is stored locally in app preferences for testing. A shipped consumer app should call a backend rather than embedding a user's API key in the client. Do not commit keys to GitHub.

## Build

- Android Gradle Plugin 8.6.1, Gradle 8.7, Kotlin Android plugin 1.9.24, compile SDK 35.
- minSdk 26 (Android 8.0+); targetSdk 28 for the older phone target in this prototype.
- Project root is this directory; run `gradle --no-daemon assembleDebug` on a machine/runner with Android SDK platform 35 and build tools installed.
- Default model is `gemini-3.8-flash`; the current official model guide documents text and image input for this model: https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash/
- Output: `app/build/outputs/apk/debug/app-debug.apk`.

Build success is not the same as on-device validation. Test voice recognition, overlay permission, screen reading, TTS, and each action on the actual phone.
