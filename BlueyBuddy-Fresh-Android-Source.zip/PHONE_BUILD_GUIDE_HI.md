# Bluey Buddy Agent — मोबाइल से APK बनाने का तरीका (Hindi)

## A. तुम्हारे मौजूदा GitHub पर build करना

तुम्हारी मौजूदा repository `AnkurBuildsAi/BlueyBuddy` का workflow इस नाम की ZIP ढूँढ़ता है:

`BlueyBuddy-Android-Source-and-APK-Build-UPDATED.zip`

1. इस नई fresh-source ZIP को फोन में डाउनलोड करो।
2. GitHub पर `AnkurBuildsAi/BlueyBuddy` खोलो → **Code** टैब।
3. पुरानी `BlueyBuddy-Android-Source-and-APK-Build-UPDATED.zip` फ़ाइल खोलो → `...` मेनू से Delete करें और Commit करें।
4. **Add file → Upload files** चुनो और नई ZIP अपलोड करो। अपलोड के बाद उसका नाम ठीक वही होना चाहिए: `BlueyBuddy-Android-Source-and-APK-Build-UPDATED.zip`। Commit changes दबाओ।
5. **Actions** टैब खोलो। नया `Build Bluey Buddy APK` run शुरू होगा। उसे खोलो।
6. हरा ✅ आने पर नीचे `BlueyBuddy-debug-apk` artifact डाउनलोड करो। डाउनलोड ZIP खोलकर `app-debug.apk` निकालो और फोन में install करो। यह scratch से बना नया package (`Bluey Buddy Agent`) है, इसलिए पुराने prototype के साथ अलग app की तरह दिख सकता है—पहले सही नए app को खोलना सुनिश्चित करो।
7. Build लाल ❌ हो तो उस नए run का आखिरी error वाला हिस्सा कॉपी करके भेजो। पुराने run का error दोबारा मत भेजना।

> इस source ZIP के अंदर project folder `BlueyBuddyAgentFresh/` है। GitHub workflow ZIP को extract करके `settings.gradle` खोजेगा और इसी नए project को build करेगा। इसीलिए पुरानी source ZIP को repository में रखना ठीक नहीं—केवल नई source ZIP रखो।

## B. पहली बार APK खोलने के बाद

1. ऐप खोलो; **Start floating Bluey** दबाओ। पहले “Display over other apps” permission मांग सकता है; Allow करके ऐप में लौटो और Start फिर दबाओ।
2. Microphone permission मांगे तो Allow करो।
3. Floating Bluey को ½ सेकंड से ज्यादा दबाकर रखो, बोलो, फिर उंगली छोड़ दो। इससे recognized speech पर काम होना चाहिए। अगर वह सुन नहीं रहा, तो फोन में Google/Speech Recognition सेवा और internet जाँचो।
4. AI सवालों के लिए पहले Gemini API key बनाओ: `https://aistudio.google.com/apikey`। ऐप में **AI Brain** वाले field में paste करके **Save AI settings** दबाओ। API key GitHub पर कभी upload मत करना।
5. दूसरी ऐप की visible text पढ़ने के लिए dashboard में **Enable screen reading** दबाओ → Accessibility Settings में `Bluey Buddy Agent` चुनकर enable करो। यह अनुमति संवेदनशील है; इसे तभी enable करो जब तुम Bluey से स्क्रीन पढ़वाना चाहते हो।
6. Photos, चित्र और visual UI समझने के लिए **Enable visual screen understanding** दबाओ और Android का system screen-share prompt स्वीकार करो। Capture चलता रहे तो notification दिखाई देगा; dashboard से **Stop visual screen sharing** दबाने पर capture बंद और memory वाली image साफ हो जाएगी। Screenshot केवल तब Gemini को भेजा जाएगा जब तुम screen के बारे में सवाल पूछोगे।
7. Bubble पर tap करो तो पूरा जवाब dashboard में खुलेगा। जवाब की आवाज़ Android Text-to-Speech support पर निर्भर करती है।

## C. ये voice commands try करो

- “YouTube kholo”
- “YouTube par Arijit Singh search karo”
- “Google par YouTube video downloader search karo” — यह official offline-download मदद की खोज खोलेगा, third-party downloader से स्वतः video download नहीं करेगा।
- “Link copy karo” — यह Bluey द्वारा आखिरी खोला गया link clipboard में copy करता है।
- “Screen par kya hai?” — पहले Accessibility permission on होनी चाहिए।
- “Click Search” — visible accessibility label वाला control ढूँढ़कर click करने की कोशिश करेगा।
- “Scroll down” / “Scroll up”
- किसी text field को पहले tap/focus करके “Type hello world” बोलो। Send/submit खुद review करो।

**सीमा:** यह शुरुआती Android agent prototype है। Screen के ऐसे चित्र/visuals जिन्हें ऐप accessibility text के रूप में नहीं देता, यह नहीं समझता। हर app में click/type काम करना guaranteed नहीं है। Payments, messages भेजने, deleting जैसी संवेदनशील कार्रवाइयों से पहले confirmation रखी गई है, और unrestricted automation नहीं है। पहले build और फोन के basic tests पूरा करो, फिर अगली सुविधाओं पर काम किया जा सकता है।


**Build validation note:** इस ZIP को यहाँ Android SDK से compile करके सत्यापित नहीं किया गया है, क्योंकि इस environment में Android SDK/Gradle उपलब्ध नहीं थे। GitHub Actions की build पहली वास्तविक Gradle compile जांच होगी। APK build होना और फोन पर फीचर्स सही चलना अलग-अलग tests हैं।
