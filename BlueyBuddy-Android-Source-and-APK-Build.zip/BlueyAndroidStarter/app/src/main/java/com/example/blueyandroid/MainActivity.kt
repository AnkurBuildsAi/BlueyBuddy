package com.example.blueyandroid

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var apiKey: EditText
    private lateinit var prompt: EditText
    private lateinit var answer: TextView
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("bluey", MODE_PRIVATE)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
            setBackgroundColor(Color.rgb(247, 249, 255))
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "Bluey Buddy"
            textSize = 30f; setTextColor(Color.rgb(28, 45, 91)); gravity = Gravity.CENTER_VERTICAL
        }, match())
        root.addView(TextView(this).apply {
            text = "A movable, animated eyes mascot for Android. Start with the offline animations; Gemini is optional."
            textSize = 15f; setTextColor(Color.DKGRAY)
        }, margins(top = 8, bottom = 18))

        val start = Button(this).apply { text = "Enable floating mascot" }
        root.addView(start, margins(bottom = 8))
        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Allow display over other apps, then return and tap Enable", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, MascotOverlayService::class.java).setAction(MascotOverlayService.ACTION_START))
                Toast.makeText(this, "Mascot started — drag it, tap to change expression, double-tap for chat", Toast.LENGTH_LONG).show()
            }
        }
        root.addView(Button(this).apply {
            text = "Stop floating mascot"
            setOnClickListener { stopService(Intent(this@MainActivity, MascotOverlayService::class.java)) }
        }, margins(bottom = 18))

        root.addView(TextView(this).apply { text = "Gemini API key (optional)"; textSize = 17f; setTextColor(Color.BLACK) }, margins(bottom = 5))
        apiKey = EditText(this).apply {
            hint = "Paste your Gemini API key"
            inputType = 129
            setText(prefs.getString("gemini_key", "") ?: "")
        }
        root.addView(apiKey, margins(bottom = 8))
        root.addView(Button(this).apply {
            text = "Save API key on this phone"
            setOnClickListener {
                prefs.edit().putString("gemini_key", apiKey.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "Saved in app preferences", Toast.LENGTH_SHORT).show()
            }
        }, margins(bottom = 18))

        root.addView(TextView(this).apply { text = "Try Gemini chat"; textSize = 17f; setTextColor(Color.BLACK) }, margins(bottom = 5))
        prompt = EditText(this).apply { hint = "Ask Bluey something…"; minLines = 2; gravity = Gravity.TOP }
        root.addView(prompt, margins(bottom = 8))
        root.addView(Button(this).apply {
            text = "Ask Gemini"
            setOnClickListener { askGemini() }
        }, margins(bottom = 8))
        answer = TextView(this).apply { textSize = 15f; setTextColor(Color.DKGRAY); text = "Gemini replies will appear here." }
        root.addView(answer, margins(bottom = 20))
        root.addView(TextView(this).apply {
            text = "Notes: This starter draws its own original blue mascot; it does not include the original project's assets. Gemini needs internet and an API key. Do not share your key. Screen reading and automatic tapping are not enabled."
            textSize = 13f; setTextColor(Color.GRAY)
        })
    }

    private fun askGemini() {
        val key = apiKey.text.toString().trim().ifEmpty { getSharedPreferences("bluey", MODE_PRIVATE).getString("gemini_key", "") ?: "" }
        val question = prompt.text.toString().trim()
        if (key.isBlank()) { answer.text = "Pehle Gemini API key paste karke save karein."; return }
        if (question.isBlank()) { answer.text = "Pehle apna sawaal likhein."; return }
        answer.text = "Gemini se jawab aa raha hai…"
        thread {
            var result: String
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + java.net.URLEncoder.encode(key, "UTF-8"))
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000; doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "You are Bluey, a friendly tiny animated phone companion. Reply briefly and warmly. User says: $question")))))
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val raw = stream.bufferedReader().use { it.readText() }
                if (conn.responseCode !in 200..299) throw Exception("Gemini API error ${conn.responseCode}: $raw")
                val json = JSONObject(raw)
                result = json.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                conn.disconnect()
            } catch (e: Exception) { result = "Gemini request failed: ${e.message ?: "unknown error"}" }
            runOnUiThread {
                answer.text = result
                // Let the floating character react to the reply as well as showing text.
                val lower = result.lowercase()
                val mood = when {
                    listOf("sorry", "sad", "unfortunately", "dukhi").any { lower.contains(it) } -> "sleepy"
                    listOf("wow", "surprise", "amazing", "shocking", "wah").any { lower.contains(it) } -> "surprised"
                    listOf("think", "maybe", "perhaps", "soch").any { lower.contains(it) } -> "thinking"
                    listOf("haha", "lol", "great", "happy", "awesome", "khushi", "😊", "😄").any { lower.contains(it) } -> "happy"
                    else -> "listening"
                }
                try {
                    startService(Intent(this@MainActivity, MascotOverlayService::class.java)
                        .setAction(MascotOverlayService.ACTION_MOOD)
                        .putExtra(MascotOverlayService.EXTRA_MOOD, mood))
                } catch (_: Exception) { /* Chat still works if overlay is stopped. */ }
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun margins(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top); bottomMargin = dp(bottom) }
}
