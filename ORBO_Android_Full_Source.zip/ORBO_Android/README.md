# ORBO — Complete Android Assistant (v0.2.0 source)

Native Android (Kotlin + Jetpack Compose + plain Views overlay). Offline-first, koi AI/cloud API nahi.
Package: `com.orbo.assistant` | module: `app` | minSdk 26 | targetSdk 35 | compileSdk 36

## Kya-kya code mein hai
- Floating Orb (overlay service): tap=ripple+bounce, long-press=Pill+mic, drag, swipe-up Peek, swipe-down/tap restore, position save
- Orb: glow, eyes, mouth, blink, 14 reaction states, central state machine
- Smart Pill: Orb se morph, status text, mic, expand/collapse, scroll text, text input, confirm/choose buttons
- Voice: SpeechRecognizer (on-device agar mile), silence timeout 5/10/15/30s, text fallback, TTS (pause/resume/stop)
- Local command engine (Hindi/Hinglish/English), compound commands, app-name matching
- Task engine (CREATED..COMPLETED/FAILED/CANCELLED), duplicate prevention, retry, history
- Phone control (AccessibilityService): Back/Home/Recents, scroll, click, type, copy/paste, screen text read, verification
- Search + result open + rule-based summary + read aloud
- Timers (persist, AlarmManager, boot reschedule), stopwatch, reminders
- Message draft (preview + confirm + share chooser; ORBO khud nahi bhejta)
- Security: ORBO PIN (PBKDF2 + Keystore), Device Biometric, Security Page, lockout, recovery, selected-app check (best-effort)
- Custom Skills (create/edit/test/enable/run/delete), History, Memory (ask-before-save)

## Jo BLOCKED / NAHI hai (honest)
- Face verification: model + liveness nahi hai -> button honestly "unavailable" dikhata hai
- MediaProjection + OCR (screen-capture mode): is version mein nahi
- Room / DataStore: SharedPreferences + JSON files use hue (kam dependency risk)
- Universal app-lock / lock-screen access / secure screens padhna: Android allow nahi karta

## Build
`.github/workflows/android-apk.yml` alag se banega. Is project mein `gradlew` nahi hai; workflow Gradle 8.13 setup karega.
Versions: AGP 8.13.2 | Gradle 8.13 | Kotlin 2.2.21 | JDK 17

## IMPORTANT
Ye code abhi tak kisi ne compile ya phone par test nahi kiya. Pehla build GitHub Actions par hoga.
