package com.orbo.assistant.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.view.View
import com.orbo.assistant.orb.EyeStyle
import com.orbo.assistant.orb.MouthStyle
import com.orbo.assistant.orb.OrbState
import com.orbo.assistant.orb.OrbTimings
import com.orbo.assistant.orb.toFace
import kotlin.random.Random

/** Overlay window ke liye lightweight Canvas Orb (Compose ki jagah plain View: kam RAM, kam risk). */
class OrbCanvasView(context: Context) : View(context) {

    private var state: OrbState = OrbState.IDLE
    private var blink = 1f
    private var pulse = 1f
    private var ripple = -1f

    var reducedMotion: Boolean = false
        set(v) {
            field = v
            refreshAnimators()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }
    private val rect = RectF()
    private var cx = 0f
    private var cy = 0f
    private var outerR = 0f
    private var bodyR = 0f
    private var glowShader: Shader? = null
    private var violetShader: Shader? = null
    private var bodyShader: Shader? = null
    private var pulseAnim: ValueAnimator? = null
    private val handler = Handler(Looper.getMainLooper())
    private val blinkTask = object : Runnable {
        override fun run() {
            doBlink()
            scheduleBlink()
        }
    }

    fun setOrbState(s: OrbState) {
        if (s == state) return
        state = s
        refreshAnimators()
        invalidate()
    }

    fun playTap() {
        ripple = 0f
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = OrbTimings.RIPPLE_MS.toLong()
            addUpdateListener {
                ripple = it.animatedValue as Float
                invalidate()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    ripple = -1f
                    invalidate()
                }
            })
            start()
        }
        if (!reducedMotion) {
            animate().scaleX(1.12f).scaleY(1.12f).setDuration(OrbTimings.BOUNCE_MS.toLong() / 2)
                .withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(OrbTimings.BOUNCE_MS.toLong() / 2).start()
                }.start()
        }
    }

    fun playSquash() {
        if (reducedMotion) return
        scaleY = 0.82f
        animate().scaleY(1f).setDuration(OrbTimings.BOUNCE_MS.toLong()).start()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        refreshAnimators()
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(blinkTask)
        pulseAnim?.cancel()
        pulseAnim = null
        super.onDetachedFromWindow()
    }

    private fun refreshAnimators() {
        pulseAnim?.cancel()
        pulseAnim = null
        pulse = 1f
        handler.removeCallbacks(blinkTask)
        if (!isAttachedToWindow || reducedMotion) return
        val pulsing = state == OrbState.LISTENING || state == OrbState.THINKING || state == OrbState.EXECUTING
        if (pulsing) {
            pulseAnim = ValueAnimator.ofFloat(0.8f, 1f).apply {
                duration = 900
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                addUpdateListener {
                    pulse = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }
        scheduleBlink()
    }

    private fun scheduleBlink() {
        val sleepy = state == OrbState.SLEEPY
        val gap = if (sleepy) Random.nextLong(6000L, 9000L) else Random.nextLong(2500L, 5000L)
        handler.postDelayed(blinkTask, gap)
    }

    private fun doBlink() {
        val ms = if (state == OrbState.SLEEPY) OrbTimings.BLINK_MS * 3 else OrbTimings.BLINK_MS
        ValueAnimator.ofFloat(1f, 0.1f, 1f).apply {
            duration = ms.toLong()
            addUpdateListener {
                blink = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cx = w / 2f
        cy = h / 2f
        outerR = minOf(w, h) / 2f
        bodyR = outerR * 0.78f
        if (outerR <= 0f) return
        val blue = Color.parseColor("#2EA8FF")
        val violet = Color.parseColor("#8B5CF6")
        glowShader = RadialGradient(cx, cy, outerR, intArrayOf(blue, Color.argb(0, 46, 168, 255)), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        val vx = cx + bodyR * 0.35f
        val vy = cy + bodyR * 0.45f
        violetShader = RadialGradient(vx, vy, outerR * 0.8f, intArrayOf(violet, Color.argb(0, 139, 92, 246)), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        bodyShader = RadialGradient(
            cx - bodyR * 0.3f, cy - bodyR * 0.35f, bodyR * 1.8f,
            intArrayOf(Color.parseColor("#6FC4FF"), Color.parseColor("#2B5BE0"), Color.parseColor("#3B1E8C")),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP,
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (outerR <= 0f) return
        val face = state.toFace()

        paint.shader = glowShader
        paint.alpha = (255 * 0.55f * pulse).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, outerR, paint)

        paint.shader = violetShader
        paint.alpha = (255 * 0.45f * pulse).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx + bodyR * 0.35f, cy + bodyR * 0.45f, outerR * 0.8f, paint)

        paint.shader = bodyShader
        paint.alpha = 255
        canvas.drawCircle(cx, cy, bodyR, paint)

        paint.shader = null
        paint.color = Color.argb(80, 255, 255, 255)
        rect.set(cx - bodyR * 0.5f, cy - bodyR * 0.85f, cx + bodyR * 0.4f, cy - bodyR * 0.47f)
        canvas.drawOval(rect, paint)

        // eyes
        paint.color = Color.WHITE
        val eyeY = cy - bodyR * 0.10f
        val gap = bodyR * 0.36f
        val left = eyeDims(face.eyes, true)
        val right = eyeDims(face.eyes, false)
        drawEye(canvas, cx - gap, eyeY, left, face.eyes)
        drawEye(canvas, cx + gap, eyeY, right, face.eyes)

        // mouth
        val my = cy + bodyR * 0.38f
        val mw = bodyR * 0.30f
        strokePaint.strokeWidth = bodyR * 0.06f
        when (face.mouth) {
            MouthStyle.NEUTRAL -> canvas.drawLine(cx - mw / 2f, my, cx + mw / 2f, my, strokePaint)
            MouthStyle.SMILE -> {
                rect.set(cx - mw, my - mw * 0.6f, cx + mw, my + mw * 0.6f)
                canvas.drawArc(rect, 20f, 140f, false, strokePaint)
            }
            MouthStyle.SURPRISED -> {
                rect.set(cx - mw * 0.25f, my - mw * 0.3f, cx + mw * 0.25f, my + mw * 0.3f)
                canvas.drawOval(rect, paint)
            }
            MouthStyle.THINKING -> canvas.drawLine(cx - mw * 0.4f, my, cx + mw * 0.6f, my - mw * 0.15f, strokePaint)
        }

        // ripple
        if (ripple >= 0f) {
            strokePaint.strokeWidth = bodyR * 0.05f
            strokePaint.alpha = ((1f - ripple) * 200).toInt().coerceIn(0, 255)
            canvas.drawCircle(cx, cy, bodyR * (0.6f + 0.4f * ripple) + outerR * 0.2f * ripple, strokePaint)
            strokePaint.alpha = 255
        }
    }

    private class Dims(val w: Float, val h: Float, val dx: Float)

    private fun eyeDims(style: EyeStyle, isLeft: Boolean): Dims = when (style) {
        EyeStyle.OPEN -> Dims(0.20f, 0.30f, 0f)
        EyeStyle.FOCUSED -> Dims(0.22f, 0.18f, 0f)
        EyeStyle.CURIOUS -> Dims(0.24f, 0.36f, 0f)
        EyeStyle.SLEEPY -> Dims(0.22f, 0.08f, 0f)
        EyeStyle.SERIOUS -> Dims(0.24f, 0.16f, 0f)
        EyeStyle.CONFUSED -> if (isLeft) Dims(0.20f, 0.36f, 0f) else Dims(0.20f, 0.18f, 0f)
        EyeStyle.SIDE -> Dims(0.20f, 0.30f, 0.12f)
        EyeStyle.HAPPY -> Dims(0.22f, 0.20f, 0f)
    }

    private fun drawEye(canvas: Canvas, x0: Float, y: Float, d: Dims, style: EyeStyle) {
        val x = x0 + d.dx * bodyR
        val w = d.w * bodyR
        if (style == EyeStyle.HAPPY) {
            val h = d.h * bodyR
            strokePaint.strokeWidth = bodyR * 0.07f
            rect.set(x - w, y - h * 0.5f, x + w, y + h * 1.1f)
            canvas.drawArc(rect, 200f, 140f, false, strokePaint)
        } else {
            val h = d.h * bodyR * blink
            rect.set(x - w / 2f, y - h / 2f, x + w / 2f, y + h / 2f)
            canvas.drawOval(rect, paint)
        }
    }
}
