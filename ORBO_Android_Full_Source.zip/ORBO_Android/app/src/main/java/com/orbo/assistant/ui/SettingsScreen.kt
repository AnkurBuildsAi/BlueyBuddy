package com.orbo.assistant.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.core.Stores
import com.orbo.assistant.overlay.OrbOverlayService

@Composable
fun SettingsScreen(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val p = Orbo.prefs
    var size by remember { mutableStateOf(p.orbSizeDp.toFloat()) }
    var longMs by remember { mutableStateOf(p.longPressMs.toFloat()) }
    var silence by remember { mutableStateOf(p.silenceSec) }
    var lang by remember { mutableStateOf(p.lang) }
    var reduced by remember { mutableStateOf(p.reducedMotion) }
    var sleepy by remember { mutableStateOf(p.sleepyEnabled) }
    var speak by remember { mutableStateOf(p.speakReplies) }

    fun restartOverlay() {
        if (p.overlayEnabled) {
            OrbOverlayService.stop(ctx)
            OrbOverlayService.start(ctx)
        }
    }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)

        Text("Orb size: ${size.toInt()} dp", style = MaterialTheme.typography.titleSmall)
        Slider(value = size, onValueChange = { size = it }, valueRange = 48f..100f,
            onValueChangeFinished = { p.orbSizeDp = size.toInt(); restartOverlay() })

        Text("Long-press time: ${longMs.toInt()} ms", style = MaterialTheme.typography.titleSmall)
        Slider(value = longMs, onValueChange = { longMs = it }, valueRange = 300f..1000f,
            onValueChangeFinished = { p.longPressMs = longMs.toLong() })

        Text("Voice silence timeout", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(5, 10, 15, 30).forEach { s ->
                FilterChip(selected = silence == s, onClick = { silence = s; p.silenceSec = s }, label = { Text("${s}s") })
            }
        }

        Text("Voice language", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("hi-IN" to "Hindi/Hinglish", "en-IN" to "English (IN)", "en-US" to "English (US)").forEach { (code, label) ->
                FilterChip(selected = lang == code, onClick = { lang = code; p.lang = code }, label = { Text(label) })
            }
        }
        Text("Language ka offline model device par install hona chahiye; warna voice fail hoga aur text mode chalega.", style = MaterialTheme.typography.bodySmall)

        SwitchRow("Reduced motion (blink/pulse/animation band)", reduced) { reduced = it; p.reducedMotion = it; restartOverlay() }
        SwitchRow("Sleepy mode (60 sec idle ke baad)", sleepy) { sleepy = it; p.sleepyEnabled = it }
        SwitchRow("Jawab bolkar sunao (TextToSpeech)", speak) { speak = it; p.speakReplies = it }

        OutlinedButton(onClick = { Stores.history.clear() }, modifier = Modifier.fillMaxWidth()) { Text("History clear karo") }
        Text("ORBO v0.2.0  •  Data phone se bahar nahi jata (sirf web search ke liye internet).", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = value, onCheckedChange = onChange)
    }
}
