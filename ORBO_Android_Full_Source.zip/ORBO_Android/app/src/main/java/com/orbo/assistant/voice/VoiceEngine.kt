package com.orbo.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Android SpeechRecognizer wrapper. Offline hona device par depend karta hai:
 * on-device recognizer (Android 13+) mile to wahi use hota hai, warna PREFER_OFFLINE hint bheja jata hai
 * (guarantee nahi). Fail hone par text-input fallback suggest hota hai.
 */
class VoiceEngine(private val ctx: Context) {

    interface Callback {
        fun onPartial(text: String)
        fun onFinal(text: String)
        fun onFailure(message: String, suggestText: Boolean)
    }

    private var recognizer: SpeechRecognizer? = null
    private val main = Handler(Looper.getMainLooper())
    private var cb: Callback? = null
    private var silenceMs = 10000L
    private var active = false
    var usedOnDevice = false
        private set

    private val timeoutTask = Runnable {
        if (active) {
            fail("Koi awaaz nahi suni (silence timeout). Dobara try karo ya text likho.", true)
        }
    }

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(ctx)

    fun onDeviceAvailable(): Boolean =
        Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx)

    fun start(lang: String, silenceSec: Int, callback: Callback) {
        if (!isAvailable()) {
            callback.onFailure("Is phone par speech recognition service nahi mili. Text command use karo.", true)
            return
        }
        cancel()
        cb = callback
        silenceMs = silenceSec * 1000L
        active = true
        try {
            val r = if (onDeviceAvailable()) {
                usedOnDevice = true
                SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
            } else {
                usedOnDevice = false
                SpeechRecognizer.createSpeechRecognizer(ctx)
            }
            recognizer = r
            r.setRecognitionListener(listener)
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
            }
            r.startListening(i)
            main.postDelayed(timeoutTask, silenceMs)
        } catch (e: Exception) {
            fail("Mic start nahi ho paya: ${e.message ?: "unknown error"}. Text command use karo.", true)
        }
    }

    /** User ne Stop dabaya: abhi tak ki awaaz ka result maango. */
    fun stopListening() {
        try { recognizer?.stopListening() } catch (e: Exception) { }
    }

    fun cancel() {
        active = false
        main.removeCallbacks(timeoutTask)
        destroy()
    }

    private fun destroy() {
        try { recognizer?.cancel() } catch (e: Exception) { }
        try { recognizer?.destroy() } catch (e: Exception) { }
        recognizer = null
    }

    private fun fail(msg: String, suggest: Boolean) {
        if (!active) return
        active = false
        main.removeCallbacks(timeoutTask)
        destroy()
        cb?.onFailure(msg, suggest)
    }

    private fun resetTimer() {
        main.removeCallbacks(timeoutTask)
        if (active) main.postDelayed(timeoutTask, silenceMs)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() { resetTimer() }
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank() && active) {
                resetTimer()
                cb?.onPartial(t)
            }
        }

        override fun onResults(results: Bundle?) {
            if (!active) return
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            active = false
            main.removeCallbacks(timeoutTask)
            destroy()
            if (t.isNullOrBlank()) {
                cb?.onFailure("Kuch samajh nahi aaya. Dobara bolo ya text likho.", true)
            } else {
                cb?.onFinal(t)
            }
        }

        override fun onError(error: Int) {
            if (!active) return
            val msg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH -> "Awaaz samajh nahi aayi. Dobara bolo."
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Koi awaaz nahi suni."
                SpeechRecognizer.ERROR_AUDIO -> "Mic/audio error. Dusri app mic use kar rahi ho sakti hai."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mic permission nahi hai."
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                    "Is speech service ko internet chahiye aur offline model nahi mila. Text command use karo."
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech service busy hai. Thodi der baad try karo."
                SpeechRecognizer.ERROR_SERVER -> "Speech service error. Text command use karo."
                SpeechRecognizer.ERROR_CLIENT -> "Speech client error. Dobara try karo."
                12 -> "Ye language is speech service mein supported nahi hai (Settings mein language badlo)."
                13 -> "Is language ka offline model install nahi hai."
                else -> "Voice error (code $error). Text command use karo."
            }
            fail(msg, true)
        }
    }
}
