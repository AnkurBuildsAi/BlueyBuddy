package com.orbo.assistant.core

import android.content.Context
import android.content.SharedPreferences

/** Simple settings (SharedPreferences). PIN verifier Keystore se encrypt hoke yahin blob ke roop mein rehta hai. */
class Prefs(ctx: Context) {
    private val sp: SharedPreferences = ctx.getSharedPreferences("orbo_prefs", Context.MODE_PRIVATE)

    var orbSizeDp: Int
        get() = sp.getInt("orbSizeDp", 68)
        set(v) { sp.edit().putInt("orbSizeDp", v.coerceIn(48, 100)).apply() }

    var orbX: Int
        get() = sp.getInt("orbX", Int.MIN_VALUE)
        set(v) { sp.edit().putInt("orbX", v).apply() }

    var orbY: Int
        get() = sp.getInt("orbY", Int.MIN_VALUE)
        set(v) { sp.edit().putInt("orbY", v).apply() }

    var longPressMs: Long
        get() = sp.getLong("longPressMs", 500L)
        set(v) { sp.edit().putLong("longPressMs", v.coerceIn(250L, 1500L)).apply() }

    var silenceSec: Int
        get() = sp.getInt("silenceSec", 10)
        set(v) { sp.edit().putInt("silenceSec", v).apply() }

    var lang: String
        get() = sp.getString("lang", "hi-IN") ?: "hi-IN"
        set(v) { sp.edit().putString("lang", v).apply() }

    var reducedMotion: Boolean
        get() = sp.getBoolean("reducedMotion", false)
        set(v) { sp.edit().putBoolean("reducedMotion", v).apply() }

    var sleepyEnabled: Boolean
        get() = sp.getBoolean("sleepyEnabled", false)
        set(v) { sp.edit().putBoolean("sleepyEnabled", v).apply() }

    var overlayEnabled: Boolean
        get() = sp.getBoolean("overlayEnabled", false)
        set(v) { sp.edit().putBoolean("overlayEnabled", v).apply() }

    var speakReplies: Boolean
        get() = sp.getBoolean("speakReplies", true)
        set(v) { sp.edit().putBoolean("speakReplies", v).apply() }

    var securityEnabled: Boolean
        get() = sp.getBoolean("securityEnabled", false)
        set(v) { sp.edit().putBoolean("securityEnabled", v).apply() }

    var verifyOnUnlock: Boolean
        get() = sp.getBoolean("verifyOnUnlock", false)
        set(v) { sp.edit().putBoolean("verifyOnUnlock", v).apply() }

    var failThreshold: Int
        get() = sp.getInt("failThreshold", 5)
        set(v) { sp.edit().putInt("failThreshold", v.coerceIn(3, 10)).apply() }

    var graceMinutes: Int
        get() = sp.getInt("graceMinutes", 2)
        set(v) { sp.edit().putInt("graceMinutes", v.coerceIn(0, 30)).apply() }

    var verifiedUntil: Long
        get() = sp.getLong("verifiedUntil", 0L)
        set(v) { sp.edit().putLong("verifiedUntil", v).apply() }

    var selectedApps: Set<String>
        get() = sp.getStringSet("selectedApps", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("selectedApps", HashSet(v)).apply() }

    var pinFailCount: Int
        get() = sp.getInt("pinFailCount", 0)
        set(v) { sp.edit().putInt("pinFailCount", v).apply() }

    var pinLockedUntil: Long
        get() = sp.getLong("pinLockedUntil", 0L)
        set(v) { sp.edit().putLong("pinLockedUntil", v).apply() }

    var pinBlob: String?
        get() = sp.getString("pinBlob", null)
        set(v) { sp.edit().putString("pinBlob", v).apply() }

    var stopwatchStart: Long
        get() = sp.getLong("stopwatchStart", 0L)
        set(v) { sp.edit().putLong("stopwatchStart", v).apply() }
}
