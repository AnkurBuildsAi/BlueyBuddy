package com.orbo.assistant.orb

enum class EyeStyle { OPEN, FOCUSED, HAPPY, CONFUSED, SLEEPY, SERIOUS, CURIOUS, SIDE }

enum class MouthStyle { NEUTRAL, SMILE, SURPRISED, THINKING }

data class OrbFace(val eyes: EyeStyle, val mouth: MouthStyle)

/** State -> expression mapping (spec section 6). */
fun OrbState.toFace(): OrbFace = when (this) {
    OrbState.IDLE -> OrbFace(EyeStyle.OPEN, MouthStyle.NEUTRAL)
    OrbState.UNLOCK_WELCOME -> OrbFace(EyeStyle.HAPPY, MouthStyle.SMILE)
    OrbState.LISTENING -> OrbFace(EyeStyle.CURIOUS, MouthStyle.NEUTRAL)
    OrbState.THINKING -> OrbFace(EyeStyle.SIDE, MouthStyle.THINKING)
    OrbState.EXECUTING -> OrbFace(EyeStyle.FOCUSED, MouthStyle.NEUTRAL)
    OrbState.WAITING -> OrbFace(EyeStyle.OPEN, MouthStyle.NEUTRAL)
    OrbState.COMPLETED -> OrbFace(EyeStyle.HAPPY, MouthStyle.SMILE)
    OrbState.SEARCH_FOUND -> OrbFace(EyeStyle.CURIOUS, MouthStyle.SURPRISED)
    OrbState.ERROR -> OrbFace(EyeStyle.CONFUSED, MouthStyle.THINKING)
    OrbState.VERIFICATION_PENDING -> OrbFace(EyeStyle.SERIOUS, MouthStyle.NEUTRAL)
    OrbState.FACE_FAILED -> OrbFace(EyeStyle.CONFUSED, MouthStyle.NEUTRAL)
    OrbState.VERIFIED -> OrbFace(EyeStyle.HAPPY, MouthStyle.SMILE)
    OrbState.SECURITY_REQUIRED -> OrbFace(EyeStyle.SERIOUS, MouthStyle.NEUTRAL)
    OrbState.SLEEPY -> OrbFace(EyeStyle.SLEEPY, MouthStyle.NEUTRAL)
}
