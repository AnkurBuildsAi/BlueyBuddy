package com.orbo.assistant

import android.app.Application
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.core.Skills

class OrboApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Orbo.init(this)
        Skills.seedIfEmpty()
    }
}
