package com.orbo.assistant.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.core.Stores
import com.orbo.assistant.security.BiometricHelper
import com.orbo.assistant.security.FaceVerifier
import com.orbo.assistant.security.PinManager
import com.orbo.assistant.security.PinResult
import com.orbo.assistant.security.SecurityActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SecurityTab(tick: Int, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val p = Orbo.prefs
    var rev by remember { mutableIntStateOf(0) }
    var pinSet by remember(rev, tick) { mutableStateOf(PinManager.isSet()) }
    var secOn by remember(rev, tick) { mutableStateOf(p.securityEnabled) }
    var unlockOn by remember(rev, tick) { mutableStateOf(p.verifyOnUnlock) }
    var threshold by remember(rev) { mutableStateOf(p.failThreshold.toFloat()) }
    var grace by remember(rev) { mutableStateOf(p.graceMinutes.toFloat()) }
    var dialog by remember { mutableStateOf<String?>(null) } // "set" | "remove"
    val bio = remember(tick) { BiometricHelper.availability(ctx) }
    val events = remember(rev) { Stores.securityEvents.read().takeLast(20).reversed() }
    val fmt = remember { SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault()) }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Security", style = MaterialTheme.typography.headlineSmall)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("ORBO PIN: ${if (pinSet) "SET" else "NOT SET"}", style = MaterialTheme.typography.titleMedium)
                Text("PIN salted PBKDF2 verifier ke roop mein, Android Keystore se encrypt hoke store hota hai. Plaintext kabhi save nahi.", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { dialog = "set" }) { Text(if (pinSet) "PIN badlo" else "PIN set karo") }
                    if (pinSet) OutlinedButton(onClick = { dialog = "remove" }) { Text("PIN hatao") }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Verification methods", style = MaterialTheme.typography.titleMedium)
                Text("1. Device Biometric: ${bio.second}", style = MaterialTheme.typography.bodySmall)
                Text("2. Face: NOT AVAILABLE. ${FaceVerifier.UNAVAILABLE_REASON}", style = MaterialTheme.typography.bodySmall)
                Text("3. ORBO PIN: ${if (pinSet) "ready" else "pehle PIN set karo"}", style = MaterialTheme.typography.bodySmall)
                OutlinedButton(enabled = pinSet, onClick = { SecurityActivity.launch(ctx, null) }) { Text("Security Page kholo (test)") }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Selected-app protection", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    Switch(checked = secOn, enabled = pinSet, onCheckedChange = { p.securityEnabled = it; secOn = it })
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Unlock ke baad verification maango", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    Switch(checked = unlockOn, enabled = pinSet, onCheckedChange = { p.verifyOnUnlock = it; unlockOn = it })
                }
                Text("Galat PIN limit: ${threshold.toInt()} (sirf ORBO ke apne PIN page ke attempts gine jaate hain)", style = MaterialTheme.typography.bodySmall)
                Slider(value = threshold, onValueChange = { threshold = it }, valueRange = 3f..10f, steps = 6,
                    onValueChangeFinished = { p.failThreshold = threshold.toInt() })
                Text("Verify ke baad grace: ${grace.toInt()} minute", style = MaterialTheme.typography.bodySmall)
                Slider(value = grace, onValueChange = { grace = it }, valueRange = 0f..30f, steps = 29,
                    onValueChangeFinished = { p.graceMinutes = grace.toInt() })
                Text("Camera se security photo: NAHI (build mein shaamil nahi; kabhi chhup kar camera on nahi hota).", style = MaterialTheme.typography.bodySmall)
            }
        }

        Text("Protected apps chuno", style = MaterialTheme.typography.titleMedium)
        Text(
            "Honest note: normal Android app arbitrary apps ko unbreakable lock nahi kar sakti. ORBO Accessibility se dekhta hai " +
                "ki selected app foreground mein aaya, aur tab Security Page upar dikhata hai. Ye best-effort hai aur bypass ho sakta hai.",
            style = MaterialTheme.typography.bodySmall,
        )
        SelectedAppsSection(editable = true)

        Text("Security events", style = MaterialTheme.typography.titleMedium)
        if (events.isEmpty()) Text("Koi event nahi.", style = MaterialTheme.typography.bodySmall)
        events.forEach {
            Text("${fmt.format(Date(it.optLong("at")))}  ${it.optString("type")}: ${it.optString("note")}", style = MaterialTheme.typography.bodySmall)
        }
        OutlinedButton(onClick = { Stores.securityEvents.clear(); rev++ }, enabled = events.isNotEmpty()) { Text("Events clear karo") }
    }

    when (dialog) {
        "set" -> PinDialog(requireCurrent = pinSet, title = if (pinSet) "PIN badlo" else "PIN set karo", onDone = { dialog = null; rev++ })
        "remove" -> PinDialog(requireCurrent = true, title = "PIN hatao", removeMode = true, onDone = { dialog = null; rev++ })
    }
}

@Composable
private fun PinDialog(requireCurrent: Boolean, title: String, removeMode: Boolean = false, onDone: () -> Unit) {
    var cur by remember { mutableStateOf("") }
    var n1 by remember { mutableStateOf("") }
    var n2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }

    @Composable
    fun field(v: String, label: String, set: (String) -> Unit) {
        OutlinedTextField(
            value = v, onValueChange = { if (it.length <= 12 && it.all { c -> c.isDigit() }) set(it) },
            label = { Text(label) }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        )
    }

    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (requireCurrent) field(cur, "Abhi ka PIN") { cur = it }
                if (!removeMode) {
                    Text("Naya PIN: kam se kam 6 digits.", style = MaterialTheme.typography.bodySmall)
                    field(n1, "Naya PIN") { n1 = it }
                    field(n2, "PIN dobara") { n2 = it }
                }
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (requireCurrent) {
                    when (val r = PinManager.verify(cur)) {
                        PinResult.Success -> {}
                        is PinResult.Wrong -> { err = "Abhi ka PIN galat (${r.failCount}/${r.threshold})."; return@TextButton }
                        is PinResult.Locked -> { err = "Lockout chal raha hai, thodi der baad try karo."; return@TextButton }
                        PinResult.NotSet -> {}
                        is PinResult.Error -> { err = r.msg; return@TextButton }
                    }
                }
                if (removeMode) {
                    PinManager.removePin()
                    onDone()
                    return@TextButton
                }
                if (n1 != n2) { err = "Dono PIN same nahi hain."; return@TextButton }
                val e = PinManager.setPin(n1)
                if (e == null) onDone() else err = e
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDone) { Text("Cancel") } },
    )
}
