package com.orbo.assistant.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.orbo.assistant.orb.EyeStyle
import com.orbo.assistant.orb.MouthStyle
import com.orbo.assistant.orb.OrbState
import com.orbo.assistant.orb.OrbTimings
import com.orbo.assistant.orb.toFace
import com.orbo.assistant.ui.theme.OrbBlue
import com.orbo.assistant.ui.theme.OrbViolet
import kotlinx.coroutines.delay
import kotlin.random.Random

private data class EyeShape(val w: Float, val h: Float, val dx: Float = 0f)

/** Har eye ka (width, height) body radius ke fraction mein. */
private fun eyeShapes(style: EyeStyle): Pair<EyeShape, EyeShape> = when (style) {
    EyeStyle.OPEN -> EyeShape(0.20f, 0.30f).let { it to it }
    EyeStyle.FOCUSED -> EyeShape(0.22f, 0.18f).let { it to it }
    EyeStyle.CURIOUS -> EyeShape(0.24f, 0.36f).let { it to it }
    EyeStyle.SLEEPY -> EyeShape(0.22f, 0.08f).let { it to it }
    EyeStyle.SERIOUS -> EyeShape(0.24f, 0.16f).let { it to it }
    EyeStyle.CONFUSED -> EyeShape(0.20f, 0.36f) to EyeShape(0.20f, 0.18f)
    EyeStyle.SIDE -> EyeShape(0.20f, 0.30f, dx = 0.12f).let { it to it }
    EyeStyle.HAPPY -> EyeShape(0.22f, 0.20f).let { it to it } // arc ke roop mein draw hota hai
}

/**
 * Orb ka Canvas drawing. Idle mein sirf kabhi-kabhi blink hota hai;
 * glow pulse sirf LISTENING / THINKING / EXECUTING mein chalta hai.
 * reducedMotion = true par blink aur pulse dono band.
 */
@Composable
fun OrbView(
    state: OrbState,
    modifier: Modifier = Modifier,
    orbSize: Dp = 68.dp,
    reducedMotion: Boolean = false,
) {
    val face = remember(state) { state.toFace() }
    val blink = remember { Animatable(1f) }

    LaunchedEffect(state, reducedMotion) {
        blink.snapTo(1f)
        if (reducedMotion) return@LaunchedEffect
        val sleepy = state == OrbState.SLEEPY
        val minGap = if (sleepy) 6000L else 2500L
        val maxGap = if (sleepy) 9000L else 5000L
        val blinkMs = if (sleepy) OrbTimings.BLINK_MS * 3 else OrbTimings.BLINK_MS
        while (true) {
            delay(Random.nextLong(minGap, maxGap))
            blink.animateTo(0.1f, tween(blinkMs / 2))
            blink.animateTo(1f, tween(blinkMs / 2))
        }
    }

    val pulsing = !reducedMotion &&
        (state == OrbState.LISTENING || state == OrbState.THINKING || state == OrbState.EXECUTING)
    val pulse: Float = if (pulsing) {
        val transition = rememberInfiniteTransition(label = "orbPulse")
        transition.animateFloat(
            initialValue = 0.80f,
            targetValue = 1.0f,
            animationSpec = infiniteRepeatable(
                animation = tween(900, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse,
            ),
            label = "pulseValue",
        ).value
    } else {
        1f
    }

    Canvas(modifier = modifier.size(orbSize)) {
        val outerR = this.size.minDimension / 2f
        val bodyR = outerR * 0.78f
        val c = center

        // Blue glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(OrbBlue.copy(alpha = 0.50f * pulse), Color.Transparent),
                center = c,
                radius = outerR,
            ),
            radius = outerR,
            center = c,
        )
        // Violet secondary glow
        val vCenter = c + Offset(bodyR * 0.35f, bodyR * 0.45f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(OrbViolet.copy(alpha = 0.40f * pulse), Color.Transparent),
                center = vCenter,
                radius = outerR * 0.8f,
            ),
            radius = outerR * 0.8f,
            center = vCenter,
        )
        // Glass body
        val bCenter = c - Offset(bodyR * 0.3f, bodyR * 0.35f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF6FC4FF), Color(0xFF2B5BE0), Color(0xFF3B1E8C)),
                center = bCenter,
                radius = bodyR * 1.8f,
            ),
            radius = bodyR,
            center = c,
        )
        // Reflection
        drawOval(
            color = Color.White.copy(alpha = 0.30f),
            topLeft = Offset(c.x - bodyR * 0.5f, c.y - bodyR * 0.85f),
            size = Size(bodyR * 0.9f, bodyR * 0.38f),
        )

        // Eyes
        val eyeY = c.y - bodyR * 0.10f
        val eyeGap = bodyR * 0.36f
        val (left, right) = eyeShapes(face.eyes)
        val strokeW = bodyR * 0.07f

        fun drawEye(cx: Float, shape: EyeShape) {
            val x = cx + shape.dx * bodyR
            if (face.eyes == EyeStyle.HAPPY) {
                val w = shape.w * bodyR
                val h = shape.h * bodyR
                drawArc(
                    color = Color.White,
                    startAngle = 200f,
                    sweepAngle = 140f,
                    useCenter = false,
                    topLeft = Offset(x - w, eyeY - h * 0.5f),
                    size = Size(w * 2f, h * 1.6f),
                    style = Stroke(width = strokeW, cap = StrokeCap.Round),
                )
            } else {
                val w = shape.w * bodyR
                val h = shape.h * bodyR * blink.value
                drawOval(
                    color = Color.White,
                    topLeft = Offset(x - w / 2f, eyeY - h / 2f),
                    size = Size(w, h),
                )
            }
        }
        drawEye(c.x - eyeGap, left)
        drawEye(c.x + eyeGap, right)

        // Mouth
        val mouthY = c.y + bodyR * 0.38f
        val mw = bodyR * 0.30f
        val mouthStroke = Stroke(width = bodyR * 0.06f, cap = StrokeCap.Round)
        when (face.mouth) {
            MouthStyle.NEUTRAL -> drawLine(
                color = Color.White,
                start = Offset(c.x - mw / 2f, mouthY),
                end = Offset(c.x + mw / 2f, mouthY),
                strokeWidth = mouthStroke.width,
                cap = StrokeCap.Round,
            )
            MouthStyle.SMILE -> drawArc(
                color = Color.White,
                startAngle = 20f,
                sweepAngle = 140f,
                useCenter = false,
                topLeft = Offset(c.x - mw, mouthY - mw * 0.6f),
                size = Size(mw * 2f, mw * 1.2f),
                style = mouthStroke,
            )
            MouthStyle.SURPRISED -> drawOval(
                color = Color.White,
                topLeft = Offset(c.x - mw * 0.25f, mouthY - mw * 0.3f),
                size = Size(mw * 0.5f, mw * 0.6f),
            )
            MouthStyle.THINKING -> drawLine(
                color = Color.White,
                start = Offset(c.x - mw * 0.4f, mouthY),
                end = Offset(c.x + mw * 0.6f, mouthY - mw * 0.15f),
                strokeWidth = mouthStroke.width,
                cap = StrokeCap.Round,
            )
        }
    }
}
