package com.orbo.assistant.agent

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.orbo.assistant.command.Cmd
import com.orbo.assistant.command.CommandParser
import com.orbo.assistant.core.NetworkUtil
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.core.Skills
import com.orbo.assistant.core.Stores
import com.orbo.assistant.orb.OrbState
import com.orbo.assistant.phone.AppMatcher
import com.orbo.assistant.phone.OrboAccessibilityService
import com.orbo.assistant.phone.PhoneActions
import com.orbo.assistant.phone.TextSummarizer
import com.orbo.assistant.timer.TimerManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Har command ka asli execution + verification. Success tabhi bolta hai jab verify ho ya limitation saaf bataya ho. */
object Executor {

    private const val NEED_A11Y = "Accessibility service band hai. Home tab ke 'Accessibility' card se ON karo."
    private const val NO_TEXT = "Is screen ka text accessibility se padha nahi ja sakta (secure/protected ya custom screen ho sakti hai)."

    private fun fail(m: String) = Res(false, m, m)
    private fun a11y(): OrboAccessibilityService? = OrboAccessibilityService.instance

    fun retryable(c: Cmd): Boolean =
        c is Cmd.Back || c is Cmd.Home || c is Cmd.Recents || c is Cmd.ScrollDown || c is Cmd.ScrollUp ||
            c is Cmd.ClickText || c is Cmd.OpenResult

    suspend fun run(c: Cmd): Res = when (c) {
        is Cmd.OpenApp -> openApp(c.query)
        Cmd.Back -> global("Back") { it.back() }
        Cmd.Home -> global("Home") { it.home() }
        Cmd.Recents -> global("Recents") { it.recents() }
        Cmd.ScrollDown -> scroll(true)
        Cmd.ScrollUp -> scroll(false)
        Cmd.Time -> {
            val t = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            Res(true, "Abhi samay $t hai.", "Abhi samay $t hai")
        }
        is Cmd.TimerSet -> timerSet(c)
        Cmd.TimerCancel -> {
            val n = TimerManager.cancelAll()
            if (n == 0) fail("Koi active timer nahi mila.") else Res(true, "$n timer cancel kar diye.", "Timer cancel ho gaya")
        }
        Cmd.TimerPause -> {
            val n = TimerManager.pauseAll()
            if (n == 0) fail("Koi running timer nahi mila.") else Res(true, "$n timer pause kiye.")
        }
        Cmd.TimerResume -> {
            val n = TimerManager.resumeAll()
            if (n == 0) fail("Koi paused timer nahi mila.") else Res(true, "$n timer resume kiye.")
        }
        is Cmd.Stopwatch -> stopwatch(c.start)
        Cmd.Stop, Cmd.Cancel -> Res(true, "Stop")
        Cmd.Pause -> if (Assistant.speaker.pause()) Res(true, "Reading pause.") else fail("Abhi kuch padh nahi raha.")
        Cmd.Resume -> if (Assistant.speaker.resume()) Res(true, "Reading resume.") else fail("Resume karne ko kuch nahi.")
        Cmd.ReadAloud -> readAloud()
        Cmd.ExplainScreen -> explainScreen()
        Cmd.ExplainError -> explainError()
        Cmd.Summarize -> summarize()
        Cmd.Copy -> copy()
        Cmd.Paste -> paste()
        is Cmd.Search -> search(c)
        is Cmd.OpenResult -> openResult(c.n)
        is Cmd.OpenSettings -> openSettings(c.page)
        is Cmd.DraftMessage -> draft(c)
        is Cmd.TypeText -> typeText(c.text)
        is Cmd.ClickText -> clickText(c.text)
        is Cmd.Remember -> remember(c.text)
        is Cmd.RunSkill -> runSkill(c.name)
        is Cmd.Compound -> runSteps(c.steps)
        is Cmd.Unknown -> fail(c.hint)
    }

    private suspend fun runSteps(steps: List<Cmd>): Res {
        val lines = mutableListOf<String>()
        for ((i, s) in steps.withIndex()) {
            val r = run(s)
            lines.add("${i + 1}. ${if (r.ok) "OK" else "FAIL"}: ${r.message}")
            if (!r.ok) return Res(false, lines.joinToString("\n"))
        }
        return Res(true, lines.joinToString("\n"), "Skill poori hui")
    }

    private suspend fun runSkill(name: String): Res {
        val q = name.lowercase().trim()
        val skill = Skills.all().firstOrNull { it.enabled && it.name.lowercase().contains(q) && q.isNotBlank() }
            ?: return fail("'$name' naam ki enabled skill nahi mili.")
        return runSteps(skill.steps.map { CommandParser.parse(it) })
    }

    // ---------- apps ----------
    private suspend fun openApp(query: String): Res {
        val apps = PhoneActions.launchableApps()
        val matches = AppMatcher.match(query, apps)
        if (matches.isEmpty()) return fail("'$query' naam ka koi app installed nahi mila.")
        val target = if (matches.size == 1 || matches[0].score > matches[1].score) {
            matches[0].app
        } else {
            val opts = matches.take(3).map { Pair(it.app.label, it.app.pkg) }
            val pkg = Assistant.choose("Kaunsa app kholun?", opts) ?: return Res(true, "Cancel kar diya.")
            apps.first { it.pkg == pkg }
        }
        val intent = PhoneActions.launchIntentFor(target.pkg) ?: return fail("${target.label} ka launch intent nahi mila.")
        try {
            Orbo.app.startActivity(intent)
        } catch (e: Exception) {
            return fail("${target.label} launch nahi ho paya: ${e.message}")
        }
        return verifyForeground(target.pkg, "${target.label} khul gaya.", "${target.label} ki launch request bheji gayi, par Accessibility off hone se confirm nahi kar sakta.")
    }

    private suspend fun verifyForeground(pkg: String, okMsg: String, unverifiedMsg: String): Res {
        if (a11y() == null) return Res(true, unverifiedMsg)
        val got = withTimeoutOrNull(4000) { OrboAccessibilityService.foreground.first { it == pkg } }
        return if (got != null) Res(true, okMsg, okMsg) else fail("Launch request gayi par app foreground mein nahi aaya (4 sec).")
    }

    private suspend fun openSettings(page: String): Res {
        val i = PhoneActions.settingsIntent(page)
        val pkg = PhoneActions.resolvedPackage(i) ?: return fail("Is phone par ye Settings page nahi mila.")
        try {
            Orbo.app.startActivity(i)
        } catch (e: Exception) {
            return fail("Settings nahi khuli: ${e.message}")
        }
        return verifyForeground(pkg, "Settings page khul gaya.", "Settings ki request bheji gayi (Accessibility off, confirm nahi).")
    }

    // ---------- navigation ----------
    private fun global(name: String, f: (OrboAccessibilityService) -> Boolean): Res {
        val s = a11y() ?: return fail(NEED_A11Y)
        return if (f(s)) Res(true, "$name action Android ne accept kiya.") else fail("$name action fail hua.")
    }

    private suspend fun scroll(down: Boolean): Res {
        val s = a11y() ?: return fail(NEED_A11Y)
        val before = s.textHash()
        var ok = s.scroll(down)
        if (!ok) ok = s.swipe(down)
        if (!ok) return fail("Scroll nahi ho paya: yahan koi scrollable cheez nahi mili ya screen protected hai.")
        delay(500)
        return if (s.textHash() != before) Res(true, "Scroll ho gaya (screen badli).")
        else fail("Scroll request chali par screen nahi badli (page ka end ho sakta hai).")
    }

    // ---------- timers ----------
    private fun timerSet(c: Cmd.TimerSet): Res {
        val t = TimerManager.start(c.seconds, c.label)
        if (!TimerManager.isScheduled(t.id)) return fail("Timer save hua par alarm schedule nahi hua.")
        val dl = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(t.deadline))
        val note = if (TimerManager.usesExactAlarm()) "" else " (Exact alarm permission nahi hai, isliye alarm thoda late ho sakta hai.)"
        val msg = "${TimerManager.format(c.seconds * 1000)} ka timer laga diya. Deadline $dl.$note"
        return Res(true, msg, "Timer laga diya")
    }

    private fun stopwatch(start: Boolean): Res {
        val p = Orbo.prefs
        return if (start) {
            p.stopwatchStart = System.currentTimeMillis()
            Res(true, "Stopwatch chalu.", "Stopwatch chalu")
        } else {
            val st = p.stopwatchStart
            if (st == 0L) return fail("Stopwatch chal hi nahi raha tha.")
            p.stopwatchStart = 0L
            val el = TimerManager.format(System.currentTimeMillis() - st)
            Res(true, "Stopwatch band. Elapsed $el.", "Stopwatch band. $el")
        }
    }

    // ---------- screen ----------
    private fun readScreen(): Pair<String?, Res?> {
        val s = a11y() ?: return Pair(null, fail(NEED_A11Y))
        val t = s.visibleText()
        if (t.isBlank()) return Pair(null, fail(NO_TEXT))
        return Pair(t, null)
    }

    private fun readAloud(): Res {
        val (t, err) = readScreen()
        if (t == null) return err!!
        return Res(true, "Screen ka text padh raha hoon (${t.length} characters).", t.take(6000))
    }

    private fun explainScreen(): Res {
        val (t, err) = readScreen()
        if (t == null) return err!!
        val sum = TextSummarizer.summarize(t, 3)
        val hint = TextSummarizer.explainError(t)
        val msg = "Screen par ye likha hai:\n$sum" + (if (hint != null) "\n\nSamajh: $hint" else "")
        return Res(true, msg, (sum + (hint?.let { ". $it" } ?: "")).take(1500))
    }

    private fun explainError(): Res {
        val (t, err) = readScreen()
        if (t == null) return err!!
        val hint = TextSummarizer.explainError(t)
            ?: return Res(true, "Screen par koi jana-pehchana error text nahi mila.", "Koi pehchana hua error nahi mila")
        return Res(true, hint, hint)
    }

    private fun summarize(): Res {
        val (t, err) = readScreen()
        if (t == null) return err!!
        val sum = TextSummarizer.summarize(t, 3)
        return Res(true, "Summary (rule-based, AI nahi):\n$sum", sum.take(1500))
    }

    private fun copy(): Res {
        val s = a11y() ?: return fail(NEED_A11Y)
        if (s.copySelection()) return Res(true, "Selected text copy karne ka action Android ne accept kiya.")
        val t = s.visibleText()
        if (t.isBlank()) return fail(NO_TEXT)
        val cm = Orbo.app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("ORBO", t))
        return Res(true, "Selection nahi mila, isliye screen ka visible text copy kiya (${t.length} characters). Clipboard verify Android restriction ki wajah se nahi ho sakta.")
    }

    private fun paste(): Res {
        val s = a11y() ?: return fail(NEED_A11Y)
        return if (s.pasteIntoFocused()) Res(true, "Paste action accept hua.") else fail("Paste nahi ho paya (koi text field focus mein nahi ya password field hai).")
    }

    private fun typeText(text: String): Res {
        val s = a11y() ?: return fail(NEED_A11Y)
        val err = s.typeText(text)
        return if (err == null) Res(true, "Text field mein likh diya (verify ho gaya).") else fail(err)
    }

    private suspend fun clickText(text: String): Res {
        val s = a11y() ?: return fail(NEED_A11Y)
        val before = s.textHash()
        if (!s.clickByText(text)) return fail("'$text' naam ka clickable element screen par nahi mila.")
        delay(1200)
        return if (s.textHash() != before) Res(true, "'$text' par click hua (screen badli).")
        else fail("Click request gayi par screen nahi badli (verify fail).")
    }

    // ---------- web ----------
    private suspend fun search(c: Cmd.Search): Res {
        if (!NetworkUtil.isOnline(Orbo.app)) {
            return fail("Internet nahi hai. Web search ke liye internet chahiye; baaki local commands offline chalte hain.")
        }
        val q = URLEncoder.encode(c.query, "UTF-8")
        val url = if (c.site == "youtube") "https://www.youtube.com/results?search_query=$q" else "https://www.google.com/search?q=$q"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pkg = PhoneActions.resolvedPackage(intent)
        try {
            Orbo.app.startActivity(intent)
        } catch (e: Exception) {
            return fail("Browser nahi khul paya: ${e.message}")
        }
        val s = a11y()
        if (s == null || pkg == null || pkg == "android") {
            return Res(true, "'${c.query}' ki search browser mein bheji gayi. Results verify nahi ho sake (Accessibility off).")
        }
        val got = withTimeoutOrNull(8000) { OrboAccessibilityService.foreground.first { it == pkg } }
            ?: return fail("Browser foreground mein nahi aaya.")
        delay(3000)
        val n = s.candidateLinks().size
        if (n > 0) {
            Orbo.force(OrbState.SEARCH_FOUND)
            return Res(true, "Search results khul gaye ($n result links dikhe).", "Results mil gaye")
        }
        return Res(true, "Browser khul gaya ($got) par results ke links accessibility se padh nahi paya.")
    }

    private suspend fun openResult(n: Int): Res {
        val s = a11y() ?: return fail(NEED_A11Y)
        val cands = s.candidateLinks()
        if (cands.isEmpty()) return fail("Result links accessibility se nahi mile (page abhi load ho raha ho sakta hai).")
        val i = (n - 1).coerceIn(0, cands.size - 1)
        val node = cands[i]
        val label = (node.text ?: node.contentDescription)?.toString().orEmpty().take(60)
        val before = s.textHash()
        if (!s.clickNode(node)) return fail("Result #${i + 1} click nahi ho paya.")
        delay(3000)
        return if (s.textHash() != before) Res(true, "Result #${i + 1} khul gaya: $label")
        else fail("Click ke baad page nahi badla (verify fail).")
    }

    // ---------- message / memory ----------
    private suspend fun draft(c: Cmd.DraftMessage): Res {
        var body = c.body
        if (body.isBlank()) {
            body = Assistant.ask("Message kya likhna hai? (bolo ya likho)") ?: return Res(true, "Draft cancel kar diya.")
        }
        val text = body.trim().replaceFirstChar { it.uppercase() }
        val ok = Assistant.confirm(
            "Message draft",
            "To: ${c.to ?: "(chooser mein select karna)"}\n\n$text",
            "Share chooser kholo", "Cancel",
        )
        if (!ok) return Res(true, "Draft cancel kar diya. Kuch bheja nahi gaya.")
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        val chooser = Intent.createChooser(send, "Message bhejo").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            Orbo.app.startActivity(chooser)
            Res(true, "Share chooser khul gaya. Bhejna aap khud karoge; ORBO message khud nahi bhejta.")
        } catch (e: Exception) {
            fail("Chooser nahi khul paya: ${e.message}")
        }
    }

    private suspend fun remember(text: String): Res {
        val sensitive = Regex("password|passcode|\\bpin\\b|otp|cvv|card number|aadhaar", RegexOption.IGNORE_CASE)
        if (sensitive.containsMatchIn(text)) return fail("Password/PIN/OTP jaisi sensitive cheezein main yaad nahi rakhta.")
        val ok = Assistant.confirm("Ye yaad rakhun?", text, "Haan, save karo", "Nahi")
        if (!ok) return Res(true, "Save nahi kiya.")
        val now = System.currentTimeMillis()
        Stores.memory.append(JSONObject().put("id", now).put("text", text).put("at", now))
        return Res(true, "Yaad rakh liya: $text", "Yaad rakh liya")
    }
}
