package com.orbo.assistant.core

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Chhota local JSON list store (history, skills, memory, security events, timers). */
class JsonListStore(private val file: File, private val max: Int) {

    @Synchronized
    fun read(): MutableList<JSONObject> {
        if (!file.exists()) return mutableListOf()
        return try {
            val arr = JSONArray(file.readText())
            val out = mutableListOf<JSONObject>()
            for (i in 0 until arr.length()) out.add(arr.getJSONObject(i))
            out
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    @Synchronized
    fun write(list: List<JSONObject>) {
        val arr = JSONArray()
        list.takeLast(max).forEach { arr.put(it) }
        file.writeText(arr.toString())
    }

    @Synchronized
    fun append(o: JSONObject) {
        val l = read()
        l.add(o)
        write(l)
    }

    @Synchronized
    fun clear() {
        file.delete()
    }
}

object Stores {
    val history: JsonListStore by lazy { JsonListStore(File(Orbo.app.filesDir, "history.json"), 100) }
    val skills: JsonListStore by lazy { JsonListStore(File(Orbo.app.filesDir, "skills.json"), 100) }
    val memory: JsonListStore by lazy { JsonListStore(File(Orbo.app.filesDir, "memory.json"), 200) }
    val securityEvents: JsonListStore by lazy { JsonListStore(File(Orbo.app.filesDir, "security_events.json"), 200) }
    val timers: JsonListStore by lazy { JsonListStore(File(Orbo.app.filesDir, "timers.json"), 50) }
}

class Skill(val id: Long, var name: String, var steps: List<String>, var enabled: Boolean)

object Skills {
    fun all(): List<Skill> = Stores.skills.read().map {
        val arr = it.optJSONArray("steps") ?: JSONArray()
        val steps = mutableListOf<String>()
        for (i in 0 until arr.length()) steps.add(arr.getString(i))
        Skill(it.optLong("id"), it.optString("name"), steps, it.optBoolean("enabled", true))
    }

    fun saveAll(list: List<Skill>) {
        Stores.skills.write(list.map {
            JSONObject().put("id", it.id).put("name", it.name)
                .put("steps", JSONArray(it.steps)).put("enabled", it.enabled)
        })
    }

    fun seedIfEmpty() {
        try {
            if (Stores.skills.read().isEmpty()) {
                saveAll(
                    listOf(
                        Skill(1, "Study Start", listOf("25 minute ka timer lagao"), true),
                        Skill(2, "Read This Page", listOf("is page ko padho"), true),
                    ),
                )
            }
        } catch (e: Exception) {
            // storage error: app crash nahi hona chahiye
        }
    }
}
