package com.orbo.assistant.overlay

import android.animation.ValueAnimator
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.orbo.assistant.MainActivity
import com.orbo.assistant.R
import com.orbo.assistant.agent.Assistant
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.core.PillKind
import com.orbo.assistant.core.PillAction
import com.orbo.assistant.core.PillStatus
import com.orbo.assistant.orb.OrbState
import com.orbo.assistant.orb.OrbTimings
import com.orbo.assistant.security.PinManager
import com.orbo.assistant.security.SecurityActivity
import com.orbo.assistant.timer.Notifier
import com.orbo.assistant.timer.TimerManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Floating Orb + Smart Pill (WindowManager overlay, plain Views).
 * Gestures: tap (ripple+bounce), long press (Pill + listening), drag, swipe-up (Peek), swipe-down/tap (restore).
 */
class OrbOverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.orbo.assistant.STOP_OVERLAY"
        private const val NOTIF_ID = 1001

        fun start(ctx: Context) {
            Orbo.prefs.overlayEnabled = true
            ContextCompat.startForegroundService(ctx, Intent(ctx, OrbOverlayService::class.java))
        }

        fun stop(ctx: Context) {
            Orbo.prefs.overlayEnabled = false
            ctx.stopService(Intent(ctx, OrbOverlayService::class.java))
        }
    }

    private class MaxHeightScroll(c: Context, private val maxH: Int) : ScrollView(c) {
        override fun onMeasure(w: Int, h: Int) {
            super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST))
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var root: LinearLayout
    private lateinit var header: LinearLayout
    private lateinit var headerLp: LinearLayout.LayoutParams
    private lateinit var orbLp: LinearLayout.LayoutParams
    private lateinit var orb: OrbCanvasView
    private lateinit var status: TextView
    private lateinit var mic: TextView
    private lateinit var arrow: TextView
    private lateinit var body: LinearLayout
    private lateinit var detail: TextView
    private lateinit var actionsRow: LinearLayout
    private lateinit var input: EditText
    private lateinit var bg: GradientDrawable

    private var built = false
    private var orbPx = 0
    private var pillMode = false
    private var expanded = false
    private var peek = false
    private var lastKind = PillKind.IDLE
    private var hasActions = false

    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var morphAnim: ValueAnimator? = null

    // gesture state
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false
    private var longFired = false
    private var vt: VelocityTracker? = null
    private val longTask = Runnable {
        if (!moved) {
            longFired = true
            root.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            if (peek) restore()
            showPill(true)
            Assistant.startVoice()
        }
    }
    private val collapseTask = Runnable {
        if (!expanded && !hasActions && lastKind != PillKind.LISTENING && lastKind != PillKind.THINKING &&
            lastKind != PillKind.EXECUTING && lastKind != PillKind.VERIFICATION
        ) collapsePill()
    }
    private val sleepTask = Runnable {
        if (Orbo.prefs.sleepyEnabled && Orbo.machine.state.value == OrbState.IDLE) Orbo.force(OrbState.SLEEPY)
    }
    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            onUnlocked()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Orbo.prefs.overlayEnabled = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent == null && !Orbo.prefs.overlayEnabled) {
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        if (!Settings.canDrawOverlays(this)) {
            Orbo.prefs.overlayEnabled = false
            Orbo.say("Overlay permission chahiye", PillKind.ERROR, "Android Settings mein 'Display over other apps' allow karo.")
            stopSelf()
            return START_NOT_STICKY
        }
        if (!built) {
            try {
                build()
            } catch (e: Exception) {
                Orbo.prefs.overlayEnabled = false
                Orbo.say("Orb overlay nahi bana", PillKind.ERROR, e.message ?: "unknown error")
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun startFg() {
        Notifier.ensureChannels(this)
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, OrbOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val openPi = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(this, Notifier.CH_OVERLAY)
            .setSmallIcon(R.drawable.ic_stat_orbo)
            .setContentTitle("ORBO Orb chalu hai")
            .setContentText("Long-press = Pill + mic. Band karne ke liye tap karo.")
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(0, "Orb band karo", stopPi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------------- helpers ----------------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** [width, height, topInset, bottomInset] */
    private fun bounds(): IntArray {
        if (Build.VERSION.SDK_INT >= 30) {
            val m = wm.currentWindowMetrics
            val ins = m.windowInsets.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            return intArrayOf(m.bounds.width(), m.bounds.height(), ins.top, ins.bottom)
        }
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        val sb = if (id > 0) resources.getDimensionPixelSize(id) else dp(24)
        return intArrayOf(dm.widthPixels, dm.heightPixels, sb, 0)
    }

    private fun applyParams() {
        try {
            if (root.isAttachedToWindow) wm.updateViewLayout(root, params)
        } catch (e: Exception) {
        }
    }

    private fun clampAndApply() {
        val b = bounds()
        val w = if (root.width > 0) root.width else orbPx
        val h = if (root.height > 0) root.height else orbPx
        params.x = params.x.coerceIn(0, max(0, b[0] - w))
        if (!peek) params.y = params.y.coerceIn(b[2], max(b[2], b[1] - b[3] - h))
        applyParams()
    }

    private fun chip(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.parseColor("#00121F"))
        textSize = 14f
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#2EA8FF"))
            cornerRadius = dp(16).toFloat()
        }
        setOnClickListener { onClick() }
    }

    private fun iconText(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 20f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(10), dp(10), dp(10))
        visibility = View.GONE
        setOnClickListener { onClick() }
    }

    // ---------------- build ----------------
    private fun build() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val p = Orbo.prefs
        orbPx = dp(p.orbSizeDp)

        bg = GradientDrawable().apply {
            setColor(Color.parseColor("#E60B1230"))
            cornerRadius = dp(32).toFloat()
            alpha = 0
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
        }
        header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        orb = OrbCanvasView(this).apply { reducedMotion = p.reducedMotion }
        orbLp = LinearLayout.LayoutParams(orbPx, orbPx)
        header.addView(orb, orbLp)

        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), 0, dp(4), 0)
            visibility = View.GONE
        }
        header.addView(status, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        mic = iconText("\uD83C\uDFA4") { Assistant.startVoice() }
        arrow = iconText("\u25BC") { toggleExpand() }
        header.addView(mic)
        header.addView(arrow)

        headerLp = LinearLayout.LayoutParams(orbPx, orbPx)
        root.addView(header, headerLp)

        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(12))
            visibility = View.GONE
        }
        val scroll = MaxHeightScroll(this, dp(200))
        detail = TextView(this).apply {
            setTextColor(Color.parseColor("#DDE6FF"))
            textSize = 14f
            setPadding(dp(4), dp(4), dp(4), dp(4))
            setTextIsSelectable(false)
        }
        scroll.addView(detail)
        body.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        actionsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val actionsScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(actionsRow)
        }
        body.addView(actionsScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })

        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "Command likho..."
            setHintTextColor(Color.parseColor("#8894B8"))
            setTextColor(Color.WHITE)
            textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            maxLines = 1
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    sendInput()
                    true
                } else false
            }
        }
        inputRow.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val send = chip("Send") { sendInput() }
        val stop = chip("Stop") { Assistant.stopAll("Stop kar diya") }
        inputRow.addView(send, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(6) })
        inputRow.addView(stop, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(6) })
        body.addView(inputRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        root.addView(body, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }
        val b = bounds()
        params.x = if (p.orbX != Int.MIN_VALUE) p.orbX else (b[0] - orbPx) / 2
        params.y = if (p.orbY != Int.MIN_VALUE) p.orbY else b[2] + dp(8)

        root.setOnTouchListener { _, ev -> onTouch(ev) }
        wm.addView(root, params)
        built = true
        root.post { clampAndApply() }

        ContextCompat.registerReceiver(this, unlockReceiver, IntentFilter(Intent.ACTION_USER_PRESENT), ContextCompat.RECEIVER_NOT_EXPORTED)

        scope.launch { Orbo.machine.state.collect { s ->
            orb.setOrbState(s)
            if (s != OrbState.SLEEPY) resetSleepTimer()
        } }
        scope.launch { Orbo.pill.collect { applyPill(it) } }
        scope.launch {
            while (isActive) {
                delay(1000)
                tickTimer()
            }
        }
        resetSleepTimer()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        morphAnim?.cancel()
        scope.cancel()
        try { unregisterReceiver(unlockReceiver) } catch (e: Exception) { }
        if (built) {
            try { wm.removeView(root) } catch (e: Exception) { }
            built = false
        }
        super.onDestroy()
    }

    // ---------------- pill content ----------------
    private fun applyPill(p: PillStatus) {
        if (!built) return
        lastKind = p.kind
        status.text = p.text
        detail.text = p.detail
        detail.visibility = if (p.detail.isBlank()) View.GONE else View.VISIBLE
        actionsRow.removeAllViews()
        hasActions = p.actions.isNotEmpty()
        for (a: PillAction in p.actions) {
            actionsRow.addView(chip(a.label) { a.run() }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(6) })
        }
        if (p.kind == PillKind.IDLE) return
        showPill(false)
        if (hasActions && !expanded) setExpanded(true)
        handler.removeCallbacks(collapseTask)
        handler.postDelayed(collapseTask, 8000)
    }

    private fun tickTimer() {
        if (!built || !pillMode || lastKind != PillKind.TIMER) return
        val t = TimerManager.active().firstOrNull() ?: return
        status.text = TimerManager.format(TimerManager.remainingMs(t)) + " remaining"
    }

    private fun sendInput() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        hideKeyboard()
        Assistant.submit(t)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(root.windowToken, 0)
    }

    // ---------------- morph / expand ----------------
    private fun showPill(@Suppress("UNUSED_PARAMETER") fromLong: Boolean) {
        if (peek) restore()
        if (pillMode) return
        val compress = !Orbo.prefs.reducedMotion
        if (compress) {
            root.animate().scaleX(0.9f).scaleY(0.9f).setDuration(100).withEndAction {
                root.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                morphTo(true)
            }.start()
        } else {
            morphTo(true)
        }
    }

    private fun collapsePill() {
        if (expanded) setExpanded(false)
        morphTo(false)
    }

    private fun morphTo(pill: Boolean) {
        if (pillMode == pill && morphAnim == null) return
        pillMode = pill
        morphAnim?.cancel()
        val b = bounds()
        val pillW = min((b[0] * 0.85f).toInt(), dp(360))
        val pillH = dp(60)
        val pillOrb = min(orbPx, dp(48))
        val fromW = headerLp.width
        val fromH = headerLp.height
        val fromO = orbLp.width
        val toW = if (pill) pillW else orbPx
        val toH = if (pill) pillH else orbPx
        val toO = if (pill) pillOrb else orbPx
        if (pill) {
            status.visibility = View.VISIBLE
            mic.visibility = View.VISIBLE
            arrow.visibility = View.VISIBLE
        }
        val dur = if (Orbo.prefs.reducedMotion) 0L else OrbTimings.MORPH_MS.toLong()
        val fromA = bg.alpha
        val toA = if (pill) 255 else 0
        morphAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = dur
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                headerLp.width = (fromW + (toW - fromW) * f).toInt()
                headerLp.height = (fromH + (toH - fromH) * f).toInt()
                orbLp.width = (fromO + (toO - fromO) * f).toInt()
                orbLp.height = orbLp.width
                header.layoutParams = headerLp
                orb.layoutParams = orbLp
                bg.alpha = (fromA + (toA - fromA) * f).toInt()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    morphAnim = null
                    if (!pill) {
                        status.visibility = View.GONE
                        mic.visibility = View.GONE
                        arrow.visibility = View.GONE
                    }
                    root.post { clampAndApply() }
                }
            })
            start()
        }
    }

    private fun toggleExpand() = setExpanded(!expanded)

    private fun setExpanded(v: Boolean) {
        expanded = v
        if (v) {
            body.visibility = View.VISIBLE
            body.alpha = 0f
            body.animate().alpha(1f).setDuration(180).start()
            arrow.text = "\u25B2"
            params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        } else {
            body.visibility = View.GONE
            arrow.text = "\u25BC"
            hideKeyboard()
            params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        applyParams()
        root.post { clampAndApply() }
    }

    // ---------------- peek / restore ----------------
    private fun enterPeek() {
        if (pillMode) collapsePill()
        peek = true
        params.x = startX
        params.y = -(orbPx * 0.6f).toInt()
        root.alpha = 0.5f
        applyParams()
    }

    private fun restore() {
        peek = false
        val b = bounds()
        params.y = if (Orbo.prefs.orbY != Int.MIN_VALUE) Orbo.prefs.orbY else b[2] + dp(8)
        root.alpha = 1f
        clampAndApply()
    }

    // ---------------- gestures ----------------
    private fun onTouch(ev: MotionEvent): Boolean {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX
                downY = ev.rawY
                startX = params.x
                startY = params.y
                moved = false
                longFired = false
                vt?.recycle()
                vt = VelocityTracker.obtain().also { it.addMovement(ev) }
                if (Orbo.machine.state.value == OrbState.SLEEPY) Orbo.force(OrbState.IDLE)
                resetSleepTimer()
                handler.postDelayed(longTask, Orbo.prefs.longPressMs)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(ev)
                val dx = ev.rawX - downX
                val dy = ev.rawY - downY
                if (!moved && hypot(dx, dy) > slop) {
                    moved = true
                    handler.removeCallbacks(longTask)
                }
                if (moved && !peek && !longFired) {
                    params.x = startX + dx.toInt()
                    params.y = startY + dy.toInt()
                    clampAndApply()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longTask)
                val tracker = vt
                tracker?.addMovement(ev)
                tracker?.computeCurrentVelocity(1000)
                val vx = tracker?.xVelocity ?: 0f
                val vy = tracker?.yVelocity ?: 0f
                tracker?.recycle()
                vt = null
                if (longFired) return true
                if (!moved) {
                    if (peek) restore() else if (!pillMode) orb.playTap()
                    return true
                }
                val dx = ev.rawX - downX
                val dy = ev.rawY - downY
                val vertical = abs(dy) > abs(dx) && abs(vy) > abs(vx) * 1.5f
                if (!peek && vertical && vy < -dp(900)) {
                    enterPeek()
                } else if (peek && vertical && vy > dp(600)) {
                    restore()
                } else if (!peek) {
                    Orbo.prefs.orbX = params.x
                    Orbo.prefs.orbY = params.y
                }
                return true
            }
        }
        return true
    }

    // ---------------- unlock / sleepy ----------------
    private fun onUnlocked() {
        if (!built) return
        peek = false
        root.alpha = 1f
        Orbo.force(OrbState.UNLOCK_WELCOME)
        playDrop()
        handler.postDelayed({
            val p = Orbo.prefs
            if (p.securityEnabled && p.verifyOnUnlock && PinManager.isSet()) {
                Orbo.force(OrbState.VERIFICATION_PENDING)
                Orbo.say(
                    "Verification Required", PillKind.VERIFICATION,
                    "Face / Device Biometric / PIN se verify karo.",
                    listOf(PillAction("Verify") { SecurityActivity.launch(this, null) }),
                )
            } else if (Orbo.machine.state.value == OrbState.UNLOCK_WELCOME) {
                Orbo.force(OrbState.IDLE)
            }
        }, 1500)
    }

    private fun playDrop() {
        if (Orbo.prefs.reducedMotion) return
        val target = if (Orbo.prefs.orbY != Int.MIN_VALUE) Orbo.prefs.orbY else bounds()[2] + dp(8)
        ValueAnimator.ofInt(-orbPx * 2, target).apply {
            duration = OrbTimings.DROP_MS.toLong()
            interpolator = OvershootInterpolator(1.4f)
            addUpdateListener {
                params.y = it.animatedValue as Int
                applyParams()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    orb.playSquash()
                }
            })
            start()
        }
    }

    private fun resetSleepTimer() {
        handler.removeCallbacks(sleepTask)
        if (Orbo.prefs.sleepyEnabled) handler.postDelayed(sleepTask, 60000)
    }
}
