package com.orbo.assistant.agent

import com.orbo.assistant.command.Cmd

enum class TaskState {
    CREATED, PLANNING, RUNNING, WAITING_FOR_USER, NEEDS_CONFIRMATION, RECOVERING, COMPLETED, FAILED, CANCELLED
}

enum class StepStatus { PENDING, RUNNING, OK, FAILED, SKIPPED }

class Step(val cmd: Cmd) {
    var status: StepStatus = StepStatus.PENDING
    var message: String = ""
}

class Task(val id: String, val command: String, val steps: List<Step>) {
    var state: TaskState = TaskState.CREATED
    var startedAt: Long = 0L
    var endedAt: Long = 0L
}

class Res(val ok: Boolean, val message: String, val speak: String? = null)
