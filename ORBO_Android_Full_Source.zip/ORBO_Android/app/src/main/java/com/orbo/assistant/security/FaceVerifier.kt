package com.orbo.assistant.security

/**
 * Face verification ABHI BLOCKED hai, jaanbujhkar:
 * - Face DETECTION identity verification nahi hoti.
 * - Matching ke liye on-device face-embedding model (.tflite) aur runtime chahiye; wo is build mein shaamil nahi hai
 *   (build ke time internet/model file available nahi tha).
 * - Liveness detection ke bina photo/screen se dhoka khaya ja sakta hai.
 * Isliye yahan kabhi "match" return nahi hota. Primary secure methods: Device Biometric + ORBO PIN.
 */
object FaceVerifier {
    const val UNAVAILABLE_REASON =
        "Face matching abhi available nahi: face-embedding model file aur on-device runtime is build mein nahi hain, " +
            "aur liveness (photo-spoof protection) bhi nahi hai. Device Biometric ya PIN use karo."

    fun isAvailable(): Boolean = false
}
