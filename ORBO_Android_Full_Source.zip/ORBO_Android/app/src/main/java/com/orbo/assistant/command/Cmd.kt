package com.orbo.assistant.command

/** Deterministic local commands. Koi AI/network nahi. */
sealed class Cmd {
    data class OpenApp(val query: String) : Cmd()
    object Back : Cmd()
    object Home : Cmd()
    object Recents : Cmd()
    object ScrollDown : Cmd()
    object ScrollUp : Cmd()
    object Time : Cmd()
    data class TimerSet(val seconds: Long, val label: String) : Cmd()
    object TimerCancel : Cmd()
    object TimerPause : Cmd()
    object TimerResume : Cmd()
    data class Stopwatch(val start: Boolean) : Cmd()
    object Stop : Cmd()
    object Cancel : Cmd()
    object Pause : Cmd()
    object Resume : Cmd()
    object ReadAloud : Cmd()
    object ExplainScreen : Cmd()
    object ExplainError : Cmd()
    object Summarize : Cmd()
    object Copy : Cmd()
    object Paste : Cmd()
    data class Search(val query: String, val site: String) : Cmd()
    data class OpenResult(val n: Int) : Cmd()
    data class OpenSettings(val page: String) : Cmd()
    data class DraftMessage(val to: String?, val body: String) : Cmd()
    data class TypeText(val text: String) : Cmd()
    data class ClickText(val text: String) : Cmd()
    data class Remember(val text: String) : Cmd()
    data class RunSkill(val name: String) : Cmd()
    data class Compound(val steps: List<Cmd>) : Cmd()
    data class Unknown(val raw: String, val hint: String) : Cmd()
}

fun Cmd.describe(): String = when (this) {
    is Cmd.OpenApp -> "App kholo: $query"
    Cmd.Back -> "Back jao"
    Cmd.Home -> "Home screen par jao"
    Cmd.Recents -> "Recent apps kholo"
    Cmd.ScrollDown -> "Neeche scroll karo"
    Cmd.ScrollUp -> "Upar scroll karo"
    Cmd.Time -> "Current time batao"
    is Cmd.TimerSet -> "Timer lagao: ${seconds}s"
    Cmd.TimerCancel -> "Timer cancel karo"
    Cmd.TimerPause -> "Timer pause karo"
    Cmd.TimerResume -> "Timer resume karo"
    is Cmd.Stopwatch -> if (start) "Stopwatch chalu karo" else "Stopwatch band karo"
    Cmd.Stop -> "Stop"
    Cmd.Cancel -> "Cancel"
    Cmd.Pause -> "Pause"
    Cmd.Resume -> "Resume"
    Cmd.ReadAloud -> "Screen ka text padho"
    Cmd.ExplainScreen -> "Screen samjhao"
    Cmd.ExplainError -> "Error ka matlab batao"
    Cmd.Summarize -> "Page ka summary do"
    Cmd.Copy -> "Text copy karo"
    Cmd.Paste -> "Paste karo"
    is Cmd.Search -> "Search karo: $query"
    is Cmd.OpenResult -> "Result #$n kholo"
    is Cmd.OpenSettings -> "Settings page kholo: $page"
    is Cmd.DraftMessage -> "Message draft karo"
    is Cmd.TypeText -> "Text likho: $text"
    is Cmd.ClickText -> "Click karo: $text"
    is Cmd.Remember -> "Yaad rakho: $text"
    is Cmd.RunSkill -> "Skill chalao: $name"
    is Cmd.Compound -> steps.joinToString(" -> ") { it.describe() }
    is Cmd.Unknown -> "Samajh nahi aaya"
}
