package com.orbo.assistant.agent

import android.Manifest
import android.content.pm.PackageManager
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.orbo.assistant.command.Cmd
import com.orbo.assistant.command.CommandParser
import com.orbo.assistant.command.describe
import com.orbo.assistant.core.Orbo
import com.orbo.assistant.core.PillAction
import com.orbo.assistant.core.PillKind
import com.orbo.assistant.core.Skill
import com.orbo.assistant.core.Stores
import com.orbo.assistant.orb.OrbState
import com.orbo.assistant.timer.TimerManager
import com.orbo.assistant.ui.PermissionActivity
import com.orbo.assistant.voice.Speaker
import com.orbo.assistant.voice.VoiceEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

/**
 * Orchestrator: voice -> text -> CommandParser -> Task (deterministic planner) -> Executor -> verify -> TTS.
 * Ek time par ek hi task chalta hai (duplicate/conflict prevention).
 */
object Assistant {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    val speaker: Speaker by lazy { Speaker(Orbo.app) }
    val voice: VoiceEngine by lazy { VoiceEngine(Orbo.app) }

    private var job: Job? = null
    @Volatile var current: Task? = null
        private set
    private var lastText = ""
    private var lastAt = 0L
    private var awaiting: CompletableDeferred<String?>? = null
    private var confirmD: CompletableDeferred<Boolean>? = null
    private var chooseD: CompletableDeferred<String?>? = null

    fun isRunning(): Boolean = job?.isActive == true

    // ---------------- voice ----------------
    fun startVoice() {
        val ctx = Orbo.app
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Orbo.force(OrbState.ERROR)
            Orbo.say("Mic permission chahiye", PillKind.ERROR, "Permission screen khul rahi hai. Allow karke dobara mic dabao.")
            PermissionActivity.request(ctx, arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        if (isRunning() && awaiting == null && confirmD == null && chooseD == null) {
            Orbo.say("Task chal raha hai", PillKind.ERROR, "Pehle 'Stop' bolo ya Stop button dabao.")
            return
        }
        speaker.stop()
        Orbo.force(OrbState.LISTENING)
        Orbo.say("Listening...", PillKind.LISTENING)
        voice.start(Orbo.prefs.lang, Orbo.prefs.silenceSec, object : VoiceEngine.Callback {
            override fun onPartial(text: String) {
                Orbo.say(text, PillKind.LISTENING, "Sun raha hoon...")
            }

            override fun onFinal(text: String) {
                Orbo.say(text, PillKind.THINKING)
                submit(text)
            }

            override fun onFailure(message: String, suggestText: Boolean) {
                Orbo.force(OrbState.ERROR)
                Orbo.say("Voice nahi chala", PillKind.ERROR, message + if (suggestText) "\n\nPill kholo (tap arrow) aur text box mein command likho." else "")
                scope.launch {
                    delay(3000)
                    if (Orbo.machine.state.value == OrbState.ERROR) Orbo.force(OrbState.IDLE)
                }
            }
        })
    }

    fun stopListening() = voice.stopListening()

    // ---------------- submit ----------------
    fun submit(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val norm = CommandParser.normalize(t)

        // confirmation ke jawab (text se)
        val cd = confirmD
        if (cd != null) {
            if (norm.any { it in setOf("haan", "ha", "yes", "ok", "okay", "theek") }) { cd.complete(true); return }
            if (norm.any { it in setOf("nahi", "no", "cancel", "mat") }) { cd.complete(false); return }
        }
        val aw = awaiting
        if (aw != null) {
            if (norm.size == 1 && norm[0] in setOf("stop", "cancel", "ruko")) aw.complete(null) else aw.complete(t)
            return
        }

        val parsed = CommandParser.parse(t)
        when (parsed) {
            Cmd.Stop -> { stopAll("Stop kar diya"); return }
            Cmd.Cancel -> { stopAll("Cancel kar diya"); return }
            Cmd.Pause -> { pauseOrResume(true); return }
            Cmd.Resume -> { pauseOrResume(false); return }
            else -> {}
        }
        val now = SystemClock.elapsedRealtime()
        if (t == lastText && now - lastAt < 1500) return
        lastText = t
        lastAt = now
        if (isRunning()) {
            Orbo.say("Pehla task chal raha hai", PillKind.ERROR, "'Stop' ya 'Cancel' bolo/likho, phir naya command do.")
            return
        }
        speaker.stop()
        startTask(t, parsed)
    }

    fun runSkill(skill: Skill) {
        if (isRunning()) {
            Orbo.say("Pehla task chal raha hai", PillKind.ERROR, "Pehle Stop karo.")
            return
        }
        val cmds = skill.steps.map { CommandParser.parse(it) }
        startTask("Skill: ${skill.name}", Cmd.Compound(cmds))
    }

    fun dryRun(skill: Skill): String =
        skill.steps.mapIndexed { i, s ->
            val c = CommandParser.parse(s)
            if (c is Cmd.Unknown) "${i + 1}. UNSUPPORTED: $s\n   ${c.hint}" else "${i + 1}. ${c.describe()}"
        }.joinToString("\n")

    fun stopAll(msg: String) {
        voice.cancel()
        speaker.stop()
        confirmD?.complete(false)
        awaiting?.complete(null)
        chooseD?.complete(null)
        job?.cancel()
        Orbo.machine.reset()
        Orbo.say(msg, PillKind.RESULT)
    }

    private fun pauseOrResume(pause: Boolean) {
        val msg = if (pause) {
            when {
                speaker.pause() -> "Reading pause kiya"
                TimerManager.pauseAll() > 0 -> "Timer pause kiya"
                else -> "Pause karne ko kuch nahi chal raha"
            }
        } else {
            when {
                speaker.resume() -> "Reading resume ki"
                TimerManager.resumeAll() > 0 -> "Timer resume kiya"
                else -> "Resume karne ko kuch nahi"
            }
        }
        Orbo.say(msg, PillKind.RESULT)
    }

    // ---------------- interaction helpers (Executor use karta hai) ----------------
    suspend fun confirm(title: String, detail: String, yes: String, no: String): Boolean {
        val d = CompletableDeferred<Boolean>()
        confirmD = d
        current?.state = TaskState.NEEDS_CONFIRMATION
        Orbo.force(OrbState.WAITING)
        Orbo.say(title, PillKind.VERIFICATION, detail, listOf(PillAction(yes) { d.complete(true) }, PillAction(no) { d.complete(false) }))
        try {
            return d.await()
        } finally {
            confirmD = null
            current?.state = TaskState.RUNNING
            Orbo.force(OrbState.EXECUTING)
        }
    }

    suspend fun choose(title: String, options: List<Pair<String, String>>): String? {
        val d = CompletableDeferred<String?>()
        chooseD = d
        current?.state = TaskState.WAITING_FOR_USER
        Orbo.force(OrbState.WAITING)
        val actions = options.map { o -> PillAction(o.first) { d.complete(o.second) } } + PillAction("Cancel") { d.complete(null) }
        Orbo.say(title, PillKind.VERIFICATION, "Ek option chuno.", actions)
        try {
            return d.await()
        } finally {
            chooseD = null
            current?.state = TaskState.RUNNING
            Orbo.force(OrbState.EXECUTING)
        }
    }

    suspend fun ask(prompt: String): String? {
        val d = CompletableDeferred<String?>()
        awaiting = d
        current?.state = TaskState.WAITING_FOR_USER
        Orbo.force(OrbState.WAITING)
        Orbo.say(prompt, PillKind.VERIFICATION, "Text box mein likho ya Bolo dabao.", listOf(PillAction("Bolo") { startVoice() }, PillAction("Cancel") { d.complete(null) }))
        try {
            return d.await()
        } finally {
            awaiting = null
            current?.state = TaskState.RUNNING
            Orbo.force(OrbState.EXECUTING)
        }
    }

    // ---------------- task engine ----------------
    private fun startTask(text: String, cmd: Cmd) {
        val flat = if (cmd is Cmd.Compound) cmd.steps else listOf(cmd)
        val task = Task(UUID.randomUUID().toString(), text, flat.map { Step(it) })
        current = task
        job = scope.launch { runTask(task) }
    }

    private fun icon(s: StepStatus) = when (s) {
        StepStatus.PENDING -> "○"
        StepStatus.RUNNING -> "…"
        StepStatus.OK -> "✓"
        StepStatus.FAILED -> "✗"
        StepStatus.SKIPPED -> "–"
    }

    private fun plan(t: Task): String = t.steps.joinToString("\n") {
        "${icon(it.status)} ${it.cmd.describe()}" + (if (it.message.isNotBlank()) "\n    ${it.message}" else "")
    }

    private fun progress(c: Cmd): String = when (c) {
        is Cmd.OpenApp -> "Opening ${c.query}..."
        is Cmd.Search -> "Searching..."
        Cmd.ReadAloud -> "Reading..."
        is Cmd.TimerSet -> "Setting timer..."
        else -> "Executing..."
    }

    private suspend fun runTask(task: Task) {
        task.startedAt = System.currentTimeMillis()
        val speakParts = mutableListOf<String>()
        try {
            task.state = TaskState.PLANNING
            Orbo.force(OrbState.THINKING)
            Orbo.say("Thinking...", PillKind.THINKING, plan(task))
            delay(250)

            task.state = TaskState.RUNNING
            for (step in task.steps) {
                step.status = StepStatus.RUNNING
                Orbo.force(OrbState.EXECUTING)
                Orbo.say(progress(step.cmd), PillKind.EXECUTING, plan(task))
                var res = Executor.run(step.cmd)
                if (!res.ok && Executor.retryable(step.cmd)) {
                    task.state = TaskState.RECOVERING
                    delay(800)
                    task.state = TaskState.RUNNING
                    res = Executor.run(step.cmd)
                }
                step.message = res.message
                step.status = if (res.ok) StepStatus.OK else StepStatus.FAILED
                res.speak?.let { speakParts.add(it) }
                if (!res.ok) {
                    task.state = TaskState.FAILED
                    Orbo.force(OrbState.ERROR)
                    Orbo.say("Fail: " + res.message.lineSequence().first().take(80), PillKind.ERROR, plan(task))
                    say(res.message.take(300))
                    returnToIdle()
                    return
                }
            }

            task.state = TaskState.COMPLETED
            Orbo.force(OrbState.COMPLETED)
            val last = task.steps.last()
            val headline = last.message.lineSequence().first().take(80).ifBlank { "Ho gaya" }
            val timerStep = task.steps.lastOrNull { it.cmd is Cmd.TimerSet }
            if (timerStep != null && task.steps.size == 1) {
                val t = TimerManager.active().lastOrNull()
                Orbo.say(if (t != null) TimerManager.format(TimerManager.remainingMs(t)) + " remaining" else headline, PillKind.TIMER, plan(task))
            } else {
                Orbo.say(headline, PillKind.RESULT, plan(task))
            }
            if (speakParts.isNotEmpty()) say(speakParts.joinToString(". "))
            returnToIdle()
        } catch (e: CancellationException) {
            task.state = TaskState.CANCELLED
            task.steps.forEach { if (it.status == StepStatus.PENDING || it.status == StepStatus.RUNNING) it.status = StepStatus.SKIPPED }
            throw e
        } catch (e: Exception) {
            task.state = TaskState.FAILED
            Orbo.force(OrbState.ERROR)
            Orbo.say("Error: ${e.message ?: "unknown"}", PillKind.ERROR, plan(task))
            returnToIdle()
        } finally {
            task.endedAt = System.currentTimeMillis()
            persist(task)
        }
    }

    private fun say(text: String) {
        if (Orbo.prefs.speakReplies) speaker.speak(text)
    }

    private fun returnToIdle() {
        scope.launch {
            delay(2500)
            val s = Orbo.machine.state.value
            if (s == OrbState.COMPLETED || s == OrbState.ERROR || s == OrbState.SEARCH_FOUND) Orbo.force(OrbState.IDLE)
        }
    }

    private fun persist(t: Task) {
        try {
            Stores.history.append(
                JSONObject().put("id", t.id).put("command", t.command).put("start", t.startedAt)
                    .put("end", t.endedAt).put("state", t.state.name).put("result", plan(t)),
            )
        } catch (e: Exception) {
        }
    }
}
