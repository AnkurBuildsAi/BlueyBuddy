#!/usr/bin/env python3
"""Basic project preflight; Android compilation remains the Gradle job's responsibility."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
required = [
    "settings.gradle", "build.gradle", "app/build.gradle",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/orbo/assistant/MainActivity.java",
    "app/src/main/java/com/orbo/assistant/core/CommandRouter.java",
    "app/src/main/java/com/orbo/assistant/core/GeminiProvider.java",
    "app/src/main/java/com/orbo/assistant/overlay/OrbOverlayService.java",
    "app/src/main/java/com/orbo/assistant/accessibility/OrboAccessibilityService.java",
]
missing = [p for p in required if not (ROOT / p).is_file()]
if missing:
    print("Missing files:", ", ".join(missing), file=sys.stderr)
    sys.exit(1)

for p in ["app/src/main/AndroidManifest.xml", "app/src/main/res/xml/orbo_accessibility_service.xml", "app/src/main/res/values/styles.xml"]:
    ET.parse(ROOT / p)

manifest = ET.parse(ROOT / "app/src/main/AndroidManifest.xml").getroot()
android = "{http://schemas.android.com/apk/res/android}"
app_id = "{http://schemas.android.com/apk/res-auto}"
uses = {x.get(android + "name") for x in manifest.findall("uses-permission")}
assert "android.permission.SYSTEM_ALERT_WINDOW" in uses
assert "android.permission.RECORD_AUDIO" in uses
assert "android.permission.INTERNET" in uses
app_gradle = (ROOT / "app/build.gradle").read_text(encoding="utf-8")
assert "minSdk 27" in app_gradle
assert "targetSdk 32" in app_gradle
assert "com.orbo.assistant" in app_gradle

# Basic safeguard: the source must not contain an actual API key literal.
for p in (ROOT / "app/src/main").rglob("*.java"):
    content = p.read_text(encoding="utf-8")
    assert "AIzaSy" not in content, f"Possible hard-coded Google key in {p}"

print("ORBO preflight passed: expected files and XML are present; minSdk/permissions checked.")
print("This is not an Android compile or device test.")
