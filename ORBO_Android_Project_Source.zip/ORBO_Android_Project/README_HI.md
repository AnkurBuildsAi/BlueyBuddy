# ORBO Android — Source ZIP (fresh project)

यह एक नया Android Studio/Gradle source project है। इसका package `com.orbo.assistant` है। ऐप का नाम ORBO ही रखा गया है। यह ZIP APK नहीं है; GitHub Actions इसे APK में build करेगा।

## Device baseline

- `minSdk 27` — Android 8.1 या उससे नया।
- `compileSdk 35`, `targetSdk 32`.
- Java + native Android Views/Canvas. Compose rewrite नहीं किया गया, ताकि low-RAM Android 8.1 target पर framework हल्का रहे।
- Oppo A3s Android 8.1 पर minimum API match करता है। Vivo Y13s के exact model/firmware को फोन के `Settings > About phone` में verify करें; इस package को Android 8.1+ के लिए configure किया है।
- **किसी असली Oppo A3s या Vivo Y13s पर अभी physical-device test नहीं हुआ है।** यह build environment में Android SDK/Gradle न होने के कारण अभी locally compile-verified भी नहीं है। GitHub Actions की पहली build इसका compile check करेगी।

## इसमें अभी source में मौजूद functionality

1. ORBO liquid-glass inspired blue/purple orb, custom Canvas face, eyes/mouth, timed blink, mood state.
2. Overlay Service; floating orb, drag + saved position, 500ms long-press to Smart Pill, tap bounce, swipe-up Peek mode (pill handle/orb से), close/collapse.
3. Foreground notification और Stop control. Android overlay permission जरूरी है.
4. Manual mic activation; Android SpeechRecognizer, Hindi `hi-IN` preference, Text-to-Speech fallback.
5. Deterministic local routing: greeting, time/date, basic arithmetic, timer/cancel, open installed app, Google search, Back/Home/Recents, scroll, type into ordinary focused fields, copy/paste, numbered click (`show buttons`, फिर `tap 1`), settings.
6. Timer AlarmManager scheduling, completion notification और reboot पर pending timer restore. Exact-alarm permission न होने पर Android का inexact idle-compatible fallback इस्तेमाल होगा.
7. AccessibilityService — केवल user enable करने पर. Password fields में text read/type/paste नहीं करता; Accessibility हर app/screen पर guarantee नहीं है.
8. App PIN — 4–8 digits, salted PBKDF2-HMAC-SHA256 (80,000 iterations), constant-time comparison और escalating lockout. यह केवल ORBO app gate है, Android lock screen या दूसरे apps का system lock नहीं.
9. Supported device biometric के लिए AndroidX BiometricPrompt; hardware/enrolment उपलब्ध न हो तो PIN fallback.
10. AI Assist default OFF. Gemini API key Android Keystore AES-GCM से encrypted रूप में local preferences में store होती है. Provider interface रखा है. Known commands AI को नहीं भेजे जाते. केवल unknown command AI-enabled + internet + valid key होने पर Gemini fallback को भेजा जाता है. Screen summary में पहले consent, फिर text preview, फिर अलग से Send confirmation; screenshot नहीं भेजा जाता.
11. Local task history.

## अभी इस fresh build में शामिल नहीं / पूरी तरह verified नहीं

इनको पूरा बना हुआ बताना सही नहीं होगा:

- Always-on `Hello ORBO` wake-word listening.
- True unlock-screen lifecycle animation; अभी overlay service start animation है, system unlock event integration नहीं.
- Complete multi-step agent that receives a structured action plan from Gemini, previews every step, and safely executes/validates all steps. फिलहाल Gemini fallback जवाब देता है; वह स्वतः phone actions execute नहीं करता.
- Face-matching camera flow, camera-based failed-PIN capture, per-app lock manager, और Android lock screen replacement. ये spec में optional/OS-limited concepts हैं; इस source build में नहीं हैं.
- Multiple concurrent timers, calendar reminders, full skill/plugin marketplace, local long-term semantic memory.
- Raw screenshot/MediaProjection based screen vision. केवल consented Accessibility text preview है.
- हर third-party app में guaranteed clicking/typing/scrolling. Apps Accessibility को रोक सकती हैं या controls expose नहीं करतीं.
- Real-device verification, battery/performance measurements, release signing, production security review.

## AI / Gemini setup

1. APK install करके ORBO खोलें.
2. `AI Assist, Gemini key and model` खोलें.
3. AI Assist ON करें. Default model `gemini-2.5-flash` है; जरूरत पर Settings में model name बदल सकते हैं.
4. अपनी Gemini API key डालकर Save करें.
5. Key source code या GitHub repository में नहीं है. इसे APK से पूरी तरह सुरक्षित रखना संभव नहीं, क्योंकि client-device app में runtime पर key मौजूद रहती है. Google production apps के लिए backend proxy की सलाह देता है. Personal testing key पर quota/billing limits लगाएँ और key किसी के साथ share न करें.
6. AI OFF, no key, no network या quota failure होने पर app local commands चलाता रहेगा और friendly message देगा.

## GitHub से APK बनाने का तरीका (Android phone से)

यह project ZIP repository में एक file के रूप में upload करें: `ORBO_Android_Project_Source.zip`.

1. GitHub पर नया empty repository बनाएँ, उदाहरण `ORBO`.
2. Repository के root में `ORBO_Android_Project_Source.zip` upload करें.
3. `Add file > Create new file` खोलें और filename में ठीक यह path लिखें: `.github/workflows/android-apk.yml`.
4. नीचे दिए गए अलग `android-apk.yml` file का पूरा code paste करके Commit करें.
5. `Actions` tab खोलें. `Build ORBO APK` workflow run होगा.
6. Successful run के `Artifacts` section से `ORBO-debug-apk` download करें. Artifact ZIP के अंदर `app-debug.apk` होगा.

Workflow source ZIP extract करके Gradle 8.9 + JDK 17 से build करता है और Android SDK 35 तथा Build Tools install/licences accept करता है. कोई API key build में embed नहीं होती.

## First install permissions

- Display over other apps / Overlay — floating orb के लिए.
- Microphone — manual speech input के लिए.
- Accessibility — Back/Home/Scroll/Type/Copy/Paste/numbered click और consented visible text के लिए. यह optional है, ORBO Settings में जाकर user कभी भी disable कर सकता है.
- Notifications — foreground assistant status और timer alerts के लिए.
- Exact alarm access — Android 12+ पर optional; न मिले तो timer inexact fallback लेता है.

Battery optimization को OEM settings में user स्वयं allowlist कर सकता है; Android/Oppo/Vivo background limits के कारण service हर परिस्थिति में जीवित रहने की guarantee नहीं है.

## Honest build status

- Source generated: YES.
- Unit tests added: YES (command parser tests).
- Local Gradle build run here: NO (this environment has no Android SDK/Gradle installation).
- GitHub Actions build: NOT RUN yet.
- Oppo A3s device test: NOT RUN.
- Vivo Y13s device test: NOT RUN.
- Zero-bug claim: NOT made.

पहली GitHub Actions build के बाद अगर workflow error दे, पूरा build log भेजें; exact error के अनुसार source fix करना होगा. Green build के बाद दोनों phones पर install/permission/voice/overlay regression test जरूरी है.
