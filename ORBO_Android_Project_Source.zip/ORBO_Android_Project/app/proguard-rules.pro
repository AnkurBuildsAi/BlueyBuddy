# Keep default Android rules. Add explicit rules only when release shrinking is enabled.
