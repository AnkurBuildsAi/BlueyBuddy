package com.orbo.assistant.core;

import org.junit.Test;
import static org.junit.Assert.*;

public class CommandRouterTest {
    @Test public void knownCommandsStayLocal() {
        assertEquals(CommandRouter.Type.BACK, CommandRouter.route("go back").type);
        assertEquals(CommandRouter.Type.HOME, CommandRouter.route("home").type);
        assertEquals(CommandRouter.Type.OPEN_APP, CommandRouter.route("open youtube").type);
        assertEquals(CommandRouter.Type.SEARCH, CommandRouter.route("search weather").type);
        assertEquals(CommandRouter.Type.COPY, CommandRouter.route("copy").type);
        assertEquals(CommandRouter.Type.PASTE, CommandRouter.route("paste").type);
    }

    @Test public void parsesTimerDurations() {
        assertEquals(120000L, CommandRouter.route("timer 2 minutes").durationMs);
        assertEquals(30000L, CommandRouter.route("30 seconds").durationMs);
        assertEquals(3600000L, CommandRouter.route("1 hour").durationMs);
        assertEquals(5000L, CommandRouter.route("5 सेकंड का टाइमर").durationMs);
    }

    @Test public void hindiDigitsNormalize() {
        assertEquals("timer 5 minutes", CommandRouter.normalize("timer ५ minutes"));
    }

    @Test public void unknownIsNotSilentlyTreatedAsKnown() {
        assertFalse(CommandRouter.route("please do a complicated task with several steps").known);
        assertEquals(CommandRouter.Type.UNKNOWN, CommandRouter.route("please do a complicated task with several steps").type);
    }

    @Test public void numberedTapAndListControls() {
        assertEquals("2", CommandRouter.route("tap २").value);
        assertEquals(CommandRouter.Type.LIST_CONTROLS, CommandRouter.route("show buttons").type);
    }
}
