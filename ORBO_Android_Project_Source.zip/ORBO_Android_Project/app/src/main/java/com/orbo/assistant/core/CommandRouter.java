package com.orbo.assistant.core;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Deterministic, offline-first command router. Known commands never reach the AI provider. */
public final class CommandRouter {
    private CommandRouter() { }
    public enum Type { GREETING, TIME, DATE, CALCULATE, TIMER, CANCEL_TIMER, OPEN_APP, SEARCH, BACK, HOME,
        RECENTS, SCROLL_FORWARD, SCROLL_BACKWARD, TYPE_TEXT, COPY, PASTE, TAP_NUMBER, LIST_CONTROLS, SCREEN_SUMMARY,
        SETTINGS, UNKNOWN }

    public static final class Command {
        public final Type type;
        public final String value;
        public final long durationMs;
        public final String response;
        public final boolean known;
        Command(Type t, String v, long d, String r, boolean k) { type=t; value=v; durationMs=d; response=r; known=k; }
    }

    public static Command route(String raw) {
        String text = normalize(raw);
        if (text.isEmpty()) return unknown();

        if (containsAny(text, "hello", "hi orbo", "hey orbo", "नमस्ते", "नमस्कार", "हेलो", "hello orbo"))
            return cmd(Type.GREETING, "", 0, "Namaste! Main ORBO hoon. Bataiye kya karna hai.");
        if (containsAny(text, "time", "समय", "kitne baje", "कितने बजे")) return cmd(Type.TIME, "", 0, "");
        if (containsAny(text, "date", "तारीख", "आज की तारीख", "आज कौन सा दिन")) return cmd(Type.DATE, "", 0, "");
        if (containsAny(text, "cancel timer", "stop timer", "timer cancel", "टाइमर बंद", "टाइमर रद्द"))
            return cmd(Type.CANCEL_TIMER, "", 0, "Timer cancel kar diya.");
        if (containsAny(text, "back", "go back", "पीछे जाओ", "वापस जाओ")) return cmd(Type.BACK, "", 0, "Back action bhej diya.");
        if (containsAny(text, "home", "go home", "होम", "होम स्क्रीन")) return cmd(Type.HOME, "", 0, "Home action bhej diya.");
        if (containsAny(text, "recent apps", "recents", "recent", "हाल के ऐप")) return cmd(Type.RECENTS, "", 0, "Recent apps khol raha hoon.");
        if (containsAny(text, "scroll down", "नीचे स्क्रॉल", "नीचे करो", "scroll next")) return cmd(Type.SCROLL_FORWARD, "", 0, "Scroll kar raha hoon.");
        if (containsAny(text, "scroll up", "ऊपर स्क्रॉल", "ऊपर करो", "scroll previous")) return cmd(Type.SCROLL_BACKWARD, "", 0, "Scroll kar raha hoon.");
        if (containsAny(text, "copy", "कॉपी करो", "कॉपी")) return cmd(Type.COPY, "", 0, "Selected text copy karne ki koshish kar raha hoon.");
        if (containsAny(text, "paste", "पेस्ट करो", "पेस्ट")) return cmd(Type.PASTE, "", 0, "Clipboard paste kar raha hoon.");
        if (containsAny(text, "settings", "open settings", "सेटिंग", "सेटिंग्स")) return cmd(Type.SETTINGS, "", 0, "ORBO settings khol raha hoon.");
        if (containsAny(text, "show buttons", "list buttons", "show controls", "बटन दिखाओ", "कंट्रोल दिखाओ"))
            return cmd(Type.LIST_CONTROLS, "", 0, "Screen ke labelled controls ki list dikha raha hoon.");
        if (containsAny(text, "explain this screen", "summarize this screen", "read this screen", "इस स्क्रीन को समझाओ", "स्क्रीन समझाओ"))
            return cmd(Type.SCREEN_SUMMARY, "", 0, "Screen text read karne se pehle aapki permission chahiye.");

        Matcher tap = Pattern.compile("^(?:tap|click|press|दबाओ|क्लिक करो)\\s*(\\d+)$").matcher(text);
        if (tap.find()) return cmd(Type.TAP_NUMBER, tap.group(1), 0, "Visible item " + tap.group(1) + " par click kar raha hoon.");

        Matcher timer = Pattern.compile("^(?:set\\s+)?(?:a\\s+)?timer\\s+(\\d+)\\s*(s|sec|seconds?|m|min|minutes?|h|hours?)$").matcher(text);
        Matcher hindiTimer = Pattern.compile("^(\\d+)\\s*(सेकंड|सेकण्ड|मिनट|घंटे|घंटा)\\s*(का)?\\s*टाइमर$").matcher(text);
        if (timer.find()) {
            long n = safeLong(timer.group(1)); String unit = timer.group(2);
            long mult = unit.startsWith("s") ? 1000L : unit.startsWith("h") ? 3600000L : 60000L;
            return timerCommand(n, mult);
        }
        if (hindiTimer.find()) {
            long n = safeLong(hindiTimer.group(1)); String unit = hindiTimer.group(2);
            return timerCommand(n, unit.startsWith("सेक") ? 1000L : unit.startsWith("मिनट") ? 60000L : 3600000L);
        }
        Matcher alternateTimer = Pattern.compile("^(\\d+)\\s*(seconds?|secs?|minutes?|mins?|hours?)$").matcher(text);
        if (alternateTimer.find()) {
            long n=safeLong(alternateTimer.group(1)); String u=alternateTimer.group(2);
            return timerCommand(n, u.startsWith("s") ? 1000L : u.startsWith("h") ? 3600000L : 60000L);
        }

        Matcher calc = Pattern.compile("^(?:calculate|what is|कितना होगा)\\s*(-?\\d+(?:\\.\\d+)?)\\s*([+\\-x*/])\\s*(-?\\d+(?:\\.\\d+)?)$").matcher(text);
        if (calc.find()) {
            double a=Double.parseDouble(calc.group(1)), b=Double.parseDouble(calc.group(3));
            String op=calc.group(2); double result;
            if (op.equals("+")) result=a+b; else if (op.equals("-")) result=a-b; else if (op.equals("x" ) || op.equals("*")) result=a*b;
            else { if (b==0) return cmd(Type.CALCULATE, "", 0, "Zero se divide nahi kar sakte."); result=a/b; }
            return cmd(Type.CALCULATE, "", 0, "Result: " + (result == Math.rint(result) ? String.valueOf((long)result) : String.valueOf(result)));
        }

        Matcher type = Pattern.compile("^(?:type|write|लिखो|टाइप करो)\\s+(.+)$").matcher(text);
        if (type.find()) return cmd(Type.TYPE_TEXT, type.group(1), 0, "Text type kar raha hoon.");
        Matcher search = Pattern.compile("^(?:search|google|find|खोजो|सर्च करो)\\s+(.+)$").matcher(text);
        if (search.find()) return cmd(Type.SEARCH, search.group(1), 0, "Google par search kar raha hoon.");
        Matcher open = Pattern.compile("^(?:open|launch|start|खोलो|चालू करो)\\s+(.+)$").matcher(text);
        if (open.find()) return cmd(Type.OPEN_APP, open.group(1), 0, "App kholne ki koshish kar raha hoon.");

        return unknown();
    }

    private static Command timerCommand(long amount, long multiplier) {
        if (amount <= 0 || amount > 100000) return cmd(Type.TIMER, "", 0, "Timer ki duration sahi nahi hai.");
        long duration = amount * multiplier;
        if (duration > 7L * 24 * 60 * 60 * 1000) return cmd(Type.TIMER, "", 0, "Timer maximum 7 din ka ho sakta hai.");
        return new Command(Type.TIMER, "", duration, "Timer start kar diya.", true);
    }
    private static long safeLong(String s) { try { return Long.parseLong(s); } catch (Exception e) { return -1; } }
    private static boolean containsAny(String s, String... words) { for (String w : words) if (s.equals(w) || s.startsWith(w + " ")) return true; return false; }
    private static Command cmd(Type t, String v, long d, String r) { return new Command(t, v, d, r, true); }
    private static Command unknown() { return new Command(Type.UNKNOWN, "", 0, "Ye command abhi samajh nahi aaya.", false); }

    public static String normalize(String input) {
        if (input == null) return "";
        String s = Normalizer.normalize(input.trim().toLowerCase(Locale.ROOT), Normalizer.Form.NFKC);
        // Devanagari digits -> ASCII digits, to support Hindi timer/tap numbers.
        String devanagari = "०१२३४५६७८९";
        for (int i=0;i<10;i++) s=s.replace(devanagari.charAt(i), (char)('0'+i));
        return s.replaceAll("\\s+", " ").replace('×', 'x').replace('÷', '/');
    }
}
