package com.orbo.assistant.core;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.speech.tts.TextToSpeech;
import android.text.TextUtils;

import com.orbo.assistant.accessibility.OrboAccessibilityService;
import com.orbo.assistant.timer.TimerScheduler;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class CommandExecutor {
    public interface Callback { void onResult(String message); }
    private CommandExecutor() { }

    public static void execute(Context context, CommandRouter.Command command, Callback callback) {
        String message = command.response;
        boolean success = true;
        switch (command.type) {
            case GREETING: break;
            case TIME:
                message = "Abhi " + DateFormat.getTimeInstance(DateFormat.SHORT, new Locale("hi", "IN")).format(new Date()) + " baj rahe hain.";
                break;
            case DATE:
                message = DateFormat.getDateInstance(DateFormat.FULL, new Locale("hi", "IN")).format(new Date());
                break;
            case CALCULATE: break;
            case TIMER:
                if (command.durationMs <= 0) { message = command.response; success = false; }
                else {
                    success = TimerScheduler.schedule(context, command.durationMs);
                    message = success ? "Timer start ho gaya. Android ke battery aur alarm rules se exact timing affect ho sakti hai." : "Timer schedule nahi ho saka. Alarm permission ya system restriction check karein.";
                }
                break;
            case CANCEL_TIMER:
                TimerScheduler.cancel(context);
                message = "Timer cancel kar diya.";
                break;
            case OPEN_APP:
                success = openApp(context, command.value);
                message = success ? command.value + " khol raha hoon." : "Ye app nahi mila. App ka naam dobara batayein.";
                break;
            case SEARCH:
                try {
                    Intent search = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(command.value)));
                    search.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(search);
                    message = "Google search khol diya.";
                } catch (Exception e) { success=false; message="Search kholna possible nahi hua."; }
                break;
            case BACK:
                success = OrboAccessibilityService.back();
                if (!success) message = "Back ke liye ORBO Accessibility permission enable karein.";
                break;
            case HOME:
                success = OrboAccessibilityService.home();
                if (!success) message = "Home action ke liye ORBO Accessibility permission enable karein.";
                break;
            case RECENTS:
                success = OrboAccessibilityService.recents();
                if (!success) message = "Recent Apps action ke liye ORBO Accessibility permission enable karein.";
                break;
            case SCROLL_FORWARD:
            case SCROLL_BACKWARD:
                success = OrboAccessibilityService.scroll(command.type == CommandRouter.Type.SCROLL_FORWARD);
                if (!success) message = "Is screen par scroll nahi ho saka. Accessibility enable karein ya screen scrollable nahi hai.";
                break;
            case TYPE_TEXT:
                success = OrboAccessibilityService.typeText(command.value);
                if (!success) message = "Text type nahi kiya. Pehle normal text field select karein. Password/secure fields blocked hain.";
                break;
            case COPY:
                success = OrboAccessibilityService.copySelectedText(context);
                if (!success) message = "Selected text copy nahi hua. Text select karke dobara try karein.";
                break;
            case PASTE:
                success = OrboAccessibilityService.pasteClipboard();
                if (!success) message = "Paste nahi hua. Normal editable field select karein; secure fields blocked hain.";
                break;
            case TAP_NUMBER:
                try { success = OrboAccessibilityService.clickByNumber(Integer.parseInt(command.value)); }
                catch (Exception e) { success = false; }
                if (!success) message = "Numbered item nahi mila. Pehle 'show buttons' ya screen ke visible controls dekhein.";
                break;
            case LIST_CONTROLS:
                message = OrboAccessibilityService.clickableLabels();
                break;
            case SETTINGS:
                Intent settings = new Intent(android.provider.Settings.ACTION_SETTINGS);
                settings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(settings);
                message = "Android Settings khol raha hoon.";
                break;
            case SCREEN_SUMMARY:
                message = "Screen samajhne ke liye app mein 'Explain current screen' par tap karke consent dein.";
                break;
            case UNKNOWN:
                message = "Ye command abhi samajh nahi aaya.";
                break;
        }
        if (!TextUtils.isEmpty(message)) SecureStore.saveHistory(context, command.type.name() + ": " + message);
        if (callback != null) callback.onResult(message);
    }

    private static boolean openApp(Context context, String appName) {
        PackageManager pm = context.getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);
        String wanted = appName.toLowerCase(Locale.ROOT).trim();
        ApplicationInfo best = null;
        for (ApplicationInfo info : apps) {
            CharSequence labelCs = pm.getApplicationLabel(info);
            String label = labelCs == null ? "" : labelCs.toString().toLowerCase(Locale.ROOT);
            if (label.equals(wanted)) { best = info; break; }
            if (best == null && (label.contains(wanted) || wanted.contains(label))) best = info;
        }
        if (best == null) return false;
        Intent launch = pm.getLaunchIntentForPackage(best.packageName);
        if (launch == null) return false;
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { context.startActivity(launch); return true; }
        catch (Exception e) { return false; }
    }
}
