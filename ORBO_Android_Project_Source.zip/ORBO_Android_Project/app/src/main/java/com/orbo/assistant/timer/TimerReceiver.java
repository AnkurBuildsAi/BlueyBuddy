package com.orbo.assistant.timer;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.orbo.assistant.MainActivity;
import com.orbo.assistant.R;

public class TimerReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "orbo_timer_alerts";
    @Override public void onReceive(Context context, Intent intent) {
        TimerScheduler.clearEnd(context);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "ORBO timer alerts", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Timer completion alerts");
            nm.createNotificationChannel(channel);
        }
        Intent open = new Intent(context, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(context, 302, open, flags);
        Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("ORBO Timer")
                .setContentText("Aapka timer poora ho gaya.")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setAutoCancel(true).setContentIntent(pi).setSound(sound);
        nm.notify(302, b.build());
    }
}
