package com.orbo.assistant.core;

import android.content.Context;

/** Provider seam: Gemini can later be replaced without changing local command routing. */
public interface AiProvider {
    void request(Context context, String userText, String consentedScreenText, GeminiProvider.Callback callback);
}
