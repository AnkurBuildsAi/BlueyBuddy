package com.orbo.assistant.timer;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public final class TimerScheduler {
    private static final String PREF = "orbo_timer";
    private TimerScheduler() { }

    public static boolean schedule(Context context, long durationMs) {
        if (durationMs <= 0) return false;
        long end = System.currentTimeMillis() + durationMs;
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putLong("end", end).apply();
        return scheduleAt(context, end);
    }

    public static boolean restore(Context context) {
        long end = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getLong("end", 0L);
        if (end <= 0) return false;
        if (end <= System.currentTimeMillis()) {
            fireNow(context);
            return true;
        }
        return scheduleAt(context, end);
    }

    private static boolean scheduleAt(Context context, long end) {
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return false;
            PendingIntent pi = pending(context);
            if (Build.VERSION.SDK_INT >= 23) {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi);
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi);
                }
            } else if (Build.VERSION.SDK_INT >= 19) am.setExact(AlarmManager.RTC_WAKEUP, end, pi);
            else am.set(AlarmManager.RTC_WAKEUP, end, pi);
            return true;
        } catch (SecurityException e) { return false; }
    }

    public static void cancel(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(pending(context));
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove("end").apply();
    }

    private static PendingIntent pending(Context context) {
        Intent i = new Intent(context, TimerReceiver.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, 301, i, flags);
    }

    static void clearEnd(Context context) { context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove("end").apply(); }
    private static void fireNow(Context context) {
        Intent i = new Intent(context, TimerReceiver.class);
        context.sendBroadcast(i);
    }
}
