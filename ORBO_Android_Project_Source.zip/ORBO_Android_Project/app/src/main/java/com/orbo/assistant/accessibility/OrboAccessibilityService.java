package com.orbo.assistant.accessibility;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** User-enabled bridge for explicit phone actions. Secure/password fields are never read or edited. */
public class OrboAccessibilityService extends AccessibilityService {
    private static volatile OrboAccessibilityService instance;

    @Override public void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* No background scraping. */ }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }

    public static boolean isConnected() { return instance != null; }
    public static boolean back() { return instance != null && instance.performGlobalAction(GLOBAL_ACTION_BACK); }
    public static boolean home() { return instance != null && instance.performGlobalAction(GLOBAL_ACTION_HOME); }
    public static boolean recents() { return instance != null && instance.performGlobalAction(GLOBAL_ACTION_RECENTS); }

    public static boolean scroll(boolean forward) {
        OrboAccessibilityService s = instance;
        if (s == null) return false;
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return false;
        try {
            AccessibilityNodeInfo scrollable = findScrollable(root);
            if (scrollable == null) return root.performAction(forward ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
            try { return scrollable.performAction(forward ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD); }
            finally { scrollable.recycle(); }
        } finally { root.recycle(); }
    }

    private static AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isScrollable()) return AccessibilityNodeInfo.obtain(node);
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo found = findScrollable(child);
            if (child != null) child.recycle();
            if (found != null) return found;
        }
        return null;
    }

    public static boolean typeText(String text) {
        OrboAccessibilityService s = instance;
        if (s == null || text == null) return false;
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return false;
        try {
            AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
            if (focused == null) return false;
            try {
                if (isSensitiveField(focused) || !focused.isEditable()) return false;
                Bundle args = new Bundle();
                args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
                return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
            } finally { focused.recycle(); }
        } finally { root.recycle(); }
    }

    private static boolean isSensitiveField(AccessibilityNodeInfo node) {
        if (node == null || node.isPassword()) return true;
        CharSequence hint = node.getHintText();
        String h = hint == null ? "" : hint.toString().toLowerCase(Locale.ROOT);
        String id = node.getViewIdResourceName();
        String i = id == null ? "" : id.toLowerCase(Locale.ROOT);
        String[] terms = {"password", "passcode", "otp", "one_time", "pin", "cvv", "cvc", "card_number", "account_number"};
        for (String term : terms) if (h.contains(term) || i.contains(term)) return true;
        return false;
    }

    public static boolean pasteClipboard() {
        OrboAccessibilityService s = instance;
        if (s == null) return false;
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return false;
        try {
            AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
            if (focused == null) return false;
            try {
                if (isSensitiveField(focused) || !focused.isEditable()) return false;
                return focused.performAction(AccessibilityNodeInfo.ACTION_PASTE);
            } finally { focused.recycle(); }
        } finally { root.recycle(); }
    }

    public static boolean copySelectedText(Context context) {
        OrboAccessibilityService s = instance;
        if (s == null) return false;
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return false;
        try {
            AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
            if (focused == null) focused = root;
            try {
                if (isSensitiveField(focused)) return false;
                boolean copied = focused.performAction(AccessibilityNodeInfo.ACTION_COPY);
                return copied;
            } finally { if (focused != root) focused.recycle(); }
        } finally { root.recycle(); }
    }

    public static int clickableCount() {
        OrboAccessibilityService s = instance;
        if (s == null) return 0;
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return 0;
        try { List<AccessibilityNodeInfo> list = new ArrayList<>(); collectClickable(root, list); int count = list.size(); for (AccessibilityNodeInfo n : list) n.recycle(); return count; }
        finally { root.recycle(); }
    }

    public static String clickableLabels() {
        OrboAccessibilityService s = instance;
        if (s == null) return "Accessibility service is not enabled.";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "No active screen.";
        List<AccessibilityNodeInfo> list = new ArrayList<>();
        try {
            collectClickable(root, list);
            StringBuilder b = new StringBuilder();
            for (int i=0; i<list.size() && i<40; i++) {
                AccessibilityNodeInfo n = list.get(i);
                CharSequence label = n.getText();
                if (TextUtils.isEmpty(label)) label = n.getContentDescription();
                b.append(i+1).append(". ").append(label == null ? "button" : label).append('\n');
            }
            return b.length()==0 ? "Is screen par labelled clickable controls nahi mile." : b.toString();
        } finally { for (AccessibilityNodeInfo n : list) n.recycle(); root.recycle(); }
    }

    public static boolean clickByNumber(int oneBasedIndex) {
        OrboAccessibilityService s = instance;
        if (s == null || oneBasedIndex < 1) return false;
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return false;
        List<AccessibilityNodeInfo> list = new ArrayList<>();
        try {
            collectClickable(root, list);
            if (oneBasedIndex > list.size()) return false;
            AccessibilityNodeInfo chosen = list.get(oneBasedIndex - 1);
            return chosen.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        } finally { for (AccessibilityNodeInfo n : list) n.recycle(); root.recycle(); }
    }

    private static void collectClickable(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out) {
        if (node == null || out.size() >= 100) return;
        CharSequence label = node.getText();
        CharSequence desc = node.getContentDescription();
        if (node.isClickable() && !node.isPassword() &&
                ((label != null && label.length() > 0) || (desc != null && desc.length() > 0))) {
            out.add(AccessibilityNodeInfo.obtain(node));
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            collectClickable(child, out);
            if (child != null) child.recycle();
        }
    }

    /** Called only after the user explicitly chooses the screen-explanation action. No screenshots. */
    public static String readVisibleTextWithConsent() {
        OrboAccessibilityService s = instance;
        if (s == null) return "Accessibility service is not enabled.";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "This screen does not expose readable text.";
        try {
            CharSequence pkg = root.getPackageName();
            String packageName = pkg == null ? "" : pkg.toString().toLowerCase(Locale.ROOT);
            if (packageName.contains("bank") || packageName.contains("upi") || packageName.contains("phonepe") ||
                    packageName.contains("paytm") || packageName.contains("googlepay") || packageName.contains("gpay")) {
                return "For privacy, ORBO will not read banking or payment screens.";
            }
            StringBuilder out = new StringBuilder();
            appendSafeText(root, out);
            if (out.length() == 0) return "No accessible text is available on this screen.";
            if (out.length() > 5000) out.setLength(5000);
            return out.toString();
        } finally { root.recycle(); }
    }

    private static void appendSafeText(AccessibilityNodeInfo node, StringBuilder out) {
        if (node == null || out.length() >= 5000 || node.isPassword()) return;
        CharSequence text = node.getText();
        CharSequence desc = node.getContentDescription();
        if (node.isEditable()) {
            CharSequence hint = node.getHintText();
            String h = hint == null ? "" : hint.toString().toLowerCase(Locale.ROOT);
            if (h.contains("password") || h.contains("otp") || h.contains("pin") || h.contains("cvv")) return;
            // Do not include arbitrary editable field contents in a screen summary.
        } else if (!TextUtils.isEmpty(text)) {
            appendLine(out, text.toString());
        } else if (!TextUtils.isEmpty(desc)) {
            appendLine(out, desc.toString());
        }
        for (int i = 0; i < node.getChildCount() && out.length() < 5000; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            appendSafeText(child, out);
            if (child != null) child.recycle();
        }
    }

    private static void appendLine(StringBuilder out, String s) {
        String clean = s.replace('\n', ' ').trim();
        if (!clean.isEmpty() && out.indexOf(clean) < 0) out.append(clean).append('\n');
    }
}
