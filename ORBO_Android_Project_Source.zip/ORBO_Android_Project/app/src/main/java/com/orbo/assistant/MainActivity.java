package com.orbo.assistant;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import com.orbo.assistant.accessibility.OrboAccessibilityService;
import com.orbo.assistant.core.CommandExecutor;
import com.orbo.assistant.core.CommandRouter;
import com.orbo.assistant.core.GeminiProvider;
import com.orbo.assistant.core.SecureStore;
import com.orbo.assistant.overlay.OrbFaceView;
import com.orbo.assistant.overlay.OrbOverlayService;

import java.util.concurrent.Executor;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_MIC=41;
    private LinearLayout page;
    private TextView status;
    private EditText commandInput;
    private boolean pinGatePassed=false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildHome();
        if(SecureStore.hasPin(this)) page.post(this::showPinGate);
    }

    private void buildHome() {
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(20),dp(24),dp(20),dp(32));
        page.setBackgroundColor(Color.rgb(8,13,28));
        scroll.addView(page,new ScrollView.LayoutParams(-1,-2));
        setContentView(scroll);

        TextView eyebrow=text("FLOATING AI COMPANION",11,0xFF94A8FF); eyebrow.setLetterSpacing(.16f); page.addView(eyebrow);
        TextView title=text("ORBO",34,0xFFF3F6FF); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setPadding(0,dp(4),0,0); page.addView(title);
        TextView subtitle=text("Aapka phone assistant — local-first, AI optional.",14,0xFFADB8D8); subtitle.setPadding(0,dp(2),0,dp(18)); page.addView(subtitle);

        OrbFaceView hero=new OrbFaceView(this); LinearLayout heroWrap=new LinearLayout(this); heroWrap.setGravity(Gravity.CENTER); heroWrap.setPadding(0,dp(8),0,dp(14));
        heroWrap.addView(hero,new LinearLayout.LayoutParams(dp(118),dp(118))); page.addView(heroWrap);

        status=text("Status: assistant stopped",13,0xFFBFC9E8); status.setPadding(dp(14),dp(12),dp(14),dp(12));
        status.setBackground(cardDrawable(0xFF111B37,0xFF283965)); page.addView(status,lp(-1,-2,0,0,0,dp(16)));

        Button start=button("Start floating ORBO",true); page.addView(start,lp(-1,dp(52),0,0,0,dp(10)));
        start.setOnClickListener(v->startOverlay());
        Button stop=button("Stop assistant",false); page.addView(stop,lp(-1,dp(48),0,0,0,dp(18)));
        stop.setOnClickListener(v->{stopService(new Intent(this,OrbOverlayService.class));status.setText("Status: assistant stopped");});

        section("QUICK COMMAND");
        commandInput=new EditText(this); commandInput.setSingleLine(false); commandInput.setMinLines(1); commandInput.setMaxLines(3);
        commandInput.setHint("Jaise: time, open YouTube, timer 2 minutes..."); commandInput.setTextColor(0xFFF5F7FF); commandInput.setHintTextColor(0xFF7F8DB5);
        commandInput.setPadding(dp(14),dp(12),dp(14),dp(12)); commandInput.setBackground(cardDrawable(0xFF111B37,0xFF283965));
        page.addView(commandInput,lp(-1,-2,0,0,0,dp(8)));
        Button run=button("Run local command",true); page.addView(run,lp(-1,dp(48),0,0,0,dp(10)));
        run.setOnClickListener(v->runTypedCommand());
        Button explain=button("Explain current screen (with consent)",false); page.addView(explain,lp(-1,dp(48),0,0,0,dp(18)));
        explain.setOnClickListener(v->confirmScreenRead());

        section("PHONE ACCESS");
        Button accessibility=button("Enable Accessibility actions",false); page.addView(accessibility,lp(-1,dp(48),0,0,0,dp(8)));
        accessibility.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        Button overlay=button("Overlay permission settings",false); page.addView(overlay,lp(-1,dp(48),0,0,0,dp(8)));
        overlay.setOnClickListener(v->openOverlaySettings());
        Button mic=button("Microphone permission",false); page.addView(mic,lp(-1,dp(48),0,0,0,dp(18)));
        mic.setOnClickListener(v->requestMic());

        section("SECURITY & SETTINGS");
        Button settings=button("AI Assist, Gemini key and model",false); page.addView(settings,lp(-1,dp(48),0,0,0,dp(8)));
        settings.setOnClickListener(v->showSettings());
        Button pin=button(SecureStore.hasPin(this)?"Change ORBO app PIN":"Set ORBO app PIN",false); page.addView(pin,lp(-1,dp(48),0,0,0,dp(8)));
        pin.setOnClickListener(v->setPinDialog());
        Button biometric=button("Use device biometric (when supported)",false); page.addView(biometric,lp(-1,dp(48),0,0,0,dp(8)));
        biometric.setOnClickListener(v->authenticateBiometric(null));
        Button alarm=button("Timer accuracy / alarm settings",false); page.addView(alarm,lp(-1,dp(48),0,0,0,dp(8)));
        alarm.setOnClickListener(v->{
            if(Build.VERSION.SDK_INT>=31){try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}catch(Exception e){showMessage("Settings > Apps > ORBO > Alarms & reminders check karein.");}}
            else showMessage("Is Android version par exact alarm permission prompt ki zaroorat nahi hai.");
        });
        Button history=button("Task history",false); page.addView(history,lp(-1,dp(48),0,0,0,dp(18)));
        history.setOnClickListener(v->showHistory());

        TextView note=text("ORBO does not secretly listen, capture screenshots, or read secure fields. Android may limit overlays, background work and Accessibility actions.",12,0xFF8F9DBF);
        note.setPadding(0,dp(6),0,0); page.addView(note);
        refreshStatus();
    }

    private void runTypedCommand() {
        String input=commandInput.getText().toString().trim(); if(input.isEmpty())return;
        CommandRouter.Command command=CommandRouter.route(input);
        if(command.known) {
            if(command.type==CommandRouter.Type.SCREEN_SUMMARY){confirmScreenRead();return;}
            CommandExecutor.execute(this,command,msg->showMessage(msg));
        } else {
            // Only unknown commands are eligible for optional Gemini fallback.
            GeminiProvider.ask(this,input,null,(text,used)->showMessage((used?"AI used · ":"")+text));
        }
    }

    private void startOverlay() {
        if(Build.VERSION.SDK_INT>=23 && !Settings.canDrawOverlays(this)){openOverlaySettings();showMessage("Pehle ORBO ko Display over other apps permission dein.");return;}
        Intent service=new Intent(this,OrbOverlayService.class);
        if(Build.VERSION.SDK_INT>=26)startForegroundService(service);else startService(service);
        status.setText("Status: floating assistant requested — orb screen par aana chahiye");
    }

    private void openOverlaySettings() {
        if(Build.VERSION.SDK_INT>=23){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));startActivity(i);}
    }

    private void requestMic() {
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_MIC);
        else showMessage("Microphone permission already granted.");
    }
    @Override public void onRequestPermissionsResult(int requestCode,@NonNull String[] permissions,@NonNull int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==REQ_MIC){if(grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED)showMessage("Microphone permission mil gayi. Ab floating ORBO start karein.");else showMessage("Mic permission nahi mili. Voice input kaam nahi karega; local text commands available rahenge.");}
    }

    private void showSettings() {
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(8),dp(6),dp(8),dp(2));
        Switch ai=new Switch(this);ai.setText("AI Assist (default OFF)");ai.setTextColor(0xFFF5F7FF);ai.setChecked(SecureStore.isAiEnabled(this));box.addView(ai);
        EditText key=new EditText(this);key.setHint("Gemini API key (stored encrypted)");key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);key.setTextColor(0xFFFFFFFF);key.setHintTextColor(0xFF8F9DBF);key.setText(SecureStore.readGeminiKey(this));box.addView(key);
        EditText model=new EditText(this);model.setHint("Model name e.g. gemini-2.5-flash");model.setTextColor(0xFFFFFFFF);model.setHintTextColor(0xFF8F9DBF);model.setText(SecureStore.getModel(this));box.addView(model);
        TextView warning=text("AI sirf unknown/complex input par call hoga. Known commands local rahenge. Production app mein client-side key extract ho sakti hai; personal test key ko restrict/rotate karein.",11,0xFFFFD18A);box.addView(warning);
        new AlertDialog.Builder(this).setTitle("ORBO AI settings").setView(box)
                .setPositiveButton("Save",(d,w)->{
                    SecureStore.setAiEnabled(this,ai.isChecked());SecureStore.setModel(this,model.getText().toString().trim());
                    try{SecureStore.saveGeminiKey(this,key.getText().toString());showMessage("AI settings encrypted storage mein save ho gayi.");}
                    catch(Exception e){showMessage("API key secure storage mein save nahi hui. Dobara try karein.");}
                }).setNegativeButton("Cancel",null).show();
    }

    private void confirmScreenRead() {
        new AlertDialog.Builder(this).setTitle("Screen text consent")
                .setMessage("ORBO current screen ke Accessibility se available text ko read karega. Screenshot nahi liya jayega. Password, OTP aur detected banking/UPI screens block hain. Agle step mein text preview dikhega.")
                .setPositiveButton("Read screen text",(d,w)->previewScreenText()).setNegativeButton("Cancel",null).show();
    }
    private void previewScreenText() {
        String visible=OrboAccessibilityService.readVisibleTextWithConsent();
        if(visible.startsWith("Accessibility service is not enabled")||visible.startsWith("For privacy")||visible.startsWith("This screen")||visible.startsWith("No accessible")) {showMessage(visible);return;}
        EditText preview=new EditText(this);preview.setText(visible);preview.setTextColor(0xFF1A2340);preview.setTextSize(13);preview.setMinLines(4);preview.setMaxLines(12);preview.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);preview.setFocusable(false);
        new AlertDialog.Builder(this).setTitle("Text preview — Gemini ko bhejne se pehle check karein").setView(preview)
                .setPositiveButton("Send to Gemini",(d,w)->GeminiProvider.ask(this,"Please explain and summarize this visible screen.",visible,(text,used)->showMessage((used?"AI used · ":"")+text)))
                .setNegativeButton("Cancel",null).show();
    }

    private void setPinDialog() {
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(8),dp(4),dp(8),0);
        EditText one=new EditText(this);one.setHint("New 4–8 digit PIN");one.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);box.addView(one);
        EditText two=new EditText(this);two.setHint("Confirm PIN");two.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);box.addView(two);
        new AlertDialog.Builder(this).setTitle("ORBO app PIN").setView(box).setPositiveButton("Save",(d,w)->{
            String p=one.getText().toString();if(!p.equals(two.getText().toString())){showMessage("PIN match nahi hua.");return;}
            try{SecureStore.setPin(this,p);showMessage("ORBO app PIN set ho gaya. Ye Android lock screen ko replace nahi karta.");}catch(Exception e){showMessage(e.getMessage()==null?"PIN save nahi hua.":e.getMessage());}
        }).setNegativeButton("Cancel",null).show();
    }

    private void showPinGate() {
        if(isFinishing()||pinGatePassed)return;
        EditText input=new EditText(this);input.setHint("Enter ORBO PIN");input.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("ORBO locked").setMessage("Continue karne ke liye app PIN enter karein.")
                .setView(input).setCancelable(false).setPositiveButton("Unlock",null).setNeutralButton("Biometric",null).create();
        dialog.setOnShowListener(v->{
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b->{
                SecureStore.PinResult result=SecureStore.verifyPin(this,input.getText().toString());
                if(result.success){pinGatePassed=true;dialog.dismiss();}
                else if(result.retryAfterMs>0)input.setError("Lockout active. " + Math.max(1,result.retryAfterMs/1000)+" sec wait karein.");
                else input.setError("Wrong PIN. Attempts: "+result.failures);
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(b->authenticateBiometric(dialog));
        });
        dialog.show();
    }

    private void authenticateBiometric(AlertDialog gate) {
        int result=BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK);
        if(result!=BiometricManager.BIOMETRIC_SUCCESS){showMessage("Is device par supported/enrolled biometric available nahi hai. PIN use karein.");return;}
        Executor executor=ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt=new BiometricPrompt(this,executor,new BiometricPrompt.AuthenticationCallback(){
            @Override public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult r){super.onAuthenticationSucceeded(r);pinGatePassed=true;if(gate!=null)gate.dismiss();showMessage("Biometric verified.");}
            @Override public void onAuthenticationError(int code,@NonNull CharSequence msg){super.onAuthenticationError(code,msg);showMessage("Biometric: "+msg);}
            @Override public void onAuthenticationFailed(){super.onAuthenticationFailed();}
        });
        BiometricPrompt.PromptInfo info=new BiometricPrompt.PromptInfo.Builder().setTitle("Unlock ORBO").setSubtitle("Use supported device biometric").setNegativeButtonText("Use PIN").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK).build();
        prompt.authenticate(info);
    }

    private void showHistory(){new AlertDialog.Builder(this).setTitle("ORBO task history").setMessage(SecureStore.getHistory(this)).setPositiveButton("Close",null).show();}
    private void showMessage(String message){if(message==null||message.trim().isEmpty())return;new AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK",null).show();}
    private void refreshStatus(){if(Settings.canDrawOverlays(this))status.setText("Overlay permission: ON  ·  Accessibility: "+(OrboAccessibilityService.isConnected()?"ON":"OFF"));else status.setText("Overlay permission: OFF  ·  Accessibility: "+(OrboAccessibilityService.isConnected()?"ON":"OFF"));}
    @Override protected void onResume(){super.onResume();if(status!=null)refreshStatus();}

    private void section(String s){TextView t=text(s,11,0xFF8398E9);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setLetterSpacing(.12f);t.setPadding(0,dp(4),0,dp(9));page.addView(t);}
    private TextView text(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private Button button(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(14);b.setTextColor(primary?0xFFFFFFFF:0xFFE5EBFF);b.setBackground(cardDrawable(primary?0xFF4059C8:0xFF172342,primary?0xFF8296FF:0xFF334879));return b;}
    private GradientDrawable cardDrawable(int color,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(16));d.setStroke(dp(1),stroke);return d;}
    private LinearLayout.LayoutParams lp(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(l,t,r,b);return p;}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
}
