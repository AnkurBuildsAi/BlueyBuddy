package com.orbo.assistant.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Color;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.View;

/** Lightweight custom-drawn ORBO orb face; avoids image assets and heavy idle rendering. */
public class OrbFaceView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Handler handler = new Handler();
    private boolean blink = false;
    private int mood = 0; // 0 neutral, 1 listening, 2 thinking, 3 happy
    private final Runnable blinkTask = new Runnable() {
        @Override public void run() {
            if (!isAttachedToWindow()) return;
            blink = true; invalidate();
            handler.postDelayed(() -> { blink = false; invalidate(); }, 130);
            handler.postDelayed(this, 2600 + (long)(Math.random() * 2600));
        }
    };

    public OrbFaceView(Context c) { super(c); init(); }
    public OrbFaceView(Context c, AttributeSet a) { super(c, a); init(); }
    private void init() { setLayerType(View.LAYER_TYPE_HARDWARE, null); setContentDescription("ORBO floating assistant"); }
    public void setMood(int value) { mood=value; invalidate(); }
    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); handler.postDelayed(blinkTask, 1800); }
    @Override protected void onDetachedFromWindow() { handler.removeCallbacksAndMessages(null); super.onDetachedFromWindow(); }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w=getWidth(), h=getHeight(), cx=w/2f, cy=h/2f;
        float radius=Math.min(w,h)*0.46f;
        paint.clearShadowLayer();
        paint.setShader(new RadialGradient(cx-radius*.25f, cy-radius*.35f, radius*1.65f,
                new int[]{Color.rgb(125,179,255), Color.rgb(37,82,198), Color.rgb(21,20,75)},
                new float[]{0f,.48f,1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx,cy,radius,paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(Math.max(1.2f,radius*.055f));
        paint.setColor(Color.argb(150,170,202,255)); canvas.drawCircle(cx,cy,radius*.91f,paint);
        paint.setStyle(Paint.Style.FILL);
        // Eyes
        float eyeY=cy-radius*.10f, eyeDx=radius*.34f;
        paint.setColor(Color.rgb(244,249,255));
        if (blink) {
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(radius*.07f);
            canvas.drawLine(cx-eyeDx-radius*.09f,eyeY,cx-eyeDx+radius*.09f,eyeY,paint);
            canvas.drawLine(cx+eyeDx-radius*.09f,eyeY,cx+eyeDx+radius*.09f,eyeY,paint);
            paint.setStyle(Paint.Style.FILL);
        } else {
            canvas.drawOval(cx-eyeDx-radius*.10f, eyeY-radius*.13f, cx-eyeDx+radius*.10f, eyeY+radius*.15f, paint);
            canvas.drawOval(cx+eyeDx-radius*.10f, eyeY-radius*.13f, cx+eyeDx+radius*.10f, eyeY+radius*.15f, paint);
            paint.setColor(Color.rgb(28,45,105));
            canvas.drawCircle(cx-eyeDx+radius*.02f, eyeY+radius*.015f, radius*.065f, paint);
            canvas.drawCircle(cx+eyeDx+radius*.02f, eyeY+radius*.015f, radius*.065f, paint);
        }
        // Tiny mouth / expression
        paint.setColor(Color.rgb(245,248,255));
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(radius*.045f);
        android.graphics.Path path=new android.graphics.Path();
        float my=cy+radius*.30f;
        if (mood==1 || mood==2) {
            canvas.drawCircle(cx,my,radius*.055f,paint);
        } else {
            path.moveTo(cx-radius*.12f,my-radius*.01f);
            path.quadTo(cx,my+radius*(mood==3?.19f:.10f),cx+radius*.12f,my-radius*.01f);
            canvas.drawPath(path,paint);
        }
        paint.setStyle(Paint.Style.FILL);
        // Tiny accent shine
        paint.setColor(Color.argb(105,255,255,255));
        canvas.drawCircle(cx-radius*.30f,cy-radius*.45f,radius*.10f,paint);
    }
}
