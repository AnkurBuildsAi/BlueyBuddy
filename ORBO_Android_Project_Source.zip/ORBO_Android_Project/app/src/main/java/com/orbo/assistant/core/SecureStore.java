package com.orbo.assistant.core;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/** Local secret storage. API keys are encrypted with an Android Keystore AES-GCM key.
 * PIN material is stored only as a salted PBKDF2 hash; the raw PIN is never persisted. */
public final class SecureStore {
    private static final String PREF = "orbo_secure_store";
    private static final String KEY_ALIAS = "orbo_master_aes_v1";
    private static final int PIN_ITERATIONS = 80000;
    private static final int PIN_BITS = 256;
    private static final SecureRandom RANDOM = new SecureRandom();

    private SecureStore() { }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static void saveGeminiKey(Context context, String key) throws Exception {
        String clean = key == null ? "" : key.trim();
        if (clean.isEmpty()) {
            prefs(context).edit().remove("gemini_key_enc").apply();
            return;
        }
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateAesKey());
        byte[] encrypted = cipher.doFinal(clean.getBytes("UTF-8"));
        byte[] iv = cipher.getIV();
        byte[] packed = new byte[iv.length + encrypted.length];
        System.arraycopy(iv, 0, packed, 0, iv.length);
        System.arraycopy(encrypted, 0, packed, iv.length, encrypted.length);
        prefs(context).edit().putString("gemini_key_enc", Base64.encodeToString(packed, Base64.NO_WRAP)).apply();
    }

    public static String readGeminiKey(Context context) {
        try {
            String encoded = prefs(context).getString("gemini_key_enc", null);
            if (encoded == null) return "";
            byte[] packed = Base64.decode(encoded, Base64.NO_WRAP);
            if (packed.length < 13) return "";
            byte[] iv = new byte[12];
            byte[] body = new byte[packed.length - 12];
            System.arraycopy(packed, 0, iv, 0, 12);
            System.arraycopy(packed, 12, body, 0, body.length);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateAesKey(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(body), "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private static SecretKey getOrCreateAesKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        java.security.Key existing = ks.getKey(KEY_ALIAS, null);
        if (existing instanceof SecretKey) return (SecretKey) existing;
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }

    public static boolean hasPin(Context c) { return prefs(c).contains("pin_hash") && prefs(c).contains("pin_salt"); }

    public static void setPin(Context c, String pin) throws Exception {
        if (pin == null || !pin.matches("[0-9]{4,8}")) throw new IllegalArgumentException("PIN 4 se 8 digits ka hona chahiye");
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);
        byte[] hash = derive(pin, salt);
        prefs(c).edit().putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                .putString("pin_hash", Base64.encodeToString(hash, Base64.NO_WRAP))
                .putInt("pin_failures", 0).putLong("pin_lock_until", 0L).apply();
    }

    public static PinResult verifyPin(Context c, String pin) {
        SharedPreferences p = prefs(c);
        long now = System.currentTimeMillis();
        long lockedUntil = p.getLong("pin_lock_until", 0L);
        if (now < lockedUntil) return new PinResult(false, lockedUntil - now, p.getInt("pin_failures", 0));
        try {
            byte[] salt = Base64.decode(p.getString("pin_salt", ""), Base64.NO_WRAP);
            byte[] expected = Base64.decode(p.getString("pin_hash", ""), Base64.NO_WRAP);
            byte[] actual = derive(pin == null ? "" : pin, salt);
            if (constantTimeEquals(expected, actual)) {
                p.edit().putInt("pin_failures", 0).putLong("pin_lock_until", 0L).apply();
                return new PinResult(true, 0, 0);
            }
        } catch (Exception ignored) { }
        int failures = p.getInt("pin_failures", 0) + 1;
        long delay = failures >= 12 ? 15 * 60_000L : failures >= 8 ? 5 * 60_000L : failures >= 5 ? 30_000L : failures >= 3 ? 10_000L : 0L;
        long until = now + delay;
        p.edit().putInt("pin_failures", failures).putLong("pin_lock_until", until).apply();
        return new PinResult(false, delay, failures);
    }

    private static byte[] derive(String pin, byte[] salt) throws Exception {
        KeySpec spec = new PBEKeySpec(pin.toCharArray(), salt, PIN_ITERATIONS, PIN_BITS);
        try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); }
        finally { ((PBEKeySpec) spec).clearPassword(); }
    }

    private static boolean constantTimeEquals(byte[] a, byte[] b) {
        if (a == null || b == null || a.length != b.length) return false;
        int diff = 0;
        for (int i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
        return diff == 0;
    }

    public static boolean isAiEnabled(Context c) { return prefs(c).getBoolean("ai_enabled", false); }
    public static void setAiEnabled(Context c, boolean value) { prefs(c).edit().putBoolean("ai_enabled", value).apply(); }
    public static String getModel(Context c) { return prefs(c).getString("gemini_model", "gemini-2.5-flash"); }
    public static void setModel(Context c, String m) { prefs(c).edit().putString("gemini_model", m).apply(); }

    public static void saveHistory(Context c, String line) {
        SharedPreferences p = c.getSharedPreferences("orbo_history", Context.MODE_PRIVATE);
        String old = p.getString("items", "");
        String next = (System.currentTimeMillis() + "|" + line.replace('\n', ' ') + "\n" + old);
        String[] lines = next.split("\n");
        StringBuilder trimmed = new StringBuilder();
        for (int i = 0; i < lines.length && i < 80; i++) trimmed.append(lines[i]).append('\n');
        p.edit().putString("items", trimmed.toString()).apply();
    }

    public static String getHistory(Context c) {
        return c.getSharedPreferences("orbo_history", Context.MODE_PRIVATE).getString("items", "No history yet.");
    }

    public static final class PinResult {
        public final boolean success;
        public final long retryAfterMs;
        public final int failures;
        PinResult(boolean s, long r, int f) { success = s; retryAfterMs = r; failures = f; }
    }
}
