package com.orbo.assistant.overlay;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

import com.orbo.assistant.MainActivity;
import com.orbo.assistant.R;
import com.orbo.assistant.core.CommandExecutor;
import com.orbo.assistant.core.CommandRouter;
import com.orbo.assistant.core.GeminiProvider;
import com.orbo.assistant.core.SecureStore;

import java.util.ArrayList;
import java.util.Locale;

public class OrbOverlayService extends Service implements TextToSpeech.OnInitListener {
    public static final String ACTION_STOP = "com.orbo.assistant.STOP_ORB";
    private static final String CHANNEL = "orbo_assistant_service";
    private WindowManager windowManager;
    private WindowManager.LayoutParams params;
    private LinearLayout root;
    private OrbFaceView orb;
    private TextView answer, mic, close;
    private boolean pill=false, peek=false, moved=false, longPressed=false;
    private float downRawX, downRawY;
    private int downX, downY;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private Runnable longPressRunnable;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;

    @Override public void onCreate() {
        super.onCreate();
        windowManager=(WindowManager)getSystemService(WINDOW_SERVICE);
        tts=new TextToSpeech(this,this);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent!=null && ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        startForeground(7101, buildNotification());
        if (Build.VERSION.SDK_INT>=23 && !Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        if (root==null) showOrb();
        return START_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT>=26) {
            NotificationChannel ch=new NotificationChannel(CHANNEL,"ORBO assistant",NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Shows when the ORBO floating assistant is active");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private android.app.Notification buildNotification() {
        Intent stop=new Intent(this,OrbOverlayService.class).setAction(ACTION_STOP);
        int f=PendingIntent.FLAG_UPDATE_CURRENT; if(Build.VERSION.SDK_INT>=23)f|=PendingIntent.FLAG_IMMUTABLE;
        PendingIntent stopPi=PendingIntent.getService(this,7102,stop,f);
        Intent open=new Intent(this,MainActivity.class);
        PendingIntent openPi=PendingIntent.getActivity(this,7103,open,f);
        return new NotificationCompat.Builder(this,CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("ORBO is active")
                .setContentText("Floating assistant running — tap Stop to close")
                .setContentIntent(openPi).setOngoing(true)
                .addAction(android.R.drawable.ic_media_pause,"Stop",stopPi).build();
    }

    private void showOrb() {
        if(windowManager==null)return;
        root=new LinearLayout(this); root.setGravity(Gravity.CENTER_VERTICAL); root.setOrientation(LinearLayout.HORIZONTAL);
        root.setPadding(dp(4),dp(4),dp(8),dp(4));
        setBackground(root,0xEE111A38,dp(36),0x886E8BFF);
        orb=new OrbFaceView(this);
        root.addView(orb,new LinearLayout.LayoutParams(dp(68),dp(68)));
        answer=new TextView(this); answer.setText("Namaste! Long-press karein"); answer.setTextColor(0xFFF0F4FF); answer.setTextSize(12); answer.setMaxLines(2);
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(48),1f); ap.leftMargin=dp(8);
        root.addView(answer,ap);
        mic=new TextView(this); mic.setText("🎙"); mic.setTextSize(19); mic.setGravity(Gravity.CENTER); mic.setTextColor(0xFFFFFFFF);
        root.addView(mic,new LinearLayout.LayoutParams(dp(42),dp(48)));
        close=new TextView(this); close.setText("×"); close.setTextSize(24); close.setTextColor(0xFFBFCBFF); close.setGravity(Gravity.CENTER);
        root.addView(close,new LinearLayout.LayoutParams(dp(30),dp(48)));
        int flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        params=new WindowManager.LayoutParams(dp(76),dp(76),type,flags,PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START;
        params.x=getPreferences().getInt("x",dp(16)); params.y=getPreferences().getInt("y",dp(180));
        root.setClipToOutline(true);
        try { windowManager.addView(root,params); } catch(Exception e){stopSelf();return;}
        // Start as a single orb, not a permanently open pill.
        setMode(false,false);
        orb.setOnTouchListener(this::onOrbTouch);
        mic.setOnClickListener(v->startListening());
        close.setOnClickListener(v->setMode(false,false));
        root.setScaleX(.86f); root.setScaleY(.86f); root.setAlpha(0f);
        root.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(320).start();
    }

    private boolean onOrbTouch(View v, MotionEvent e) {
        switch(e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                downRawX=e.getRawX(); downRawY=e.getRawY(); downX=params.x; downY=params.y;
                moved=false; longPressed=false;
                if(longPressRunnable!=null)handler.removeCallbacks(longPressRunnable);
                longPressRunnable=()->{if(!moved){longPressed=true;setMode(!pill,false);}};
                handler.postDelayed(longPressRunnable,500);
                return true;
            case MotionEvent.ACTION_MOVE:
                float dx=e.getRawX()-downRawX, dy=e.getRawY()-downRawY;
                if(Math.abs(dx)>dp(5)||Math.abs(dy)>dp(5)) { moved=true; if(longPressRunnable!=null)handler.removeCallbacks(longPressRunnable); }
                if(moved && params!=null) { params.x=downX+(int)dx; params.y=downY+(int)dy; safeUpdate(); }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if(longPressRunnable!=null)handler.removeCallbacks(longPressRunnable);
                if(moved) {
                    int screen= getResources().getDisplayMetrics().widthPixels;
                    params.x=Math.max(0,Math.min(params.x,screen-(pill?dp(peek?170:290):dp(76))));
                    getPreferences().edit().putInt("x",params.x).putInt("y",params.y).apply(); safeUpdate();
                    if(pill && downRawY-e.getRawY()>dp(50)) setMode(true,true);
                } else if(!longPressed) {
                    orb.animate().scaleX(1.08f).scaleY(1.08f).setDuration(100).withEndAction(()->orb.animate().scaleX(1f).scaleY(1f).setDuration(130).start()).start();
                }
                return true;
        }
        return true;
    }

    private void setMode(boolean toPill, boolean toPeek) {
        if(root==null)return;
        pill=toPill; peek=toPill&&toPeek;
        if(pill) {
            answer.setVisibility(peek?View.GONE:View.VISIBLE); mic.setVisibility(peek?View.GONE:View.VISIBLE); close.setVisibility(View.VISIBLE);
            root.setBackground(background(0xF0131C3B,dp(38),0xAA8294FF));
            params.width=dp(peek?170:290); params.height=dp(76);
            answer.setText(peek?"ORBO":"Ready. Mic dabayein ya boliye.");
        } else {
            answer.setVisibility(View.GONE); mic.setVisibility(View.GONE); close.setVisibility(View.GONE);
            root.setBackground(background(0x00111A38,dp(40),0x00000000));
            params.width=dp(76); params.height=dp(76);
        }
        safeUpdate();
    }

    private void safeUpdate(){try{if(root!=null&&root.isAttachedToWindow())windowManager.updateViewLayout(root,params);}catch(Exception ignored){}}
    private void setMessage(String text, boolean usedAi) {
        if(root==null)return;
        setMode(true,false);
        answer.setText((usedAi?"✦ AI used · ":"")+text);
        orb.setMood(usedAi?2:3);
        speak(text);
    }
    private void startListening() {
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=android.content.pm.PackageManager.PERMISSION_GRANTED) {
            setMessage("Microphone permission app mein enable karein.",false); return;
        }
        if(!SpeechRecognizer.isRecognitionAvailable(this)) { setMessage("Speech recognition provider available nahi hai.",false); return; }
        try {
            if(recognizer!=null){recognizer.destroy();recognizer=null;}
            recognizer=SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(android.os.Bundle b){setMessage("Sun raha hoon…",false);if(orb!=null)orb.setMood(1);}
                @Override public void onBeginningOfSpeech(){}
                @Override public void onRmsChanged(float r){}
                @Override public void onBufferReceived(byte[] b){}
                @Override public void onEndOfSpeech(){if(orb!=null)orb.setMood(2);}
                @Override public void onError(int error){setMessage("Awaaz samajh nahi aayi. Dobara try karein.",false);}
                @Override public void onResults(android.os.Bundle b){ArrayList<String> list=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(list!=null&&!list.isEmpty())handleCommand(list.get(0));}
                @Override public void onPartialResults(android.os.Bundle b){}
                @Override public void onEvent(int t,android.os.Bundle b){}
            });
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN");
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"hi-IN");
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3);
            recognizer.startListening(i);
            setMessage("Listening…",false);
        } catch(Exception e){setMessage("Mic start nahi ho saka. Permission/provider check karein.",false);}
    }

    private void handleCommand(String spoken) {
        CommandRouter.Command command=CommandRouter.route(spoken);
        if(command.known) {
            if(command.type==CommandRouter.Type.SCREEN_SUMMARY){setMessage("Screen summary ke liye ORBO app mein consent prompt open karein.",false);return;}
            CommandExecutor.execute(this,command,msg->setMessage(msg,false));
        } else {
            // Strict routing: only unknown commands can reach Gemini. If AI is off/no key/offline, it degrades gracefully.
            GeminiProvider.ask(this,spoken,null,(text,used)->setMessage(text,used));
        }
    }

    private void speak(String text) {
        if (text == null || text.equals("Listening…") || text.equals("Sun raha hoon…")) return;
        if(tts!=null && text!=null && Build.VERSION.SDK_INT>=21) {
            try { tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"orbo_reply"); } catch(Exception ignored) { }
        }
    }
    @Override public void onInit(int status) { if(status==TextToSpeech.SUCCESS && tts!=null) { int r=tts.setLanguage(new Locale("hi","IN")); if(r==TextToSpeech.LANG_MISSING_DATA||r==TextToSpeech.LANG_NOT_SUPPORTED)tts.setLanguage(Locale.getDefault()); } }
    private android.content.SharedPreferences getPreferences(){return getSharedPreferences("orbo_overlay",MODE_PRIVATE);}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private void setBackground(View view,int color,int radius,int stroke){view.setBackground(background(color,radius,stroke));}
    private GradientDrawable background(int color,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);if(stroke!=0)d.setStroke(dp(1),stroke);return d;}

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if(recognizer!=null){try{recognizer.cancel();recognizer.destroy();}catch(Exception ignored){}recognizer=null;}
        if(tts!=null){tts.stop();tts.shutdown();tts=null;}
        try{if(root!=null&&root.isAttachedToWindow())windowManager.removeView(root);}catch(Exception ignored){}
        root=null;
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent){return null;}
}
