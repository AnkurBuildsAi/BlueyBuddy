# ORBO feature ledger

Status terms: `SOURCE IMPLEMENTED` means implementation is present in this source tree but has not yet passed a device test. `PARTIAL` means a limited Android-supported version exists. `NOT IMPLEMENTED` means it is not in this ZIP.

| Feature | Status | Notes / dependencies |
|---|---|---|
| ORBO name and dark blue/purple orb identity | SOURCE IMPLEMENTED | Custom Canvas orb, no remote image assets |
| Expressions, eyes, mouth and blinking | PARTIAL | Neutral/listening/thinking/happy mood; simple variable blink |
| Floating overlay | SOURCE IMPLEMENTED | User must grant Display over other apps |
| Dragging and position persistence | SOURCE IMPLEMENTED | Saved after drag; OEM battery rules still apply |
| Tap ripple/bounce | PARTIAL | Bounce animation, no advanced particle/ripple engine |
| Long-press Orb-to-Pill morph | SOURCE IMPLEMENTED | 500 ms gesture |
| Smart Pill | SOURCE IMPLEMENTED | Voice button, message, close; simple text layout |
| Peek Mode | PARTIAL | Compact pill state, entered by upward drag on orb handle |
| Unlock-entry animation | NOT IMPLEMENTED | Current animation is only when overlay service starts |
| Manual microphone | SOURCE IMPLEMENTED | Runtime mic permission and system speech provider required |
| Hindi/Hinglish speech | PARTIAL | `hi-IN` preference; exact accuracy depends on installed provider/network |
| Always-on wake phrase | NOT IMPLEMENTED | No idle mic listening |
| Text-to-Speech | SOURCE IMPLEMENTED | System TTS Hindi preference, device voices vary |
| Greetings, time/date, arithmetic | SOURCE IMPLEMENTED | Deterministic local router |
| Timer, cancel, completion alert | SOURCE IMPLEMENTED | AlarmManager; exact alarms depend on special access/OEM limits |
| Timer reboot restore | SOURCE IMPLEMENTED | Uses persisted wall-clock deadline and BootReceiver |
| Multiple concurrent timers | NOT IMPLEMENTED | One active timer slot |
| Open installed apps / web search | SOURCE IMPLEMENTED | Android package visibility and installed app availability apply |
| Back/Home/Recents/Scroll | SOURCE IMPLEMENTED | Accessibility permission required; not all screens support it |
| Type text / Copy / Paste | PARTIAL | Focused ordinary fields only; secure/password/OTP-like fields blocked by heuristics |
| Enumerate visible buttons / tap by number | SOURCE IMPLEMENTED | `show buttons`, then `tap 1`; exposed accessibility labels only |
| Screen text understanding | PARTIAL | Explicit consent + preview + send; Accessibility text only, no screenshot |
| Gemini API fallback | PARTIAL | AI default OFF; only unknown commands/screen summary; text reply only, no actions executed |
| AI provider interface | SOURCE IMPLEMENTED | `AiProvider` seam and Gemini implementation |
| Structured multi-step plan + confirm + execute + verify | NOT IMPLEMENTED | Gemini does not execute phone actions in this ZIP |
| API key encrypted local storage | SOURCE IMPLEMENTED | Android Keystore AES-GCM; not a substitute for a backend proxy |
| ORBO history | PARTIAL | Local last 80 text entries |
| App PIN | SOURCE IMPLEMENTED | Salted PBKDF2-HMAC-SHA256; reset/recovery flow not included |
| Biometric prompt | PARTIAL | Uses supported enrolled device biometrics; PIN fallback |
| Camera face match / failed-PIN capture | NOT IMPLEMENTED | No camera permission or capture implementation |
| Per-app lock manager / Android lock-screen replacement | NOT IMPLEMENTED | Ordinary apps cannot reliably replace OS lock screen or enforce universal app locks |
| Foreground service and Stop notification | SOURCE IMPLEMENTED | User-visible active notification |
| Unit tests | SOURCE ADDED | Command parser tests; CI run pending |
| Real-device test on Oppo A3s | NOT TESTED | No physical device connected to build environment |
| Real-device test on Vivo Y13s | NOT TESTED | No physical device connected to build environment |
| Clean GitHub Actions build | NOT TESTED | Run the included workflow and inspect its result |
